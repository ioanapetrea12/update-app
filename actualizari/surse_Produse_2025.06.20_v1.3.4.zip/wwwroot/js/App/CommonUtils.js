﻿Array.prototype.inArray = function (comparer) {
    for (var i = 0; i < this.length; i++) {
        if (comparer(this[i])) return true;
    }
    return false;
};

Array.prototype.removeObject = function (object) {
    var i = this.indexOf(object);
    if (i < 0) {
        return;
    }

    this.splice(i, 1);
};

Array.prototype.pushIfNotExist = function (element, comparer) {
    if (!this.inArray(comparer)) {
        this.push(element);
    }
};

Array.prototype.indexOfObject = function (property, value) {
    for (let i = 0; i < this.length; i++) {
        if (this[i][property] === value) {
            return i;
        }
    }
    return -1;
};
Array.prototype.count = function (expr) {
    if (expr === undefined || typeof expr !== "function") {
        return null;
    }

    var count = 0;
    for (var i = 0; i < this.length; i++) {
        if (expr(this[i])) {
            count++;
        }
    }
    return count;
};

Array.prototype.all = function (expr) {
    for (var i = 0; i < this.length; i++) {
        if (!expr(this[i])) {
            return false;
        }
    }

    return true;
};

Array.prototype.where = function (expr) {
    if (expr === undefined || typeof expr !== "function") {
        return null;
    }

    var out = [];
    for (var i = 0; i < this.length; i++) {
        if (expr(this[i])) {
            out.push(this[i]);
        }
    }
    return out;
};

Array.prototype.select = function (expr) {
    if (expr === undefined || typeof expr !== "function") {
        return null;
    }

    var out = [];
    for (var i = 0; i < this.length; i++) {
        out.push(expr(this[i]));
    }

    return out;
};

Array.prototype.whereSelect = function (where, select) {
    if (!expr || !select || typeof where !== "function" || typeof select !== "function") {
        return null;
    }

    if (this.length === 0) {
        return [];
    }

    var out = [];
    for (var i = 0; i < this.length; i++) {
        if (where(this[i])) {
            out.push(expr(this[i]));
        }
    }

    return out;
};

Array.prototype.find = function (expr) {
    if (expr === undefined || typeof expr !== "function") {
        return null;
    }
    for (var i = 0; i < this.length; i++) {
        if (expr(this[i])) {
            return this[i];
        }
    }
    return null;
};

Array.prototype.last = function (expr) {
    if (this.length === 0) {
        return null;
    }

    if (!expr || typeof (expr) !== "function") {
        return this[this.length - 1];
    }

    var subArray = this.where(expr);
    if (subArray !== null) {
        if (subArray.length === 0) {
            return null;
        }
        else {
            return subArray[subArray.length - 1];
        }
    }

    return this[this.length - 1];
};

Array.prototype.minMax = function (getMinOrMax) {
    if (this.length == 0) {
        return null;
    }

    var minMax = this[0];

    for (var i = 0; i < this.length; i++) {
        minMax = getMinOrMax(this[i], minMax);
    }

    return minMax;
};

Array.prototype.first = function (expr) {
    if (this.length === 0) {
        return null;
    }

    if (!expr) {
        return this.length > 0 ? this[0] : null;
    }

    for (var i = 0; i < this.length; i++) {
        if (expr(this[i])) {
            return this[i];
        }
    }

    return null;
};

Array.prototype.any = function (expr) {
    if (this.length === 0) {
        return false;
    }

    for (var i = 0; i < this.length; i++) {
        if (expr(this[i])) {
            return true;
        }
    }

    return false;
};

Array.prototype.forEachEl = function (expr) {
    if (this.length === 0) {
        return;
    }

    for (var i = 0; i < this.length; i++) {
        if (expr(this[i])) {
            break;
        }
    }
};

Array.prototype.count = function (expr) {
    if (this.length === 0) {
        return 0;
    }

    var count = 0;
    for (var i = 0; i < this.length; i++) {
        if (expr(this[i])) {
            count++;
        }
    }

    return count;
};

Date.prototype.ddmmyyyy = function () {
    var mm = this.getMonth() + 1; // getMonth() is zero-based
    var dd = this.getDate();

    return [(dd > 9 ? '' : '0') + dd, (mm > 9 ? '' : '0') + mm, this.getFullYear()].join('.');
};

function Default(val, defaultVal) {
    if (val === undefined || val === null) {
        return defaultVal;
    }

    return val;
}

function convertModelToFormData(data, form, namespace) {
    data = Default(data, {})
    form = Default(form, null)
    namespace = Default(namespace, '')
    var model = {};
    for (var propertyName in data) {
        model[propertyName] = data[propertyName]
    }

    var formData = form || new FormData();

    for (var propertyName in model) {
        if (!model.hasOwnProperty(propertyName) || !model[propertyName]) continue;
        var formKey = namespace ? namespace + "." + propertyName + "" : propertyName;
        if (model[propertyName] instanceof Date)
            formData.append(formKey, model[propertyName].toISOString());
        else if (model[propertyName] instanceof File) {
            formData.append(formKey, model[propertyName]);
        }
        else if (model[propertyName] instanceof Array) {
            for (var index = 0; index < model[propertyName].length; index++) {
                var element = model[propertyName][index];
                var tempFormKey = formKey + "[" + index + "]";
                if (typeof element === 'object') {
                    this.convertModelToFormData(element, formData, tempFormKey);
                }
                else formData.append(tempFormKey, element.toString());
            }
        }
        else if (typeof model[propertyName] === 'object' && !(model[propertyName] instanceof File))
            this.convertModelToFormData(model[propertyName], formData, formKey);
        else {
            formData.append(formKey, model[propertyName].toString());
        }
    }

    return formData;
}

function GenerateGuid() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
        var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
        return v.toString(16);
    });
}

function IsValidResult(result) {
    return result && result.success;
};

var ReloadDataGrid = function (id) {
    if ($(id).length == 0) {
        throw "dxDataGrid with id: " + id + " not exists";
    }

    $(id).dxDataGrid("getDataSource").reload();
}

var IsDataGridInstance = function (id) {
    return $(id).dxDataGrid("getDataSource") != null;
}

var IsTreeListInstance = function (id) {
    return $(id).dxTreeList("getDataSource") != null;
}

var ShowPopup = function (id) {
    if ($(id).length == 0) {
        throw "Popup with id: " + id + " not exists";
    }

    $(id).dxPopup("instance").show();
}

var ToastShowSuccess = function (message) {
    DevExpress.ui.notify({
        message: message,
        shading: true,
        position: {
            my: 'top center',
            at: 'top center',
            of: window,
            offset: '0 20'
        }
    }, "success", 3000);
}

var ToastShowError = function (message) {
    DevExpress.ui.notify({
        message: message,
        shading: true,
        position: {
            my: 'top center',
            at: 'top center',
            of: window,
            offset: '0 20'
        }
    }, "error", 6000);
}

var ToastShowInfo = function (message) {
    DevExpress.ui.notify({
        message: message,
        shading: true,
        position: {
            my: 'top center',
            at: 'top center',
            of: window,
            offset: '0 20'
        }
    }, "info", 3000);
}

var HidePopup = function (id) {
    if ($(id).length == 0) {
        throw "Popup with id: " + id + " not exists";
    }

    $(id).dxPopup("instance").hide();
}

var ReloadTreeList = function (id) {
    if ($(id).length == 0) {
        throw "dxTreeList with id: " + id + " not exists";
    }

    $(id).dxTreeList("getDataSource").reload();
}

var ShowLoading = function (clickEnabled = false) {
    let loadingPanel = $("#loading-panel").dxLoadPanel({
        shadingColor: "rgba(0,0,0,0.4)",
        visible: true,
        message: "Va rugam asteptati, se prelucreaza datele!",
        showIndicator: true,
        showPane: true,
        shading: true,
        hideOnOutsideClick: clickEnabled
    }).dxLoadPanel("instance");

    loadingPanel.option("message", "Va rugam asteptati, se prelucreaza datele!");

    loadingPanel.show();
}


var HideLoading = function (clickEnabled = false) {
    let loadingPanel = $("#loading-panel").dxLoadPanel({
        shadingColor: "rgba(0,0,0,0.4)",
        visible: true,
        message: "Va rugam asteptati, se prelucreaza datele!",
        showIndicator: true,
        showPane: true,
        shading: true,
        hideOnOutsideClick: clickEnabled
    }).dxLoadPanel("instance");

    loadingPanel.option("message", "Va rugam asteptati, se prelucreaza datele!");

    loadingPanel.hide();
}

GetValueFromDxDateBox = function (id) {
    if ($(id).length == 0) {
        throw "Picker with id: " + id + " not exists";
    }

    return ($(id).dxDateBox("instance").option('value') != null ? moment($(id).dxDateBox("instance").option('value')).format() : null)
}

GetValueFromDxCheckBox = function (id) {
    if ($(id).length == 0) {
        throw "CheckBox with id: " + id + " not exists";
    }

    return ($(id).dxCheckBox("instance").option('value'))
}

GetValueFromDxSelectBox = function (id) {
    if ($(id).length == 0) {
        throw "CheckBox with id: " + id + " not exists";
    }

    return ($(id).dxSelectBox("instance").option('value'))
}

GetValueFromDxNumberBox = function (id) {
    if ($(id).length == 0) {
        throw "CheckBox with id: " + id + " not exists";
    }

    return ($(id).dxNumberBox("instance").option('value'))
}

GetValueFromDxDropdownBox = function (id) {
    if ($(id).length == 0) {
        throw "DropDownBox with id: " + id + " not exists";
    }

    return ($(id).dxDropDownBox("instance").option('value'))
}


GetValueFromDxDateBox = function (id) {
    if ($(id).length == 0) {
        throw "DateBoxF with id: " + id + " not exists";
    }

    return ($(id).dxDateBox("instance").option('value'))
}

SetValueFromDxDropdownBox = function (id, value) {
    if ($(id).length == 0) {
        throw "DropDownBox with id: " + id + " not exists";
    }

    return ($(id).dxDropDownBox("instance").option('value', value))
}

SetValueFromDxGroupRadio = function (id, value) {
    if ($(id).length == 0) {
        throw "DropDownBox with id: " + id + " not exists";
    }

    return ($(id).dxRadioGroup("instance").option('value', value))
}

GetValueFromDxTextBox = function (id) {
    if ($(id).length == 0) {
        throw "Textbox with id: " + id + " not exists";
    }

    return ($(id).dxTextBox("instance").option('value'))
}

GetValueFromDxTextArea = function (id) {
    if ($(id).length == 0) {
        throw "Text Area with id: " + id + " not exists";
    }

    return ($(id).dxTextArea("instance").option('value'))
}

GetValueFromDxGroupRadio = function (id) {
    if ($(id).length == 0) {
        throw "Radio Group with id: " + id + " not exists";
    }

    return ($(id).dxRadioGroup("instance").option('value'))
}

GetSelectedRowData = function (id) {
    if ($(id).length == 0) {
        throw "dataGrid with id: " + id + " not exists";
    }

    var data = $(id).dxDataGrid("instance").getSelectedRowsData();
    return data;
}

// start grid functions

GetNumberItemsDataSource = function (id) {
    if ($(id).length == 0) {
        throw "dxDataGrid with id: " + id + " not exists";
    }

    return $(id).dxDataGrid('getDataSource')._items.length;
}

GetModifiedDataFromGrid = function (id) {
    if ($(id).length == 0) {
        throw "dxDataGrid with id: " + id + " not exists";
    }
    return $(id).dxDataGrid("instance").getVisibleRows();
}

GetModifiedDataFromTree = function (id) {
    if ($(id).length == 0) {
        throw "dxTreeList with id: " + id + " not exists";
    }
    return $(id).dxTreeList("instance").getVisibleRows();
}

function CustomCopyTo(modelType, items, bReturnAllDataAsNewLines = false) {
    // items - the list of objects
    // modelType - the type of model must be defined
    // this function will return a new list of elements of the model type received as a parameter
    if (items == undefined || items == null || items.length == 0 || !(modelType instanceof Object)) {
        return [];
    }

    var returnedList = [];
    for (var i = 0; i < items.length; i++) {
        var itemUpdated;

        var isNewItem = (bReturnAllDataAsNewLines === false) ? items[i].isNewRow === true ? true : false : true;
        var isUpdateItem = ((items[i]['modified'] != undefined && items[i].modified) || (items[i]['isEditing'] && items[i].isEditing == true)) ? true : false;
        var isDeleteItem = (items[i]['removed'] != undefined && items[i].removed) ? true : false;

        itemUpdated = items[i].data;
        var newItem = Object.create(modelType);

        var properties = Object.getOwnPropertyNames(modelType);
        if (properties != []) {
            if (isNewItem) {
                for (var j = 0; j < properties.length; j++) {
                    var property = properties[j];
                    if (itemUpdated[property] != undefined) {
                        if (bReturnAllDataAsNewLines === true && property === "Id")
                            newItem[property] = 0; //cand returnam intreaga lista ca fiind inregistrari noi atunci nu mai preluam si id-urile inregistrarilor
                        else
                            newItem[property] = itemUpdated[property]
                    }
                }
                newItem["ActionType"] = ActionTypeEnum.Insert;
            }
            else if (isUpdateItem) {
                for (var j = 0; j < properties.length; j++) {
                    var property = properties[j];
                    if (itemUpdated[property] != undefined) {
                        newItem[property] = itemUpdated[property];
                    }
                }
                newItem["ActionType"] = ActionTypeEnum.Update;
            } else if (isDeleteItem) {
                for (var j = 0; j < properties.length; j++) {
                    var property = properties[j];
                    if (itemUpdated[property] != undefined) {
                        newItem[property] = itemUpdated[property];
                    }
                }
                newItem["ActionType"] = ActionTypeEnum.Remove;
            }
        }

        if (isNewItem || isUpdateItem || isDeleteItem) {
            returnedList.push(newItem);
        }
    }

    return returnedList;
}

function CustomCopyTo(modelType, items, bReturnAllDataAsNewLines = false) {
    // items - the list of objects
    // modelType - the type of model must be defined
    // this function will return a new list of elements of the model type received as a parameter
    if (items == undefined || items == null || items.length == 0 || !(modelType instanceof Object)) {
        return [];
    }

    var returnedList = [];
    for (var i = 0; i < items.length; i++) {
        var itemUpdated;

        var isNewItem = (bReturnAllDataAsNewLines === false) ? items[i].isNewRow === true ? true : false : true;
        var isUpdateItem = ((items[i]['modified'] != undefined && items[i].modified) || (items[i]['isEditing'] && items[i].isEditing == true)) ? true : false;
        var isDeleteItem = (items[i]['removed'] != undefined && items[i].removed) ? true : false;

        itemUpdated = items[i].data;
        var newItem = Object.create(modelType);

        var properties = Object.getOwnPropertyNames(modelType);
        if (properties != []) {
            if (isNewItem) {
                for (var j = 0; j < properties.length; j++) {
                    var property = properties[j];
                    if (itemUpdated[property] != undefined) {
                        if (bReturnAllDataAsNewLines === true && property === "Id")
                            newItem[property] = 0; //cand returnam intreaga lista ca fiind inregistrari noi atunci nu mai preluam si id-urile inregistrarilor
                        else
                            newItem[property] = itemUpdated[property]
                    }
                }
                newItem["ActionType"] = ActionTypeEnum.Insert;
            }
            else if (isUpdateItem) {
                for (var j = 0; j < properties.length; j++) {
                    var property = properties[j];
                    if (itemUpdated[property] != undefined) {
                        newItem[property] = itemUpdated[property];
                    }
                }
                newItem["ActionType"] = ActionTypeEnum.Update;
            } else if (isDeleteItem) {
                for (var j = 0; j < properties.length; j++) {
                    var property = properties[j];
                    if (itemUpdated[property] != undefined) {
                        newItem[property] = itemUpdated[property];
                    }
                }
                newItem["ActionType"] = ActionTypeEnum.Remove;
            }
        }

        if (isNewItem || isUpdateItem || isDeleteItem) {
            returnedList.push(newItem);
        }
    }

    return returnedList;
}

function CustomCopyToAsModified(modelType, items) {
    if (items == undefined || items == null || items.length == 0 || !(modelType instanceof Object)) {
        return [];
    }

    var returnedList = [];
    for (var i = 0; i < items.length; i++) {
        var itemUpdated = items[i];
        var newItem = Object.create(modelType);

        var properties = Object.getOwnPropertyNames(modelType);
        if (properties != []) {
            for (var j = 0; j < properties.length; j++) {
                var property = properties[j];
                if (itemUpdated[property] != undefined) {
                    newItem[property] = itemUpdated[property];
                }
            }
            newItem["ActionType"] = ActionTypeEnum.Update;
        }
        returnedList.push(newItem);
    }

    return returnedList;
}

//function CustomCopyTo(modelType, items) {
//    // items - the list of objects
//    // modelType - the type of model must be defined
//    // this function will return a new list of elements of the model type received as a parameter
//    if (items == undefined || items == null || items.length == 0 || !(modelType instanceof Object)) {
//        return [];
//    }

//    var returnedList = [];
//    for (var i = 0; i < items.length; i++) {
//        var itemUpdated;

//        var isNewItem = items[i].isNewRow === true ? true : false;
//        var isUpdateItem = ((items[i]['modified'] != undefined && items[i].modified) || (items[i]['isEditing'] && items[i].isEditing == true)) ? true : false;
//        var isDeleteItem = (items[i]['removed'] != undefined && items[i].removed) ? true : false;

//        itemUpdated = items[i].data;
//        var newItem = Object.create(modelType);

//        var properties = Object.getOwnPropertyNames(modelType);
//        if (properties != []) {
//            if (isNewItem) {
//                for (var j = 0; j < properties.length; j++) {
//                    var property = properties[j];
//                    if (itemUpdated[property] != undefined) {
//                        newItem[property] = itemUpdated[property]
//                    }
//                }
//                newItem["ActionType"] = ActionTypeEnum.Insert;
//            }
//            else if (isUpdateItem) {
//                for (var j = 0; j < properties.length; j++) {
//                    var property = properties[j];
//                    if (itemUpdated[property] != undefined) {
//                        newItem[property] = itemUpdated[property];
//                    }
//                }
//                newItem["ActionType"] = ActionTypeEnum.Update;
//            } else if (isDeleteItem) {
//                for (var j = 0; j < properties.length; j++) {
//                    var property = properties[j];
//                    if (itemUpdated[property] != undefined) {
//                        newItem[property] = itemUpdated[property];
//                    }
//                }
//                newItem["ActionType"] = ActionTypeEnum.Remove;
//            }
//        }

//        if (isNewItem || isUpdateItem || isDeleteItem) {
//            returnedList.push(newItem);
//        }
//    }

//    return returnedList
//}

var CleanupGridModifiedData = function (id) {
    if ($(id).length == 0) {
        throw "dxDataGrid with id: " + id + " not exists";
    }

    $(id).dxDataGrid("instance").cancelEditData();
}

var ActionTypeEnum = {
    Insert: 0,
    Update: 1,
    Remove: 2
}

var convertFileToBase64 = function (file, callback, ...params) {
    var reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = function () {
        if (callback && typeof callback === "function") {
            callback(reader.result, params);
        }
    };
}

var attachOperationId = function (obj, operationId) {
    if (typeof obj !== 'object' || Array.isArray(obj) || obj == null) {
        throw "Please provide proper object"
    }

    obj.OperationId = operationId;
    return obj;
}

var getMimeTypeByExtension = function (extension) {
    if (!extension) {
        return null;
    }

    switch (extension) {
        case "txt":
            return "data:text/plain;base64,"
        case "png":
            return "data:image/png;base64,"
        case "pdf":
            return "data:application/pdf;base64,"
        case "png":
        case "bmp":
        case "gif":
        case "jpeg":
        case "jpg":
            return "data:image/jpeg;base64,"
        case "csv":
            return "data:text/csv;base64,"
        case "doc":
            return "data:application/msword;base64,"
        case "docx":
            return "data:application/vnd.openxmlformats-officedocument.wordprocessingml.document;base64,"
        case "csv":
            return "data:image/jpeg;base64,"
        case "xls":
            return "data:application/vnd.ms-excel;base64,"
        case "xlsx":
            return "data:application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;base64,"
        default:
            return null;
    }
}


var GetDataGridInstance = function (id) {

    if ($(id).length == 0 || !$(id).dxDataGrid("instance")) {
        throw "Grid with id: " + id + " not exists";
    }

    return $(id).dxDataGrid("instance");
}

var GetTreeInstance = function (id) {

    if ($(id).length == 0 || !$(id).dxTreeList("instance")) {
        throw "TreeList with id: " + id + " not exists";
    }

    return $(id).dxTreeList("instance");
}

var ShowPopup = function (id) {
    if ($(id).length == 0) {
        throw "Popup with id: " + id + " not exists";
    }

    $(id).dxPopup("instance").show();
}


var exportToExcel = function (dataGridElement, denumire) {
    var dataGrid = GetDataGridInstance(dataGridElement);
    var workbook = new ExcelJS.Workbook();// crearea unui obiect Workbook pentru lucrul cu fișierele Excel 
    var worksheet = workbook.addWorksheet(denumire);// adăugarea unei foi de lucru

    DevExpress.excelExporter.exportDataGrid({
        component: dataGrid,
        worksheet: worksheet,
        autoFilterEnabled: true
    }).then(function () {
        return workbook.xlsx.writeBuffer();
    }).then(function (buffer) {
        saveAs(new Blob([buffer], { type: 'application/octet-stream' }), denumire + '.xlsx');
    }).catch(function (error) {
        console.error("Export error: ", error);
    });
};

var exportToPdf = async function (
    dataGridElement,
    denumire,
    orientation = 'landscape',
    pageFormat = 'a4'
) {
    // 1) Load the Base64-encoded Roboto font
    const base64Url = '/fonts/RobotoRegularBase64.txt';
    const response = await fetch(base64Url);
    if (!response.ok) {
        throw new Error('Failed to load the Base64 font file.');
    }
    const base64String = await response.text();

    // 2) Get DevExtreme’s DataGrid instance
    const dxGrid = $(dataGridElement).dxDataGrid('instance');

    // 3) Initialize jsPDF
    const doc = new jsPDF({
        orientation: orientation,
        unit: 'mm',
        format: pageFormat
    });

    doc.addFileToVFS('Roboto-Regular.ttf', base64String);
    doc.addFont('Roboto-Regular.ttf', 'Roboto', 'normal');
    doc.setFont('Roboto');

    // 4) Export with minimal customization
    DevExpress.pdfExporter.exportDataGrid({
        jsPDFDocument: doc,
        component: dxGrid, // pass the DataGrid instance
        topLeft: { x: 5, y: 10 }
    }).then(() => {
        // 6) Finally save the PDF
        doc.save(denumire + '.pdf');
    });
};

var exportTreeToExcel = function (treeListElement, denumire) {
    var treeList = GetTreeInstance(treeListElement);
    var workbook = new ExcelJS.Workbook();// crearea unui obiect Workbook pentru lucrul cu fișierele Excel 
    var worksheet = workbook.addWorksheet(denumire);// adăugarea unei foi de lucru

    exportTreeList({
        component: treeList,
        worksheet,
    }).then(() => {
        workbook.xlsx.writeBuffer().then((buffer) => {
            saveAs(new Blob([buffer], { type: 'application/octet-stream' }), denumire + '.xlsx');
        });
    }).catch(function (error) {
        console.error("Export error: ", error);
    });
};

var exportTreeToPdf = function (treeListElement, denumire) {
    var treeList = GetTreeInstance(treeListElement);
    var doc = new jsPDF();

    DevExpress.pdfExporter.exportDataGrid({
        jsPDFDocument: doc,
        component: treeList,
        indent: 5,
    }).then(function () {
        doc.save(denumire + '.pdf');
    });
};

const getValue = function (object, property) {
    if (object && typeof object === 'object') {
        return object[property] !== undefined ? object[property] : null;
    }
    return null;
}