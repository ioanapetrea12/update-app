﻿var notificariModule = (function () {
    var notificariId = 0;

    const apiRoot = "/Notificari/Notificari";
    const gridId = "#gridNotificari";
    const popupId = "#upsert-notificari-popup";
    const formId = "#upsert-notificari-form";

    var onAddAction = function (args) {
        var popup = $(popupId).dxPopup("instance");
        if (popup !== undefined) {
            popup.option("title", "Adaugare");
        }
        ShowPopup(popupId);
        onClearInfo();
    }

    var onDelete = function (item) {
        var result = DevExpress.ui.dialog.confirm("<p>Sunteti sigur/a ca doriti stergerea elementului selectat?</p>", "Stergere");
        result.done(function (dialogResult) {
            if (dialogResult) {
                ajaxHelper.delete(`${apiRoot}/Delete/${item.row.key}`,
                    function (response) {
                        HideLoading();
                        if (response) {
                            ReloadDataGrid(gridId);
                        } else {
                            ToastShowError("A aparut o eroare la stergerea intrarilor");
                        }
                    },
                    function (err) {
                        ToastShowError("An error occured");
                        HideLoading();
                    });
            }
        })
    }

    var onResetGrid = function () {
        var grid = $(gridId).dxDataGrid("instance");

        grid.state({});
    }
    var onCancel = function () {
        HidePopup(popupId);
    }

    var onHidingPopup = function () {
        global.onHidingUpsertViewPopup(popupId, apiRoot, onClearInfo);
    }

    var onSave = function (item) {
        ShowLoading();

        var frmInstance = $(formId).dxForm("instance");

        if (!frmInstance.validate().isValid) {
            HideLoading();
            ToastShowError("Date Invalide!");
            return;
        }

        var notificariData = frmInstance.option("formData");
        var range = global.getDateRangeValues('#dateRangeBox');

        var postData = {
            Id: notificariId,
            Cod: notificariData.Cod,
            Denumire: notificariData.Denumire,
            IsDefault: notificariData.IsDefault,
            DataStart: moment(range[0]).format("YYYY-MM-DD"),
            DataStop: moment(range[1]).format("YYYY-MM-DD")
        };

        ajaxHelper.post(`${apiRoot}/Upsert`,
            postData,
            function (response) {
                HideLoading();

                if (!response || !response.Success) {
                    ToastShowError(response.Message);
                    return;
                }

                HidePopup(popupId);
                ReloadDataGrid(gridId);
            },
            function (err) {
                ToastShowError(err.Message);
                HideLoading();
            });

        HideLoading();
    }
    var onEdit = function (item) {
        var popup = $(popupId).dxPopup("instance");
        if (popup !== undefined) {
            popup.option("title", "Actualizare");
        }
        ShowLoading();
        onClearInfo();
        notificariId = item.data.Id;
        getData(item.data.Id);
        item.cancel = true;
    }

    var getData = function (id) {

        if (!id || id < 1) {
            ToastShowError("Id invalid!")
            return;
        }

        ajaxHelper.get(`${apiRoot}/GetNotificariDetails?notificariId=${id}`, null,
            function (response) {

                HideLoading();

                if (!response || !response.Success) {
                    ToastShowError(response.Message);
                    return;
                }

                ShowPopup(popupId);
                var frmInstance = $(formId).dxForm("instance");
                if (frmInstance !== undefined) {
                    frmInstance.option("formData", response.Data);

                    global.setDateRangeValues('#dateRangeBox', response.Data.DataStart, response.Data.DataStop);
                }
            },
            function (err) {
                ToastShowError("Au aparut erori la citirea datelor!");
                HideLoading();
            });
    }

    var onClearInfo = function () {
        notificariId = 0;
        var now = new Date();
        global.setDateRangeValues('#dateRangeBox', new Date(now.getFullYear(), 0, 1), new Date(2099, 11, 31),);
    }

    var onRowClick = function (item) {
        notificariId = item.data.Id;
    }

    var onRowPrepared = function (e) {
        if (e.data && e.data.DataOperare === null) {
            e.rowElement.css('font-weight', 'bold'); // Make text bold
        }
    }

    var readNotifications = function (params) {
        var data = params.row.data;
        if (!data) {
            return false;
        }

        ShowLoading();

        var postData = { Id: data.Id };

        ajaxHelper.post(`${apiRoot}/ReadNotification`, postData,
            function (response) {
                if (response && response.Success) {
                    //succes
                    window.location.href = `${apiRoot}/Index`;
                } else {
                    ToastShowError("Date Invalide!");
                }
                HideLoading();
            },
            function () {
                ToastShowError("Au aparut erori la citirea notificarii!");
                HideLoading();
            });
    }

    var disableRead = function (params) {
        var data = params.row.data;
        if (!data) {
            return false;
        }

        return data.DataOperare != null;
    }

    return {
        onAddAction: onAddAction,
        onResetGrid: onResetGrid,
        onDelete: onDelete,
        onCancel: onCancel,
        onSave: onSave,
        onEdit: onEdit,
        onRowClick: onRowClick,
        onRowPrepared: onRowPrepared,
        readNotifications: readNotifications,
        disableRead: disableRead,
        onHidingPopup: onHidingPopup
    }
})();