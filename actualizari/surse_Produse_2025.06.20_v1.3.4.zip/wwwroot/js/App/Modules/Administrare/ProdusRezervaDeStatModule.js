﻿const produsRezModule = (function () {
    var produsRezId = 0;
    var produsIdDetalii = 0;
    var produsDetId = 0;
    var IdParinte = null;
    var produsRezModelData = {};
    var editRowIndex = -1;
    var umIdBaza = 0;

    const apiRoot = "/Administrare/ProdusRezervaDeStat";
    const gridId = "#gridProdusRez";
    const gridDetaliiId = "#treeProdusDet";
    const popupId = "#upsert-produsRez-popup";
    const popupDetaliiId = "#upsert-detaliiprodus-popup";
    const popupDetaliiGridId = "#upsert-detaliigridprodus-popup";
    const formId = "#upsert-produsRez-form";
    const formDetaliiId = "#upsert-detaliiprodus-form";
    const formDetaliiGridId = "#upsert-detaliigridprodus-form";

    var onAddAction = function (args) {
        var popup = $(popupId).dxPopup("instance");
        if (popup != undefined) {
            popup.option("title", "Adăugare");
        }
        ShowPopup(popupId);
        onClearInfo();

        var frmInstance = $(formId).dxForm("instance");
        frmInstance.option("formData", { Stare: 1 });
    }

    var onAddActionDetaliiGrid = function (args) {
        editRowIndex = -1;
        var popup = $(popupDetaliiGridId).dxPopup("instance");
        if (popup != undefined) {
            popup.option("title", "Adăugare detaliu produs");
        }
        ShowPopup(popupDetaliiGridId);
        onClearInfoDetaliiGrid();

        if (args.row?.data?.Id) {
            IdParinte = args.row.data.Id;
        }
    }

    var onDelete = function (item) {
        var result = DevExpress.ui.dialog.confirm("<p>Sunteți sigur/ă ca doriți ștergerea elementului selectat?</p>", "Ștergere");
        result.done(function (dialogResult) {
            if (dialogResult) {
                var postData = {
                    Key: item.row.key
                };
                ajaxHelper.post(`${apiRoot}/Delete`, postData,
                    function (response) {
                        HideLoading();
                        if (response) {
                            if (response.Success == false) {
                                ToastShowError(response.Message);
                                return;
                            }
                            ReloadDataGrid(gridId);
                        } else {
                            ToastShowError("A apărut o eroare la ștergerea intrărilor");
                        }
                    },
                    function (err) {
                        ToastShowError("An error occured");
                        HideLoading();
                    });
            }
        })
    }

    var onDeleteDetaliiGrid = function (item) {
        var gridDetaliiInstance = $(gridDetaliiId).dxTreeList("instance");
        var result = DevExpress.ui.dialog.confirm("<p>Sunteti sigur ca doriti stergerea elementului selectat?</p>", "Stergere");
        result.done(function (dialogResult) {
            deletedRowIndex = item.row.rowIndex;

            if (dialogResult) {
                gridDetaliiInstance.deleteRow(deletedRowIndex);
                gridDetaliiInstance.element().find(".dx-row-removed").hide();
            }
        });
    }

    var collectBatchGridData = function (bReturnAllDataAsNewLines = false) {
        if (!IsTreeListInstance(gridDetaliiId)) {
            return;
        }

        var detaliiProdus = GetModifiedDataFromTree(gridDetaliiId);
        var model = {
            Id: 0,
            Ordine: 0,
            IdParinte: null,
            GrupaProdusId: null,
            ProdusId: null,
            UMIdBaza: 0,
            StocRS: 0,
            StocIntangibil: 0,
            StocUrgenta: 0,
            StocConjunctura: 0,
            StocRezilienta: 0,
            NrLuniImprospatare: 0,
            TotalStoc: 0,
            NomenclatorProdusBaseId: produsRezId
        };

        return CustomCopyTo(model, detaliiProdus, bReturnAllDataAsNewLines);
    }

    var onResetGrid = function () {
        var grid = $(gridId).dxDataGrid("instance");

        grid.state({});
    }

    var onResetDetaliiGrid = function () {
        var tree = $(gridDetaliiId).dxTreeList("instance");

        tree.state({});
    }

    var onCancel = function () {
        HidePopup(popupId);
    }

    var onCancelDetalii = function () {
        HidePopup(popupDetaliiId);
    }

    var onCancelDetaliiGrid = function () {
        HidePopup(popupDetaliiGridId);
    }

    const onHidingPopup = function () {
        global.onHidingUpsertViewPopup(popupId, apiRoot, onClearInfo);
    }

    var onHidingDetaliiPopup = function () {
        onClearInfoDetalii();
        $(popupDetaliiId).dxPopup("dispose");
        $(popupDetaliiId).load(`${apiRoot}/GetPopupViewDetalii`);
    }

    var onHidingDetaliiGridPopup = function () {
        onClearInfoDetaliiGrid();
        $(popupDetaliiGridId).dxPopup("dispose");
        $(popupDetaliiGridId).load(`${apiRoot}/GetPopupViewDetaliiGrid`);
    }

    var onSave = function (item) {
        ShowLoading();

        var frmInstance = $(formId).dxForm("instance");

        if (!frmInstance.validate().isValid) {
            HideLoading();
            ToastShowError("Date Invalide!");
            return;
        }

        const produsData = frmInstance.option("formData");
        var range = global.getDateRangeValues('#dateRangeBox');

        const postData = {
            Id: produsRezId,
            UnitatiId: produsData.UnitatiId,
            Cod: produsData.Cod,
            Denumire: produsData.Denumire,
            Stare: produsData.Stare,
            DataStart: moment(range[0]).format("YYYY-MM-DD"),
            DataStop: moment(range[1]).format("YYYY-MM-DD"),
        };
        console.log(postData);

        ajaxHelper.post(`${apiRoot}/Upsert`,
            postData,
            function (response) {

                console.log(response);

                HideLoading();

                if (!response || !response.Success) {
                    ToastShowError(response.Message);
                    return;
                }

                HidePopup(popupId);
                ReloadDataGrid(gridId);
            },
            function (err) {
                ToastShowError(err.Message);
                HideLoading();
            });

        HideLoading();
    }

    var onSaveDetalii = function (item) {
        ShowLoading();

        var frmInstance = $(formDetaliiId).dxForm("instance");

        if (!frmInstance.validate().isValid) {
            HideLoading();
            ToastShowError("Date Invalide!");
            return;
        }

        var produsData = frmInstance.option("formData");
        var detaliiProdus = collectBatchGridData();
        var range = global.getDateRangeValues('#dateRangeBox');

        var postData = {
            Id: produsRezId,
            UnitatiId: produsData.UnitatiId,
            Cod: produsData.Cod,
            Denumire: produsData.Denumire,
            Stare: produsData.Stare,
            DataStart: moment(range[0]).format("YYYY-MM-DD"),
            DataStop: moment(range[1]).format("YYYY-MM-DD"),
            DetaliiProdus: detaliiProdus
        };

        console.log(postData);

        ajaxHelper.post(`${apiRoot}/Upsert`,
            postData,
            function (response) {
                HideLoading();

                if (!response || !response.Success) {
                    ToastShowError(response.Message);
                    return;
                }

                HidePopup(popupDetaliiId);
                ReloadDataGrid(gridId);
            },
            function (err) {
                ToastShowError(err.Message);
                HideLoading();
            });

        HideLoading();
    }


    var onSaveDetaliiGrid = function (item) {
        var frmDetaliiGridInstance = $(formDetaliiGridId).dxForm("instance");

        if (!frmDetaliiGridInstance.validate().isValid) {
            ToastShowError("Date Invalide!")
            return;
        }

        if (IdParinte === 0 || IdParinte === null) {
            IdParinte = undefined;
        }

        let dataGrid = $(gridDetaliiId).dxTreeList("instance");
        let formData = frmDetaliiGridInstance.option("formData");
        if (editRowIndex >= 0) {
            dataGrid.cellValue(editRowIndex, "IdParinte", IdParinte);
            dataGrid.cellValue(editRowIndex, "ProdusId", formData.ProdusId);
            dataGrid.cellValue(editRowIndex, "UMIdBaza", formData.UMIdBaza);
            dataGrid.cellValue(editRowIndex, "Ordine", formData.Ordine ?? 0);
            dataGrid.cellValue(editRowIndex, "GrupaProdusId", formData.GrupaProdusId ?? 0);
            dataGrid.cellValue(editRowIndex, "StocRS", formData.StocRS ?? 0);
            dataGrid.cellValue(editRowIndex, "StocIntangibil", formData.StocIntangibil ?? 0);
            dataGrid.cellValue(editRowIndex, "StocUrgenta", formData.StocUrgenta ?? 0);
            dataGrid.cellValue(editRowIndex, "StocConjunctura", formData.StocConjunctura ?? 0);
            dataGrid.cellValue(editRowIndex, "StocRezilienta", formData.StocRezilienta ?? 0);
            dataGrid.cellValue(editRowIndex, "TotalStoc", formData.TotalStoc ?? 0);
            dataGrid.cellValue(editRowIndex, "NrLuniImprospatare", formData.NrLuniImprospatare ?? 0);
            dataGrid.cellValue(editRowIndex, "NomenclatorProdusBaseId", produsRezId);
        } else {
            dataGrid.on("initNewRow", function (e) {
                e.data["IdParinte"] = IdParinte;
                e.data["ProdusId"] = formData.ProdusId;
                e.data["UMIdBaza"] = formData.UMIdBaza;
                e.data["Ordine"] = formData.Ordine ?? 0;
                e.data["GrupaProdusId"] = formData.GrupaProdusId;
                e.data["StocRS"] = formData.StocRS ?? 0;
                e.data["StocIntangibil"] = formData.StocIntangibil ?? 0;
                e.data["StocUrgenta"] = formData.StocUrgenta ?? 0;
                e.data["StocConjunctura"] = formData.StocConjunctura ?? 0;
                e.data["StocRezilienta"] = formData.StocRezilienta ?? 0;
                e.data["TotalStoc"] = formData.TotalStoc ?? 0;
                e.data["NrLuniImprospatare"] = formData.NrLuniImprospatare ?? 0;
                e.data["NomenclatorProdusBaseId"] = produsRezId;
            });

            dataGrid.beginUpdate();
            dataGrid.addRow();
            dataGrid.endUpdate();
            dataGrid.endCustomLoading();
            dataGrid.off("initNewRow");
        }

        HidePopup(popupDetaliiGridId);
    }

    var onEdit = function (item) {
        var popup = $(popupId).dxPopup("instance");
        if (popup != undefined) {
            popup.option("title", "Actualizare");
        }
        ShowLoading();
        onClearInfo();
        produsRezId = item.data.Id;
        getData(produsRezId, popupId, formId);
        item.cancel = true;
    }

    var onEditDetalii = function (item) {
        var popup = $(popupDetaliiId).dxPopup("instance");
        if (popup != undefined) {
            popup.option("title", "Actualizare detalii");
        }
        ShowLoading();
        onClearInfo();
        produsRezId = item.row?.data.Id;
        getData(produsRezId, popupDetaliiId, formDetaliiId);
        item.cancel = true;
    }

    var onEditDetaliiGrid = function (item) {
        var popup = $(popupDetaliiGridId).dxPopup("instance");
        if (popup != undefined) {
            popup.option("title", "Actualizare detalii");
        }

        produsDetId = item.row?.data.Id;
        IdParinte = item.row?.data.IdParinte;

        editRowIndex = item.row?.rowIndex;
        var clonedData = Object.assign({}, item.row?.data);
        item.event.preventDefault();

        ShowPopup(popupDetaliiGridId);
        var frmDetaliiGridInstance = $(formDetaliiGridId).dxForm("instance");
        frmDetaliiGridInstance.option("formData", clonedData);
    }

    var onProdusChanged = function (args) {
        let produsId = 0;

        if (args.component.clickedRowData !== null && args.component.clickedRowData !== undefined) {
            produsId = args.component.clickedRowData.Id;
            umIdBaza = args.component.clickedRowData.UMIdBaza;
        }
        //pentru situatia in care se schimba valoarea din cod si nu de catre utilizator
        else if (args.value !== 0) {
            partenerId = args.value;
        }

        var umIdBazaDropDown = $("#UMIdBaza").dxDropDownBox("instance");
        //setam valorea UMIdBaza in dropdown
        umIdBazaDropDown.option('value', umIdBaza);
    }

    var getData = function (id, popupId, formId) {

        if (!id || id < 1) {
            ToastShowError("Id invalid!")
            return;
        }


        ajaxHelper.get(`${apiRoot}/GetProdusRezervaDeStatDetails?produsRezId=${id}`, null,
            function (response) {

                HideLoading();

                 console.log(response);

                if (!response || !response.Success) {
                    ToastShowError(response.Message);
                    return;
                }

                ShowPopup(popupId);
                var frmInstance = $(formId).dxForm("instance");
                if (frmInstance != undefined) {
                    produsRezModelData = response.Data;
                    frmInstance.option("formData", produsRezModelData);

                    //for daterange
                    global.setDateRangeValues('#dateRangeBox', produsRezModelData.DataStart, produsRezModelData.DataStop);
                }
            },
            function (err) {
                ToastShowError("Au aparut erori la citirea datelor!");
                HideLoading();
            });
    }

    const getNomenclatorProdusBaseId = function () {
        return produsDetId;
    }

    var onClearInfo = function () {
        produsRezId = 0;
        produsRezModelData = null;
    }

    var onClearInfoDetalii = function () {
        produsIdDetalii = 0; 
    }

    var onClearInfoDetaliiGrid = function () {
        produsDetId = 0;
        IdParinte = null;
    }

    var onRowClick = function (item) {
        produsRezId = item.data.Id;
    }

    var onRowClickDetaliiGrid = function (item) {
        produsDetId = item.data.Id;
    }

    var getDetaliiGridParam = function (operation, ajaxSettings) {
        if (operation == "load") {
            ajaxSettings.data.produsRezId = produsRezId;
        }
    }

    return {
        onAddAction: onAddAction,
        onResetGrid: onResetGrid,
        onDelete: onDelete,
        onCancel: onCancel,
        onSave: onSave,
        onEdit: onEdit,
        onEditDetalii: onEditDetalii,
        onEditDetaliiGrid: onEditDetaliiGrid,
        onRowClick: onRowClick,
        onHidingPopup: onHidingPopup,
        onAddActionDetaliiGrid: onAddActionDetaliiGrid,
        onDeleteDetaliiGrid: onDeleteDetaliiGrid,
        collectBatchGridData: collectBatchGridData,
        onResetDetaliiGrid: onResetDetaliiGrid,
        onCancelDetalii: onCancelDetalii,
        onCancelDetaliiGrid: onCancelDetaliiGrid,
        onHidingDetaliiPopup: onHidingDetaliiPopup,
        onHidingDetaliiGridPopup: onHidingDetaliiGridPopup,
        onSaveDetalii: onSaveDetalii,
        onSaveDetaliiGrid: onSaveDetaliiGrid,
        onProdusChanged: onProdusChanged,
        onRowClickDetaliiGrid: onRowClickDetaliiGrid,
        getNomenclatorProdusBaseId: getNomenclatorProdusBaseId,
        getDetaliiGridParam: getDetaliiGridParam
    }
})();