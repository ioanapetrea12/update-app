﻿var articolModule = (function () {
    var articolId = null;
    var parinteArticolId = null;
    var articolModelData = {};


    const apiRoot = "/Administrare/Articol";
    const popupId = "#upsert-articol-popup";
    const formId = "#upsert-articol-form";
    const treeId = "#treeArticol";

    var onAddAction = function (args) {
        var popup = $(popupId).dxPopup("instance");
        if (popup != undefined) {
            popup.option("title", "Adaugare");
        }
        ShowPopup(popupId);
        onClearInfo();

        if (args.row?.data?.Id) {
            parinteArticolId = args.row.data.Id;

            var parentCod = args.row.data.Cod;

            var frmInstance = $(formId).dxForm("instance");
            frmInstance.option("formData", { Cod: parentCod });
        }
    }

    var onDelete = function (item) {
        var result = DevExpress.ui.dialog.confirm("<p>Sunteti sigur/ă că doriți ștergerea elementului selectat?</p>", "Ștergere");
        result.done(function (dialogResult) {
            if (dialogResult) {
                var postData = {
                    Key: item.row.key
                };
                ajaxHelper.post(`${apiRoot}/Delete`, postData,
                    function (response) {
                        HideLoading();
                        if (response) {
                            if (response.Success == false) {
                                ToastShowError(response.Message);
                                return;
                            }
                            ReloadTreeList(treeId);
                        } else {
                            ToastShowError("A apărut o eroare la ștergerea intrărilor");
                        }
                    },
                    function (err) {
                        ToastShowError("An error occured");
                        HideLoading();
                    });
            }
        })
    }

    var onResetGrid = function () {
        var tree = $(treeId).dxTreeList("instance");

        tree.state({});
    }
    var onCancel = function () {
        onClearInfo();
        HidePopup(popupId);
    }

    var onHidingPopup = function () {
        global.onHidingUpsertViewPopup(popupId, apiRoot, onClearInfo);
    }

    var onSave = function (item) {
        ShowLoading();

        var frmInstance = $(formId).dxForm("instance");

        if (!frmInstance.validate().isValid) {
            HideLoading();
            ToastShowError("Date Invalide!");
            return;
        }

        var articolData = frmInstance.option("formData");
        var range = global.getDateRangeValues('#dateRangeBox');

        var postData = {
            Id: articolId,
            Idparinte: parinteArticolId,
            Cod: articolData.Cod,
            CodForexebug: articolData.CodForexebug,
            Denumire: articolData.Denumire,
            TipSectiune: articolData.TipSectiune,
            EsteTotal: articolData.EsteTotal,
            Ordine: articolData.Ordine,
            DataStart: moment(range[0]).format("YYYY-MM-DD"),
            DataStop: moment(range[1]).format("YYYY-MM-DD"),
            Titlu: articolModelData.titlu,
            Articol: articolModelData.articol,
            Alineat: articolModelData.alineat
        };

        ajaxHelper.post(`${apiRoot}/Upsert`,
            postData,
            function (response) {
                HideLoading();

                if (!response || !response.Success) {
                    ToastShowError(response.Message);
                    return;
                }

                HidePopup(popupId);
                ReloadTreeList(treeId);
            },
            function (err) {
                ToastShowError(err.Message);
                HideLoading();
            });

        HideLoading();
    }
    var onEdit = function (item) {
        var popup = $(popupId).dxPopup("instance");
        if (popup != undefined) {
            popup.option("title", "Actualizare");
        }
        ShowLoading();
        onClearInfo();
        articolId = item.row?.data.Id;
        parinteArticolId = item.row?.data.Idparinte;
        getData(articolId);
        item.cancel = true;
    }

    var getData = function (id) {

        if (!id || id < 1) {
            ToastShowError("Id invalid!")
            return;
        }


        ajaxHelper.get(`${apiRoot}/GetArticolDetails?articolId=${id}`, null,
            function (response) {

                HideLoading();

                console.log(response);

                if (!response || !response.Success) {
                    ToastShowError(response.Message);
                    return;
                }

                ShowPopup(popupId);
                var frmInstance = $(formId).dxForm("instance");
                if (frmInstance != undefined) {
                    articolModelData = response.Data;
                    frmInstance.option("formData", articolModelData);

                    //for daterange
                    global.setDateRangeValues('#dateRangeBox', articolModelData.DataStart, articolModelData.DataStop);
                }
            },
            function (err) {
                ToastShowError("Au aparut erori la citirea datelor!");
                HideLoading();
            });
    }

    var onClearInfo = function () {
        articolId = null;
        parinteArticolId = null;
        articolModelData = null;

        var now = new Date();
        global.setDateRangeValues('#dateRangeBox', new Date(now.getFullYear(), 0, 1), new Date(2099, 11, 31),);
    }

    var onRowClick = function (item) {
        articolId = item.data.Id;
    }

    var showAction = function (params) {
        var data = params.row.data;
        if (!data) {
            return false;
        }

        return true;
    }

    const onCodTextChanged = function (args) {
        if (args.event !== null && args.event !== undefined && args.event.type == 'change') {
            var result = extractAndSeparate(args.value);
            var txtCodForexebug = $('#txtCodForexebug').dxTextBox('instance');
            txtCodForexebug.option('value', result.concatenated);

            if (articolModelData === null) {
                articolModelData = {};
            }
            articolModelData.titlu = result.part1;
            articolModelData.articol = result.part2;
            articolModelData.alineat = result.part3;
            SetPossibleOrder(args.value);
        }
    }
    function extractAndSeparate(inputString) {
        // Remove dots from the string
        let cleanString = inputString.replace(/\./g, "");

        // Extract the parts
        let part1 = cleanString.slice(0, 2).padEnd(2, "0");  // First 2 characters
        let part2 = cleanString.slice(2, 4).padEnd(2, "0");  // Next 2 characters
        let part3 = cleanString.slice(4, 6).padEnd(2, "0");  // Next 2 characters

        // Concatenate the parts
        let concatenated = part1 + part2 + part3;

        return {
            part1: part1,
            part2: part2,
            part3: part3,
            concatenated: concatenated
        };
    }
    function SetPossibleOrder(cod) {
        if (parinteArticolId === null || parinteArticolId === undefined)
            parinteArticolId = 0;

        ajaxHelper.get(`${apiRoot}/GetPossibleOrder?parentId=${parinteArticolId}&cod=${cod}`, null,
            function (response) {
                HideLoading();
                if (!response) {
                    return;
                }

                var txtOrdine = $('#txtOrdine').dxTextBox('instance');
                txtOrdine.option('value', response.Ordine);
            },
            function (err) {
                ToastShowError("Au aparut erori la citirea datelor!");
                HideLoading();
            });
    }

    return {
        onAddAction: onAddAction,
        onResetGrid: onResetGrid,
        onDelete: onDelete,
        onCancel: onCancel,
        onSave: onSave,
        onEdit: onEdit,
        onRowClick: onRowClick,
        showAction: showAction,
        onHidingPopup: onHidingPopup,
        onCodTextChanged: onCodTextChanged
    }
})();