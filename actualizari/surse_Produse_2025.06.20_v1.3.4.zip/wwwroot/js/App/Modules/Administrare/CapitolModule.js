﻿var capitolModule = (function () {
    var capitolId = null;
    var parinteCapitolId = null;
    var capitolData = {};


    const apiRoot = "/Administrare/Capitol";
    const popupId = "#upsert-capitol-popup";
    const formId = "#upsert-capitol-form";
    const treeId = "#treeCapitol";

    var onAddAction = function (args) {
        var popup = $(popupId).dxPopup("instance");
        if (popup != undefined) {
            popup.option("title", "Adaugare");
        }
        ShowPopup(popupId);
        onClearInfo();

        if (args.row?.data?.Id) {
            parinteCapitolId = args.row.data.Id;

            var parentCod = args.row.data.Cod;

            var frmInstance = $(formId).dxForm("instance");
            frmInstance.option("formData", { Cod: parentCod });

        }
    }

    var onDelete = function (item) {
        var result = DevExpress.ui.dialog.confirm("<p>Sunteti sigur/ă că doriți ștergerea elementului selectat?</p>", "Ștergere");
        result.done(function (dialogResult) {
            if (dialogResult) {
                ajaxHelper.delete(`${apiRoot}/Delete/${item.row.key}`,
                    function (response) {
                        HideLoading();
                        if (response) {
                            if (response.Success == false) {
                                ToastShowError(response.Message);
                                return;
                            }
                            ReloadTreeList(treeId);
                        } else {
                            ToastShowError("A apărut o eroare la ștergerea intrărilor");
                        }
                    },
                    function (err) {
                        ToastShowError("An error occured");
                        HideLoading();
                    });
            }
        })
    }

    var onResetGrid = function () {
        var tree = $(treeId).dxTreeList("instance");

        tree.state({});
    }
    var onCancel = function () {
        onClearInfo();
        HidePopup(popupId);
    }

    var onHidingPopup = function () {
        global.onHidingUpsertViewPopup(popupId, apiRoot, onClearInfo);
    }

    var onSave = function (item) {
        ShowLoading();

        var frmInstance = $(formId).dxForm("instance");

        if (!frmInstance.validate().isValid) {
            HideLoading();
            ToastShowError("Date Invalide!");
            return;
        }

        var capitolData = frmInstance.option("formData");
        var range = global.getDateRangeValues('#dateRangeBox');

        var postData = {
            Id: capitolId,
            Idparinte: parinteCapitolId,
            Cod: capitolData.Cod,
            CodForexebug: capitolData.CodForexebug,
            Denumire: capitolData.Denumire,
            TipSectiune: capitolData.TipSectiune,
            EsteTotal: capitolData.EsteTotal,
            EsteVenit: capitolData.EsteVenit,
            TipBugetId: capitolData.TipBugetId,
            Ordine: capitolData.Ordine,
            DataStart: moment(range[0]).format("YYYY-MM-DD"),
            DataStop: moment(range[1]).format("YYYY-MM-DD")
        };
        console.log(postData);

        ajaxHelper.post(`${apiRoot}/Upsert`,
            postData,
            function (response) {
                HideLoading();

                if (!response || !response.Success) {
                    ToastShowError(response.Message);
                    return;
                }

                HidePopup(popupId);
                ReloadTreeList(treeId);
            },
            function (err) {
                ToastShowError(err.Message);
                HideLoading();
            });

        HideLoading();
    }
    var onEdit = function (item) {
        var popup = $(popupId).dxPopup("instance");
        if (popup != undefined) {
            popup.option("title", "Actualizare");
        }
        ShowLoading();
        onClearInfo();
        capitolId = item.row?.data.Id;
        parinteCapitolId = item.row?.data.Idparinte;
        getData(capitolId);
        item.cancel = true;
    }

    var getData = function (id) {

        if (!id || id < 1) {
            ToastShowError("Id invalid!")
            return;
        }


        ajaxHelper.get(`${apiRoot}/GetCapitolDetails?capitolId=${id}`, null,
            function (response) {

                HideLoading();

                console.log(response);

                if (!response || !response.Success) {
                    ToastShowError(response.Message);
                    return;
                }

                ShowPopup(popupId);
                var frmInstance = $(formId).dxForm("instance");
                if (frmInstance != undefined) {
                    capitolModelData = response.Data;
                    frmInstance.option("formData", capitolModelData);

                    //for daterange
                    global.setDateRangeValues('#dateRangeBox', capitolModelData.DataStart, capitolModelData.DataStop);
                }
            },
            function (err) {
                ToastShowError("Au aparut erori la citirea datelor!");
                HideLoading();
            });
    }

    var onClearInfo = function () {
        capitolId = null;
        parinteCapitolId = null;
        capitolModelData = null;

        var now = new Date();
        global.setDateRangeValues('#dateRangeBox', new Date(now.getFullYear(), 0, 1), new Date(2099, 11, 31),);
    }

    var onRowClick = function (item) {
        capitolId = item.data.Id;
    }

    var showAction = function (params) {
        var data = params.row.data;
        if (!data) {
            return false;
        }

        return true;
    }
    const onCodTextChanged = function (args) {
        if (args.event !== null && args.event !== undefined && args.event.type == 'change') {
            var firstChar = args.value.charAt(0);

            // Convert the first character to a number
            var firstNumber = parseInt(firstChar, 10);

            // Check if the result is a valid number
            if (!isNaN(firstNumber)) {
                var comboInstance = $('#sbTipCapitol').dxSelectBox('instance');
                comboInstance.option('value', firstNumber >= 5);
            }

            var result = extractAndFormat(args.value);
            var txtCodForexebug = $('#txtCodForexebug').dxTextBox('instance');
            txtCodForexebug.option('value', result);

            SetPossibleOrder(args.value);
        }
    }
    function extractAndFormat(inputString) {
        // Remove dots from the string
        let cleanString = inputString.replace(/\./g, "");

        // Extract the parts
        let concatenated = cleanString.slice(0, 6).padStart(6, "0");
        return concatenated;
    }

    function SetPossibleOrder(cod) {
        if (parinteCapitolId === null || parinteCapitolId === undefined)
            parinteCapitolId = 0;

        ajaxHelper.get(`${apiRoot}/GetPossibleOrder?parentId=${parinteCapitolId}&cod=${cod}`, null,
            function (response) {
                HideLoading();
                if (!response) {
                    return;
                }

                var txtOrdine = $('#txtOrdine').dxTextBox('instance');
                txtOrdine.option('value', response.Ordine);
            },
            function (err) {
                ToastShowError("Au aparut erori la citirea datelor!");
                HideLoading();
            });
    }


    return {
        onAddAction: onAddAction,
        onResetGrid: onResetGrid,
        onDelete: onDelete,
        onCancel: onCancel,
        onSave: onSave,
        onEdit: onEdit,
        onRowClick: onRowClick,
        showAction: showAction,
        onHidingPopup: onHidingPopup,
        onCodTextChanged: onCodTextChanged
    }
})();