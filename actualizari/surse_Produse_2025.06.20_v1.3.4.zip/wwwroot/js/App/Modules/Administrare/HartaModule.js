﻿const hartaModule = (function () {

    const apiRoot = "/Administrare/Harta";
    var map;
    const feature1Layer = L.layerGroup();
    const feature2Layer = L.layerGroup();
    const overlayMaps = {
        Layer: feature1Layer
    };

    var unitateId = null;
    var tipLocDepozitareId = null;

    const onUnitateChanged = function (e) {
        if (e.value) {
            unitateId = e.value;
        }
    };

    const onTipLocDepozitareChanged = function (e) {
        if (e.value) {
            tipLocDepozitareId = e.value;
        }
    };

    const initMap = function () {
        map = L.map("map").setView([47.1693556, 27.5816653], 13);
        L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png").addTo(map);
        L.control.layers(null, overlayMaps).addTo(map);
    };

    const onResetFilters = function () {
        unitateId = null;
        tipLocDepozitareId = null;

        $("#unitatiDropDownId").dxDropDownBox("instance").option("value", null);
        $("#tipLocDepozitareId").dxDropDownBox("instance").option("value", null);
        $("#ProdusTextBoxID").dxTextBox("instance").option("value", "");
        $('#details').html('');

        loadData();
    };


    const loadData = function () {
        ShowLoading();
        produs = $("#ProdusTextBoxID").dxTextBox("instance").option("value");

        ajaxHelper.get(`${apiRoot}/GetHartaData?unitateId=${unitateId}&tipLocDepozitareId=${tipLocDepozitareId}&produs=${produs}`, null,
            function (response) {
                if (!response || !response.Success) {
                    ToastShowError(response.Message);
                    return;
                }

                feature1Layer.clearLayers();

                response.Data.forEach((item) => {
                    const popupContent = `<h2>${item.Denumire}</h2></br><button
                        onclick="hartaModule.showDetails('${item.GestiuneTipLocDepozitareId}')"
                        "${item.Icon}">Detalii</button>`;
                    $('#details').html('');

                    var icon1 = L.icon({
                        iconUrl: '/images/icons/depozit.png',
                        iconSize: [38, 38],
                        iconAnchor: [19, 38],
                        popupAnchor: [0, -38],

                    });

                    var icon2 = L.icon({
                        iconUrl: '/images/icons/siloz.png',
                        iconSize: [38, 38],
                        iconAnchor: [19, 38],
                        popupAnchor: [0, -38],
                    });

                    var icon3 = L.icon({
                        iconUrl: '/images/icons/platforma.png',
                        iconSize: [38, 38],
                        iconAnchor: [19, 38],
                        popupAnchor: [0, -38],
                    });

                    if (item.Icon === "Icon1") {
                        L.marker([item.Lat, item.Long], { icon: icon1 }).addTo(feature1Layer).bindPopup(popupContent);
                    }
                    else if (item.Icon === "Icon2") {
                        L.marker([item.Lat, item.Long], { icon: icon2 }).addTo(feature1Layer).bindPopup(popupContent);
                    } else if (item.Icon === "Icon3") {
                        L.marker([item.Lat, item.Long], { icon: icon3 }).addTo(feature1Layer).bindPopup(popupContent);
                    } else {
                        L.marker([item.Lat, item.Long]).addTo(feature1Layer).bindPopup(popupContent);
                    }
                });

                var firstItem = response.Data[0];
                if (firstItem) {
                    map.flyTo([firstItem.Lat, firstItem.Long]);
                }

                feature1Layer.addTo(map);
                HideLoading();
            },
            function (err) {
                ToastShowError(err.Message || "Au aparut erori la transmiterea documentului!");
                HideLoading();
                return;
            });
    }

    const showDetails = function (id) {
        ShowLoading();
        ajaxHelper.get(`${apiRoot}/GetHartaDetails?gestiuneTipLocDepozitareId=${id}`, null,
            function (response) {
                if (!response || !response.Success) {
                    ToastShowError(response.Message);
                    return;
                }

                let detailsContent = '';

                response.Data.forEach(item => {
                    detailsContent += `
                    <p style="margin: 5px 0;"><strong><i>Produs:</i></strong>  ${item.DenumireProdus}   <strong><i>Unitate de masura de baza:</i></strong>  ${item.UMBaza}   <strong><i>Unitate de masura echivalenta:</i></strong>  ${item.UMEchivalent}   <strong><i>Stoc:</i></strong>  ${item.Stoc}   <strong><i>Volum:</i></strong>  ${item.Volum}</p>
                `;
                });
               
                $('#details').html(detailsContent);
                HideLoading();
            },
            function (err) {
                ToastShowError(err.Message || "Au aparut erori la transmiterea documentului!");
                HideLoading();
                return;
            });
    };

    return {
        initMap: initMap,
        loadData: loadData,
        showDetails: showDetails,
        onUnitateChanged: onUnitateChanged,
        onTipLocDepozitareChanged: onTipLocDepozitareChanged,
        onResetFilters: onResetFilters
    };
})();

$(document).ready(function () {
    hartaModule.initMap();
    hartaModule.loadData();
});