﻿const auditLogModule = (function () {
    var auditLogId = 0;
    var auditLogModelData = {};

    const apiRoot = "/Administrare/AuditLog";
    const gridId = "#gridAuditLog";

    var onResetGrid = function () {
        var grid = $(gridId).dxDataGrid("instance");

        grid.state({});
    }

    var onRowClick = function (item) {
        auditLogId = item.data.Id;
    }

    return {
        onResetGrid: onResetGrid,
        onRowClick: onRowClick
    }
})();