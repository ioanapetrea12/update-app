﻿const produsRezUtModule = (function () {
    var produsRezDetUtId = 0
    var nomenclatorDetId = 0;
    var produsRezDetDetaliiId = 0;
    var dataStart = null;
    var dataStop = null;

    var produsRezUtModelData = {};
    var editRowIndex = -1;

    const apiRoot = "/Administrare/ProdusRezervaDeStatUT";
    const gridId = "#gridProdusRezUt";
    const gridDetaliiId = "#gridProdusRezDetUt";
    const popupId = "#upsert-produsRezUt-popup";
    const popupDetaliiGridId = "#upsert-detaliiprodusRezUt-popup";
    const formId = "#upsert-produsRezUt-form";
    const formDetaliiGridId = "#upsert-detaliigridprodusUt-form";

    var onAddAction = function (args) {
        var popup = $(popupId).dxPopup("instance");
        if (popup != undefined) {
            popup.option("title", "Adăugare");
        }
        ShowPopup(popupId);
        onClearInfo();

        // Set the NomenclatorProdusDetId to read/write when adding
        var dropDownNomenclatorProdusDetInstance = $("#NomenclatorProdusDetId").dxDropDownBox("instance");
        if (dropDownNomenclatorProdusDetInstance) {
            dropDownNomenclatorProdusDetInstance.option("readOnly", false);
        } else {
            console.error("DropDownBox instance NomenclatorProdusDetId not found at the time of execution.");
        }
    }

    var onAddActionDetaliiGrid = function (args) {
        editRowIndex = -1;
        var popup = $(popupDetaliiGridId).dxPopup("instance");
        if (popup != undefined) {
            popup.option("title", "Adăugare detaliu produs");
        }
        ShowPopup(popupDetaliiGridId);
        onClearInfoDetaliiGrid();

        dataStart = dataStart ? moment(dataStart).format("YYYY-MM-DD") : moment().startOf('year').format("YYYY-MM-DD");
        dataStop = dataStop ? moment(dataStop).format("YYYY-MM-DD") : moment().endOf('year').format("YYYY-MM-DD");

        //precompletăm formularul pentru DataStart și DataStop cu valori salvate
        var dateBoxDataStartInstance = $("#DataStart").dxDateBox("instance");
        if (dateBoxDataStartInstance) {
            dateBoxDataStartInstance.option("value", dataStart);

        } else {
            console.error("DateBox instance DataStart not found at the time of execution.");
        }

        var dateBoxDataStopInstance = $("#DataStop").dxDateBox("instance");
        if (dateBoxDataStopInstance) {
            dateBoxDataStopInstance.option("value", dataStop);
        } else {
            console.error("DateBox instance DataStop not found at the time of execution.");
        }
    }

    var onDelete = function (item) {
        var result = DevExpress.ui.dialog.confirm("<p>Sunteți sigur/ă ca doriți ștergerea elementului selectat?</p>", "Ștergere");
        result.done(function (dialogResult) {
            if (dialogResult) {
                var postData = {
                    Key: item.row.key
                };
                ajaxHelper.post(`${apiRoot}/Delete`, postData,
                    function (response) {
                        HideLoading();
                        if (response) {
                            if (response.Success == false) {
                                ToastShowError(response.Message);
                                return;
                            }
                            ReloadDataGrid(gridId);
                        } else {
                            ToastShowError("A apărut o eroare la ștergerea intrărilor");
                        }
                    },
                    function (err) {
                        ToastShowError("An error occured");
                        HideLoading();
                    });
            }
        })
    }

    var onDeleteDetaliiGrid = function (item) {
        var gridDetaliiInstance = $(gridDetaliiId).dxDataGrid("instance");
        var result = DevExpress.ui.dialog.confirm("<p>Sunteti sigur ca doriti stergerea elementului selectat?</p>", "Stergere");
        result.done(function (dialogResult) {
            deletedRowIndex = item.row.rowIndex;

            if (dialogResult) {
                gridDetaliiInstance.deleteRow(deletedRowIndex);
                gridDetaliiInstance.element().find(".dx-row-removed").hide();
            }
        });
    }

    var collectBatchGridData = function (bReturnAllDataAsNewLines = false) {
        if (!IsDataGridInstance(gridDetaliiId)) {
            return;
        }

        var detaliiProdus = GetModifiedDataFromGrid(gridDetaliiId);
        var model = {
            Id: 0,
            UnitatiId: null,
            StocRs: 0,
            StocIntangibil: 0,
            StocUrgenta: 0,
            StocConjunctura: 0,
            StocRezilienta: 0,
            NomenclatorDetId: nomenclatorDetId,
            DataStart: null,
            DataStop: null
        };

        return CustomCopyTo(model, detaliiProdus, bReturnAllDataAsNewLines);
    }

    const onResetGrid = function () {
        var grid = $(gridId).dxDataGrid("instance");

        grid.state({});
    }

    const onResetDetaliiGrid = function () {
        var grid = $(gridDetaliiId).dxDataGrid("instance");

        grid.state({});
    }

    const onCancel = function () {
        HidePopup(popupId);
    }

    const onCancelDetaliiGrid = function () {
        HidePopup(popupDetaliiGridId);
    }

    const onHidingPopup = function () {
        global.onHidingUpsertViewPopup(popupId, apiRoot, onClearInfo);
    }

    const getMergedGridData = function (gridId, collectBatchFn) {
        const grid = $(gridId).dxDataGrid("instance");
        if (!grid) throw new Error(`Grid "${gridId}" not found`);

        const ds = grid.getDataSource();
        const storeKey = ds.store().key();                             // e.g. "Id"
        const keyExpr = Array.isArray(storeKey) ? storeKey[0] : storeKey;

        // 1) Clone whatever the DataSource has loaded
        const rawItems = ds.items().map(item => ({ ...item }));

        // 2) Grab your diffs: [{ ActionType:0|1|2, Id, …fields }]
        const diffs = collectBatchFn();

        // 3) Replay each diff:
        diffs.forEach(diff => {
            const id = diff[keyExpr];
            const idx = rawItems.findIndex(r => r[keyExpr] === id);

            switch (diff.ActionType) {
                case 0: // Insert
                    rawItems.push(diff);
                    break;

                case 1: // Update
                    if (idx >= 0) {
                        rawItems[idx] = { ...rawItems[idx], ...diff };
                    } else {
                        rawItems.push(diff);
                    }
                    break;

                case 2: // Remove
                    if (idx >= 0) {
                        rawItems.splice(idx, 1);
                    }
                    break;
            }
        });

        return rawItems;
    }

    const onHidingDetaliiGridPopup = function () {
        onClearInfoDetaliiGrid();
        $(popupDetaliiGridId).dxPopup("dispose");
        $(popupDetaliiGridId).load(`${apiRoot}/GetPopupViewDetaliiGrid`);
    }

    const onEditorPreparingDetaliiGrid = function(e) {
        if (e.parentType === 'dataRow') {
            const orig = e.editorOptions.onValueChanged;
            e.editorOptions.onValueChanged = function (args) {
                // let DevExtreme finish applying the edit first
                if (orig) orig.apply(this, arguments);
                setTimeout(() => {
                    e.component.refresh();    // repaint grid & summary row
                }, 0);
            };
        }
    }

    const onSave = function (item) {
        ShowLoading();

        var frmInstance = $(formId).dxForm("instance");

        if (!frmInstance.validate().isValid) {
            HideLoading();
            ToastShowError("Date Invalide!");
            return;
        }

        const produsData = frmInstance.option("formData");

        // — VALIDATE against *all* rows, skipping any ActionType=2 deletes —
        const allRows = getMergedGridData(gridDetaliiId, collectBatchGridData);

        // calculam toatalurile stocurilor din grid
        const totals = allRows.reduce((acc, row) => {
            if (row.ActionType === 2) return acc;  // skip deletes
            acc.StocRs += row.StocRs ?? 0;
            acc.StocIntangibil += row.StocIntangibil ?? 0;
            acc.StocUrgenta += row.StocUrgenta ?? 0;
            acc.StocConjunctura += row.StocConjunctura ?? 0;
            acc.StocRezilienta += row.StocRezilienta ?? 0;
            return acc;
        }, {
            StocRs: 0,
            StocIntangibil: 0,
            StocUrgenta: 0,
            StocConjunctura: 0,
            StocRezilienta: 0
        });

        //validam valorile totalurilor stocurilor introduse in grid: trebuie sa fie egale cu cele ale stocurilor din tabela tblNomenclatorProdusDet
        if (produsData.StocRsBase !== totals.StocRs) {
            HideLoading();
            ToastShowError("Totalul stocurilor din lista nu este egal cu valoarea stocului de baza!");
            return;
        }
        if (produsData.StocIntangibilBase !== totals.StocIntangibil) {
            HideLoading();
            ToastShowError("Totalul stocurilor intangibile din lista nu este egal cu valoarea stocului intangibil de baza!");
            return;
        }
        if (produsData.StocUrgentaBase !== totals.StocUrgenta) {
            HideLoading();
            ToastShowError("Totalul stocurilor de urgenta din lista nu este egal cu valoarea stocului de urgenta de baza!");
            return;
        }
        if (produsData.StocConjuncturaBase !== totals.StocConjunctura) {
            HideLoading();
            ToastShowError("Totalul stocurilor de conjunctura din lista nu este egal cu valoarea stocului de conjunctura de baza!");
            return;
        }
        if (produsData.StocRezilientaBase !== totals.StocRezilienta) {
            HideLoading();
            ToastShowError("Totalul stocurilor de rezilienta din lista nu este egal cu valoarea stocului de rezilienta de baza!");
            return;
        }

        const detaliiUt = collectBatchGridData();

        const postData = {
            Id: produsRezDetUtId,
            //StocRs: produsData.StocRsBase ?? 0,
            //StocIntangibil: produsData.StocIntangibilBase ?? 0,
            //StocUrgenta: produsData.StocUrgentaBase ?? 0,
            //StocConjunctura: produsData.StocConjuncturaBase ?? 0,
            //StocRezilienta: produsData.StocRezilientaBase ?? 0,
            NomenclatorProdusDetId: produsData.NomenclatorProdusDetId,
            DetaliiProdusRezervaDeStatUT: detaliiUt,
        };
        console.log(postData);

        ajaxHelper.post(`${apiRoot}/Upsert`,
            postData,
            function (response) {

                console.log(response);

                HideLoading();

                if (!response || !response.Success) {
                    ToastShowError(response.Message);
                    return;
                }

                HidePopup(popupId);
                ReloadDataGrid(gridId);
            },
            function (err) {
                ToastShowError(err.Message);
                HideLoading();
            });

        HideLoading();
    }

    const onSaveDetaliiGrid = function (item) {
        var frmDetaliiGridInstance = $(formDetaliiGridId).dxForm("instance");

        if (!frmDetaliiGridInstance.validate().isValid) {
            ToastShowError("Date Invalide!")
            return;
        }

        let dataGrid = $(gridDetaliiId).dxDataGrid("instance");
        let formData = frmDetaliiGridInstance.option("formData");
        if ((!formData.StocRs || formData.StocRs === 0)
            && (!formData.StocConjunctura || formData.StocConjunctura === 0)
            && (!formData.StocUrgenta || formData.StocUrgenta === 0)
            && (!formData.StocRezilienta || formData.StocRezilienta === 0)
            && (!formData.StocIntangibil || formData.StocIntangibil === 0)) {
            ToastShowError("Nu puteti inregistra in lista o linie cu toate valorile 0");
            return;
        }

        if (editRowIndex >= 0) {
            dataGrid.cellValue(editRowIndex, "UnitatiId", formData.UnitatiId);
            dataGrid.cellValue(editRowIndex, "StocRs", formData.StocRs ?? 0);
            dataGrid.cellValue(editRowIndex, "StocIntangibil", formData.StocIntangibil ?? 0);
            dataGrid.cellValue(editRowIndex, "StocUrgenta", formData.StocUrgenta ?? 0);
            dataGrid.cellValue(editRowIndex, "StocConjunctura", formData.StocConjunctura ?? 0);
            dataGrid.cellValue(editRowIndex, "StocRezilienta", formData.StocRezilienta ?? 0);
            dataGrid.cellValue(editRowIndex, "NomenclatorProdusDetId", nomenclatorDetId);
            dataGrid.cellValue(editRowIndex, "DataStart", moment(formData.DataStart).format("YYYY-MM-DD"));
            dataGrid.cellValue(editRowIndex, "DataStop", moment(formData.DataStop).format("YYYY-MM-DD"));
        } else {
            dataGrid.on("initNewRow", function (e) {
                e.data["UnitatiId"] = formData.UnitatiId;
                e.data["StocRs"] = formData.StocRs ?? 0;
                e.data["StocIntangibil"] = formData.StocIntangibil ?? 0;
                e.data["StocUrgenta"] = formData.StocUrgenta ?? 0;
                e.data["StocConjunctura"] = formData.StocConjunctura ?? 0;
                e.data["StocRezilienta"] = formData.StocRezilienta ?? 0;
                e.data["NomenclatorProdusDetId"] = nomenclatorDetId;
                e.data["DataStart"] = moment(formData.DataStart).format("YYYY-MM-DD");
                e.data["DataStop"] = moment(formData.DataStop).format("YYYY-MM-DD");
            });

            dataGrid.beginUpdate();
            dataGrid.addRow();
            dataGrid.endUpdate();
            dataGrid.endCustomLoading();
            dataGrid.off("initNewRow");
        }

        HidePopup(popupDetaliiGridId);

        // (optional) force a light repaint so your new data is in the DOM
        if (typeof dataGrid.repaintChangesOnly === "function") {
            dataGrid.repaintChangesOnly();
        } else {
            dataGrid.refresh();
        }

        // **Then** overwrite the footer with our own sums:
        recalcStocSummaries(dataGrid);
    }

    function recalcStocSummaries(grid) {
        // 1) Grab the data­-rows you’re looking at (with any in-UI edits applied)
        const rows = grid.getVisibleRows()
            .filter(r => r.rowType === "data")
            .map(r => r.data);

        // 2) Compute each Stoc* total
        const sums = rows.reduce((acc, r) => {
            acc.StocRs += (r.StocRs ?? 0);
            acc.StocIntangibil += (r.StocIntangibil ?? 0);
            acc.StocUrgenta += (r.StocUrgenta ?? 0);
            acc.StocConjunctura += (r.StocConjunctura ?? 0);
            acc.StocRezilienta += (r.StocRezilienta ?? 0);
            return acc;
        }, {
            StocRs: 0,
            StocIntangibil: 0,
            StocUrgenta: 0,
            StocConjunctura: 0,
            StocRezilienta: 0
        });

        // 3) Format function
        const fmt = v => produsRezUtModule.formatNumberForROCulture(v);

        // 4) Find your footer's summary row by CSS
        const $root = grid.element();
        const fieldMap = {
            StocRs: sums.StocRs,
            StocIntangibil: sums.StocIntangibil,
            StocUrgenta: sums.StocUrgenta,
            StocConjunctura: sums.StocConjunctura,
            StocRezilienta: sums.StocRezilienta
        };

        // 5) Overwrite each cell in the footer
        Object.entries(fieldMap).forEach(([field, value]) => {
            $root
                .find(`td.dx-datagrid-total-footer-cell[data-field="${field}"] .dx-datagrid-summary-item-value`)
                .text(fmt(value));
        });
    }

    const onEdit = function (item) {
        var popup = $(popupId).dxPopup("instance");
        if (popup != undefined) {
            popup.option("title", "Actualizare");
        }
        ShowLoading();
        onClearInfo();

        produsRezDetUtId = item.data.Id;
        getData(produsRezDetUtId, popupId, formId);
        item.cancel = true;
    }

    const onEditingStart = function (e) {
        e.cancel = true;
    }

    const onEditDetaliiGrid = function (item) {
        var popup = $(popupDetaliiGridId).dxPopup("instance");
        if (popup != undefined) {
            popup.option("title", "Actualizare detalii");
        }

        produsRezDetDetaliiId = item.row?.data.Id;

        editRowIndex = item.row?.rowIndex;
        var clonedData = Object.assign({}, item.row?.data);
        item.event.preventDefault();

        ShowPopup(popupDetaliiGridId);
        var frmDetaliiGridInstance = $(formDetaliiGridId).dxForm("instance");
        frmDetaliiGridInstance.option("formData", clonedData);
    }

    const onNomenclatorProdusDetIdChanged = function (args) {
        let stocRs = 0;
        let stocIntangibil = 0;
        let stocUrgenta = 0;
        let stocConjunctura = 0;
        let stocRezilienta = 0;
        let clickedDataStart = null;
        let clickedDataStop = null;

        if (args.component.clickedRowData !== null && args.component.clickedRowData !== undefined) {
            nomenclatorDetId = args.component.clickedRowData.Id;
            stocRs = args.component.clickedRowData.StocRs;
            stocIntangibil = args.component.clickedRowData.StocIntangibil;
            stocUrgenta = args.component.clickedRowData.StocUrgenta;
            stocConjunctura = args.component.clickedRowData.StocConjunctura;
            stocRezilienta = args.component.clickedRowData.StocRezilienta;
            clickedDataStart = args.component.clickedRowData.DataStart;
            clickedDataStop = args.component.clickedRowData.DataStop;
        }
        //pentru situatia in care se schimba valoarea din cod si nu de catre utilizator
        else if (args.value !== 0) {
            nomenclatorDetId = args.value;
        }

        if (produsRezDetUtId === 0) {
            dataStart = clickedDataStart;
            dataStop = clickedDataStop;
        }

        var stocRsNumberBox = $("#StocRs").dxNumberBox("instance");
        stocRsNumberBox.option('value', stocRs);
        var stocIntangibilNumberBox = $("#StocIntangibil").dxNumberBox("instance");
        stocIntangibilNumberBox.option('value', stocIntangibil);
        var stocUrgentaNumberBox = $("#StocUrgenta").dxNumberBox("instance");
        stocUrgentaNumberBox.option('value', stocUrgenta);
        var stocConjuncturaNumberBox = $("#StocConjunctura").dxNumberBox("instance");
        stocConjuncturaNumberBox.option('value', stocConjunctura);
        var stocRezilientaNumberBox = $("#StocRezilienta").dxNumberBox("instance");
        stocRezilientaNumberBox.option('value', stocRezilienta);
    }

    const getData = function (id, popupId, formId) {

        if (!id || id < 1) {
            ToastShowError("Id invalid!")
            return;
        }


        ajaxHelper.get(`${apiRoot}/GetProdusRezervaDeStatUTDetails?produsRezUtId=${id}`, null,
            function (response) {

                HideLoading();

                console.log(response);

                if (!response || !response.Success) {
                    ToastShowError(response.Message);
                    return;
                }

                ShowPopup(popupId);

                // Set the NomenclatorProdusDetId to readOnly when editing
                var dropDownNomenclatorProdusDetInstance = $("#NomenclatorProdusDetId").dxDropDownBox("instance");
                if (dropDownNomenclatorProdusDetInstance) {
                    dropDownNomenclatorProdusDetInstance.option("readOnly", true);
                } else {
                    console.error("DropDownBox instance NomenclatorProdusDetId not found at the time of execution.");
                }

                var frmInstance = $(formId).dxForm("instance");
                if (frmInstance != undefined) {
                    produsRezUtModelData = response.Data;
                    frmInstance.option("formData", produsRezUtModelData);

                    //for daterange
                    //global.setDateRangeValues('#dateRangeBox', produsRezUtModelData.DataStart, produsRezUtModelData.DataStop);
                }
            },
            function (err) {
                ToastShowError("Au aparut erori la citirea datelor!");
                HideLoading();
            });
    }

    const getNomenclatorProdusBaseId = function () {
        return produsDetId;
    }

    const onClearInfo = function () {
        produsRezDetUtId = 0;
        nomenclatorDetId = 0;
        dataStart = null;
        dataStop = null;
        produsRezUtModelData = null;
    }

    const onClearInfoDetaliiGrid = function () {
        produsRezDetDetaliiId = 0;
    }

    const onRowClick = function (item) {
        produsRezDetUtId = item.data.Id;
    }

    const onRowClickDetaliiGrid = function (item) {
        produsRezDetDetaliiId = item.data?.Id;
    }

    const getDetaliiGridParam = function (operation, ajaxSettings) {
        if (operation == "load") {
            ajaxSettings.data.nomenclatorDetId = nomenclatorDetId;
        }
    }

    const formatNumberForROCulture = function (value) {
        if (value !== undefined)
            return new Intl.NumberFormat('ro-RO', {
                style: 'decimal',
                minimumFractionDigits: 2,
                maximumFractionDigits: 2,
            }).format(value);
        else
            return 0;
    }

    return {
        onAddAction: onAddAction,
        onResetGrid: onResetGrid,
        onDelete: onDelete,
        onCancel: onCancel,
        onSave: onSave,
        onEdit: onEdit,
        onEditingStart: onEditingStart,
        onEditorPreparingDetaliiGrid: onEditorPreparingDetaliiGrid,
        onEditDetaliiGrid: onEditDetaliiGrid,
        onRowClick: onRowClick,
        onHidingPopup: onHidingPopup,
        onAddActionDetaliiGrid: onAddActionDetaliiGrid,
        onDeleteDetaliiGrid: onDeleteDetaliiGrid,
        collectBatchGridData: collectBatchGridData,
        onResetDetaliiGrid: onResetDetaliiGrid,
        onCancelDetaliiGrid: onCancelDetaliiGrid,
        onHidingDetaliiGridPopup: onHidingDetaliiGridPopup,
        onSaveDetaliiGrid: onSaveDetaliiGrid,
        onNomenclatorProdusDetIdChanged: onNomenclatorProdusDetIdChanged,
        onRowClickDetaliiGrid: onRowClickDetaliiGrid,
        getNomenclatorProdusBaseId: getNomenclatorProdusBaseId,
        getDetaliiGridParam: getDetaliiGridParam,
        getMergedGridData: getMergedGridData,
        formatNumberForROCulture: formatNumberForROCulture
    }
})();