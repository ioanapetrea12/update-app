﻿const logModule = (function () {
    var logId = 0;
    var logModelData = {};

    const apiRoot = "/Administrare/Log";
    const gridId = "#gridLog";

    var onResetGrid = function () {
        var grid = $(gridId).dxDataGrid("instance");

        grid.state({});
    }

    var onRowClick = function (item) {
        logId = item.data.Id;
    }

    return {
        onResetGrid: onResetGrid,
        onRowClick: onRowClick
    }
})();