﻿const produsModule = (function () {
    var produsId = 0;
    var produsModelData = {};

    const apiRoot = "/Administrare/Produs";
    const gridId = "#gridProdus";
    const popupId = "#upsert-produs-popup";
    const formId = "#upsert-produs-form";

    var onAddAction = function (args) {
        var popup = $(popupId).dxPopup("instance");
        if (popup != undefined) {
            popup.option("title", "Adăugare");
        }
        ShowPopup(popupId);
        onClearInfo();
    }

    var onDelete = function (item) {
        var result = DevExpress.ui.dialog.confirm("<p>Sunteți sigur/ă ca doriți ștergerea elementului selectat?</p>", "Ștergere");
        result.done(function (dialogResult) {
            if (dialogResult) {
                var postData = {
                    Key: item.row.key
                };
                ajaxHelper.post(`${apiRoot}/Delete`, postData,
                    function (response) {
                        HideLoading();
                        if (response) {
                            ReloadDataGrid(gridId);
                        } else {
                            ToastShowError("A apărut o eroare la ștergerea intrărilor");
                        }
                    },
                    function (err) {
                        ToastShowError("An error occured");
                        HideLoading();
                    });
            }
        })
    }

    var onResetGrid = function () {
        var grid = $(gridId).dxDataGrid("instance");

        grid.state({});
    }
    var onCancel = function () {
        HidePopup(popupId);
    }

    const onHidingPopup = function () {
        global.onHidingUpsertViewPopup(popupId, apiRoot, onClearInfo);
    }

    var onSave = function (item) {
        ShowLoading();

        var frmInstance = $(formId).dxForm("instance");

        if (!frmInstance.validate().isValid) {
            HideLoading();
            ToastShowError("Date Invalide!");
            return;
        }

        const produsData = frmInstance.option("formData");

        const postData = {
            Id: produsId,
            Cod: produsData.Cod,
            Denumire: produsData.Denumire,
            EconomicaId: produsData.EconomicaId,
            PlanContId: produsData.PlanContId,
            Sort: produsData.Sort,
            Calitate: produsData.Calitate,
            Inaltime: produsData.Inaltime,
            Latime: produsData.Latime,
            Adancime: produsData.Adancime,
            Densitate: produsData.Densitate,
            CodCPVId: produsData.CodCPVId,
            UMIdBaza: produsData.UMIdBaza,
            UMIdEchivalent1: produsData.UMIdEchivalent1,
            UMIdEchivalent2: produsData.UMIdEchivalent2,
            UMIdEchivalent3: produsData.UMIdEchivalent3,
            UMIdEchivalent4: produsData.UMIdEchivalent4,
            UMIdEchivalent5: produsData.UMIdEchivalent5,
            UMIdDimensiune: produsData.UMIdDimensiune,
            ModConservare: produsData.ModConservare,
            TipSpatiu: produsData.TipSpatiu,
            ConditiiMicroclimat: produsData.ConditiiMicroclimat,
            IncarcareNormata: produsData.IncarcareNormata,
            PeriodicitateConservare: produsData.PeriodicitateConservare,
            ConditiiStivuire: produsData.ConditiiStivuire,
            StivuireMaterial: produsData.StivuireMaterial,
            StivuireDiametru: produsData.StivuireDiametru,
            StivuireSuprafataEvaporare: produsData.StivuireSuprafataEvaporare,
            StivuireInaltimeVara: produsData.StivuireInaltimeVara,
            StivuireInaltimeIarna: produsData.StivuireInaltimeIarna,
            StivuireTermenPastrare: produsData.StivuireTermenPastrare,
            TermenPastrare: produsData.TermenPastrare,
            Tehnician: produsData.Tehnician,
            NrZecimaleStoc: produsData.NrZecimaleStoc,
        };
        console.log(postData);

        ajaxHelper.post(`${apiRoot}/Upsert`,
            postData,
            function (response) {

                console.log(response);

                HideLoading();

                if (!response || !response.Success) {
                    ToastShowError(response.Message);
                    return;
                }

                HidePopup(popupId);
                ReloadDataGrid(gridId);
            },
            function (err) {
                ToastShowError(err.Message);
                HideLoading();
            });

        HideLoading();
    }
    var onEdit = function (item) {
        var popup = $(popupId).dxPopup("instance");
        if (popup != undefined) {
            popup.option("title", "Actualizare");
        }
        ShowLoading();
        onClearInfo();
        produsId = item.data.Id;
        getData(item.data.Id);
        item.cancel = true;
    }

    var getData = function (id) {

        if (!id || id < 1) {
            ToastShowError("Id invalid!")
            return;
        }


        ajaxHelper.get(`${apiRoot}/GetProdusDetails?produsId=${id}`, null,
            function (response) {

                HideLoading();

                console.log(response);

                if (!response || !response.Success) {
                    ToastShowError(response.Message);
                    return;
                }

                ShowPopup(popupId);
                var frmInstance = $(formId).dxForm("instance");
                if (frmInstance != undefined) {
                    produsModelData = response.Data;
                    frmInstance.option("formData", produsModelData);

                }
            },
            function (err) {
                ToastShowError("Au aparut erori la citirea datelor!");
                HideLoading();
            });
    }

    var onClearInfo = function () {
        produsId = 0;
        produsModelData = null;
    }

    var onRowClick = function (item) {
        produsId = item.data.Id;
    }

    const onPrintRaport = function (e) {
        var codRaport = -11;
        var produsId = e.row.data.Id;
        ShowLoading();
        ajaxHelper.get(`${apiRoot}/GetProdusLinkRaport?produsId=${produsId}&codInternRaport=${codRaport}`, null,
            function (response) {
                if (!response || !response.Success) {
                    ToastShowError(response.Message);
                    return;
                }

                window.open(response.Data, '_blank');
                HideLoading();
            },
            function (error) {

            });
        HideLoading();
    }

    return {
        onAddAction: onAddAction,
        onResetGrid: onResetGrid,
        onDelete: onDelete,
        onCancel: onCancel,
        onSave: onSave,
        onEdit: onEdit,
        onPrintRaport: onPrintRaport,
        onRowClick: onRowClick,
        onHidingPopup: onHidingPopup
    }
})();