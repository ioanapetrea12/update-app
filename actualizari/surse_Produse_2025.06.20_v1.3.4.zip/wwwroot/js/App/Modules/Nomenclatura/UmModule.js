﻿const umModule = (function () {
    var umId = 0;
    var umModelData = {};

    const apiRoot = "/Nomenclatoare/Um";
    const gridId = "#grid-ums";
    const popupId = "#upsert-um-popup";
    const formId = "#upsert-um-form";
    const umConversieGridId = "#um-conversie-grid";

    const getUpsertItemId = function () {
        return umId;
    }

    var onAddAction = function (args) {
        var popup = $(popupId).dxPopup("instance");
        if (popup != undefined) {
            popup.option("title", "Adaugare");
        }
        ShowPopup(popupId);
        onClearInfo();
    }

    var onDelete = function (item) {
        var result = DevExpress.ui.dialog.confirm("<p>Sunteti sigur/a ca doriti stergerea elementului selectat?</p>", "Stergere");
        result.done(function (dialogResult) {
            if (dialogResult) {
                var postData = {
                    Key: item.row.key
                };
                ajaxHelper.post(`${apiRoot}/Delete`, postData,
                    function (response) {
                        HideLoading();
                        if (response) {
                            if (response.Success == false) {
                                ToastShowError(response.Message);
                                return;
                            }
                            ReloadDataGrid(gridId);
                        } else {
                            ToastShowError("A aparut o eroare la stergerea intrarilor");
                        }
                    },
                    function (err) {
                        ToastShowError("An error occured");
                        HideLoading();
                    });
            }
        })
    }

    var onResetGrid = function () {
        var grid = $(gridId).dxDataGrid("instance");

        grid.state({});
    }
    var onCancel = function () {
        HidePopup(popupId);
    }

    var onHidingPopup = function () {
        global.onHidingUpsertViewPopup(popupId, apiRoot, onClearInfo);
    }

    var onSave = function (item) {
        ShowLoading();

        var frmInstance = $(formId).dxForm("instance");

        if (!frmInstance.validate().isValid) {
            HideLoading();
            ToastShowError("Date Invalide!");
            return;
        }

        const umData = frmInstance.option("formData");
        var range = global.getDateRangeValues('#dateRangeBox');

        const postData = {
            Id: umId,
            Cod: umData.Cod,
            Denumire: umData.Denumire,
            CodSpv: umData.CodSpv,
            NumeSpv: umData.NumeSpv,
            NameSpv: umData.NameSpv,
            IsStandard: umData.IsStandard,
            IsDefault: umData.IsDefault,
            DataStart: moment(range[0]).format("YYYY-MM-DD"),
            DataStop: moment(range[1]).format("YYYY-MM-DD"),
        };
        //console.log(postData);

        const gridUmConversieInstance = $(umConversieGridId).dxDataGrid('instance');
        //console.log(gridUmConversieInstance.getVisibleRows());
        const umConversieRows = gridUmConversieInstance.getVisibleRows().filter(x => !x.removed && x.data).map(x => x.data);
        //console.log(umConversieRows);

        const umConversies = [];
        for (let i = 0; i < umConversieRows.length; i++) {

            const umConversieRow = umConversieRows[i];
            const umConversie = {
                id: getValue(umConversieRow, 'Id'),
                dinumid: umId,
                inumid: umConversieRow.InUmId,
                factorconversie: umConversieRow.FactorConversie,
                esteautomat: umConversieRow.EsteAutomat,
                dataadaugarii: moment(umConversieRow.DataAdaugarii).format("YYYY-MM-DD") //moment().format("YYYY-MM-DD")
            };
            umConversies.push(umConversie);
        }

        postData.UmConversies = umConversies;
        console.log(postData);

        ajaxHelper.post(`${apiRoot}/Upsert`,
            postData,
            function (response) {
                HideLoading();

                if (!response || !response.Success) {
                    ToastShowError(response.Message);
                    return;
                }

                HidePopup(popupId);
                ReloadDataGrid(gridId);
            },
            function (err) {
                ToastShowError(err.Message);
                HideLoading();
            });

        HideLoading();
    }
    var onEdit = function (item) {
        var popup = $(popupId).dxPopup("instance");
        if (popup != undefined) {
            popup.option("title", "Actualizare");
        }
        ShowLoading();
        onClearInfo();
        umId = item.data.Id;
        getData(item.data.Id);
        item.cancel = true;
    }

    var getData = function (id) {

        if (!id || id < 1) {
            ToastShowError("Id invalid!")
            return;
        }


        ajaxHelper.get(`${apiRoot}/GetUmDetails?umId=${id}`, null,
            function (response) {

                HideLoading();
                if (!response || !response.Success) {
                    ToastShowError(response.Message);
                    return;
                }

                ShowPopup(popupId);
                var frmInstance = $(formId).dxForm("instance");
                if (frmInstance != undefined) {
                    umModelData = response.Data;
                    frmInstance.option("formData", umModelData);

                    //for daterange
                    global.setDateRangeValues('#dateRangeBox', umModelData.DataStart, umModelData.DataStop);
                }
            },
            function (err) {
                ToastShowError("Au aparut erori la citirea datelor!");
                HideLoading();
            });
    }

    const onAddUmConversieAction = function () {
        const dataGrid = $(umConversieGridId).dxDataGrid("instance");
        dataGrid.beginUpdate();
        dataGrid.addRow();
        dataGrid.endUpdate();
        dataGrid.endCustomLoading();
    }

    var onClearInfo = function () {
        umId = 0;
        umModelData = null;

        var now = new Date();
        global.setDateRangeValues('#dateRangeBox', new Date(now.getFullYear(), 0, 1), new Date(2099, 11, 31),);
    }

    var onRowClick = function (item) {
        umId = item.data.Id;
    }

    return {
        getUpsertItemId: getUpsertItemId,
        onAddAction: onAddAction,
        onResetGrid: onResetGrid,
        onDelete: onDelete,
        onCancel: onCancel,
        onSave: onSave,
        onEdit: onEdit,
        onRowClick: onRowClick,
        onHidingPopup: onHidingPopup,
        onAddUmConversieAction
    }
})();