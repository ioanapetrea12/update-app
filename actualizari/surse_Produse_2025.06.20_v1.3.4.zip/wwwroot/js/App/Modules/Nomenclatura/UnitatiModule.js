﻿var unitatiModule = (function () {
    var unitatiId = null;
    var parinteUnitatiId = null;
    var unitatiData = {};
    var cif = null;

    const apiRoot = "/Nomenclatoare/Unitati";
    const popupId = "#upsert-unitati-popup";
    const formId = "#upsert-unitati-form";
    const treeId = "#gridUnitati";

    var onAddAction = function (args) {
        var popup = $(popupId).dxPopup("instance");
        if (popup != undefined) {
            popup.option("title", "Adaugare");
        }
        ShowPopup(popupId);
        onClearInfo();

        //if (args.row?.data?.Id) {
        //    parinteUnitatiId = args.row.data.Id;
        //}
    }

    var onDelete = function (item) {
        var result = DevExpress.ui.dialog.confirm("<p>Sunteti sigur/a ca doriti stergerea elementului selectat?</p>", "Stergere");
        result.done(function (dialogResult) {
            if (dialogResult) {
                var postData = {
                    Key: item.row.key
                };
                ajaxHelper.post(`${apiRoot}/Delete`, postData,
                    function (response) {
                        HideLoading();
                        if (response) {
                            if (response.Success == false) {
                                ToastShowError(response.Message);
                                return;
                            }
                            ReloadDataGrid(treeId);
                        } else {
                            ToastShowError("A aparut o eroare la stergerea intrarilor");
                        }
                    },
                    function (err) {
                        ToastShowError("An error occured");
                        HideLoading();
                    });
            }
        })
    }

    var onResetGrid = function () {
        var datagrid = $(treeId).dxDataGrid("instance");

        datagrid.state({});
    }
    var onCancel = function () {
        onClearInfo();
        HidePopup(popupId);
    }

    var onHidingPopup = function () {
        global.onHidingUpsertViewPopup(popupId, apiRoot, onClearInfo);
    }

    var onSave = function (item) {
        ShowLoading();

        var frmInstance = $(formId).dxForm("instance");

        if (!frmInstance.validate().isValid) {
            HideLoading();
            ToastShowError("Date Invalide!");
            return;
        }

        var unitatiData = frmInstance.option("formData");
        var range = global.getDateRangeValues('#dateRangeBox');

        var postData = {
            Id: unitatiId,
            Idparinte: parinteUnitatiId,
            Denumire: unitatiData.Denumire,
            DenumireCompleta: unitatiData.DenumireCompleta,
            Cif: unitatiData.Cif,
            CifTva: unitatiData.CifTva,
            NrComert: unitatiData.NrComert,
            AdresaId: unitatiData.AdresaId,
            AdresaIdcorespondenta: unitatiData.AdresaIdcorespondenta,
            AdresaEmail: unitatiData.AdresaEmail,
            TipUnitate: unitatiData.TipUnitate,
            TipOrdonator: unitatiData.TipOrdonator,
            CodCaenprincipal: unitatiData.CodCaenprincipal,
            CodCaensecundar: unitatiData.CodCaensecundar,
            Detalii: unitatiData.Detalii,
            DataStart: moment(range[0]).format("YYYY-MM-DD"),
            DataStop: moment(range[1]).format("YYYY-MM-DD"),
        };
        console.log(postData);

        ajaxHelper.post(`${apiRoot}/Upsert`,
            postData,
            function (response) {
                HideLoading();

                if (!response || !response.Success) {
                    ToastShowError(response.Message);
                    return;
                }

                HidePopup(popupId);
                ReloadDataGrid(treeId);
            },
            function (err) {
                ToastShowError(err.Message);
                HideLoading();
            });

        HideLoading();
    }
    var onEdit = function (item) {
        var popup = $(popupId).dxPopup("instance");
        if (popup != undefined) {
            popup.option("title", "Actualizare");
        }
        ShowLoading();
        onClearInfo();
        unitatiId = item.row?.data.Id;
        //parinteUnitatiId = item.row?.data.Idparinte;
        getData(unitatiId);
        item.cancel = true;
    }

    var getData = function (id) {

        if (!id || id < 1) {
            ToastShowError("Id invalid!")
            return;
        }


        ajaxHelper.get(`${apiRoot}/GetUnitatiDetails?unitatiId=${id}`, null,
            function (response) {

                HideLoading();

                console.log(response);

                if (!response || !response.Success) {
                    ToastShowError(response.Message);
                    return;
                }

                ShowPopup(popupId);
                var frmInstance = $(formId).dxForm("instance");
                if (frmInstance != undefined) {
                    unitatiModelData = response.Data;
                    frmInstance.option("formData", unitatiModelData);

                    //for daterange
                    global.setDateRangeValues('#dateRangeBox', unitatiModelData.DataStart, unitatiModelData.DataStop);
                }
            },
            function (err) {
                ToastShowError("Au aparut erori la citirea datelor!");
                HideLoading();
            });
    }

    var onClearInfo = function () {
        unitatiId = null;
        parinteUnitatiId = null;
        unitatiModelData = null;
        cif = null;

        var now = new Date();
        global.setDateRangeValues('#dateRangeBox', new Date(now.getFullYear(), 0, 1), new Date(2099, 11, 31),);
    }

    var onRowClick = function (item) {
        unitatiId = item.data.Id;
    }

    var showAction = function (params) {
        var data = params.row.data;
        if (!data) {
            return false;
        }

        return true;
    }

    var onCifValueChanged = function (e) {
        cif = e.value; 
        console.log("CIF updated:", cif); 

        var adrese = $("#ddlAdrese").dxDropDownBox("instance");
        if (adrese)
            adrese.option('value', null);

        var adreseCorespondente = $("#ddlAdreseCorespondente").dxDropDownBox("instance");
        if (adreseCorespondente)
            adreseCorespondente.option('value', null);
    }

    const setCifParam = function (operation, ajaxSettings) {
        if (operation === "load") {
            ajaxSettings.data.Cif = cif;
        }
    }

    const onAdreseOpen = function (e) {
        e.component.getDataSource().load().then(function (data) {
            ReloadDataGrid("#ComboAdreseGrid");
        })
    }

    const onAdreseCorespondenteOpen = function (e) {
        e.component.getDataSource().load().then(function (data) {
            ReloadDataGrid("#ComboAdreseCorespondenteGrid");
        })
    }

    return {
        onAddAction: onAddAction,
        onResetGrid: onResetGrid,
        onDelete: onDelete,
        onCancel: onCancel,
        onSave: onSave,
        onEdit: onEdit,
        onRowClick: onRowClick,
        showAction: showAction,
        onHidingPopup: onHidingPopup,
        onCifValueChanged: onCifValueChanged,
        setCifParam: setCifParam,
        onAdreseOpen: onAdreseOpen,
        onAdreseCorespondenteOpen: onAdreseCorespondenteOpen
    }
})();