﻿const parteneriModule = (function () {

    let partenerId = 0;
    let istoricAnaf = null;

    const apiRoot = "/Nomenclatoare/Parteneri";
    const popupPartenerId = "#upsert-partner-popup";
    const formPartenerId = "#upsert-parteneri-form";
    const gridPartenerBankId = "#partener-bank-grid";
    const gridPartenerAnafId = "#partener-anaf-grid";
    const txtCifCnpId = "#txtCifCnp";
    const gridParteneriId = "#grid-parteneri";

    const enableSyncAnafBtn = function () {
        const textBox = $(txtCifCnpId).dxTextBox('instance');

        if (!textBox) return;

        const value = textBox.option('value');
        const anafBtn = $('#btnSyncAnaf').dxButton('instance');

        if (!anafBtn) return;

        if (value && value !== '') {
            anafBtn.option('disabled', false);
            return;
        }

        anafBtn.option('disabled', true);
    }

    const getUpsertItemId = function () {
        return partenerId;
    }
    const getUpsertItemCui = function () {
        const textBox = $(txtCifCnpId).dxTextBox('instance');
        if (!textBox) return;
        return textBox.option('value');
    }

    const onAddAction = function () {
        ShowPopup(popupPartenerId);
        onClearInfo();
    }

    const onHidingPopup = function () {
        global.onHidingUpsertViewPopup(popupPartenerId, apiRoot, onClearInfo);
    }

    const onSave = function () {

        const formInstance = $(formPartenerId).dxForm('instance');
        const formData = formInstance.option("formData");
        console.log(formData);

        if (!formInstance.validate().isValid) {
            ToastShowError("Datele introduse sunt invalide!");
            return;
        }

        const payload = getSubmitPayload(formData);

        ajaxHelper.post(`${apiRoot}/Upsert`,
            payload,
            function (response) {

                console.log(response);

                HideLoading();

                if (!response || !response.Success) {
                    ToastShowError(response.Message);
                    return;
                }

                HidePopup(popupPartenerId);
                ReloadDataGrid(gridParteneriId);
            },
            function (err) {
                ToastShowError(err.Message);
                HideLoading();
            });

        HideLoading();
    }

    const getSubmitPayload = function (formData) {
        try {
            //note! on delete items is still available. Also, if tab was not selected, the data is not available

            const gridBankInstance = $(gridPartenerBankId).dxDataGrid('instance');
            console.log(gridBankInstance.getVisibleRows());
            const bankRows = gridBankInstance.getVisibleRows().filter(x => !x.removed && x.data).map(x => x.data);
            console.log(bankRows);

            console.log(istoricAnaf);

            const payload = {
                id: partenerId,
                denumire: formData.Denumire,
                cod: formData.Cod,
                atributFiscal: formData.AtributFiscal,
                cif: formData.CifCnp,
                vectorFiscal: formData.VectorFiscal,
                nrRegCom: formData.NrRegCom,
                codDistribuitor: formData.CodDistribuitor,
                codCaenPrincipal: formData.CodCaenPrincipal,
                codCaenSecundar: formData.CodCaenSecundar,
                categoriePartenerId: formData.CategoriePartenerId,
                telefonFix: formData.TelefonFix,
                telefonMobil: formData.TelefonMobil,
                fax: formData.Fax,
                numePersoanaAutorizata: formData.NumePersoanaAutorizata,
                prenumePersoanaAutorizata: formData.PrenumePersoanaAutorizata,
                capitalSocial: formData.CapitalSocial,
                numarActiuni: formData.NumarActiuni,
                numarTotalActiuni: formData.NumarTotalActiuni,
                bazaLegalaActiuni: formData.BazaLegalaActiuni,
                efactura: formData.Efactura,
                tvaIncasare: formData.TvaIncasare,
                dataStart: moment(formData.DataStart).format("YYYY-MM-DD"),
                dataStop: moment(formData.DataStop).format("YYYY-MM-DD"),
                detalii: formData.Detalii,
                adresa: {
                    id: formData.Adresa.Id,
                    tariId: formData.Adresa.TariId,
                    judeteId: formData.Adresa.JudeteId,
                    localitatiId: formData.Adresa.LocalitateId,
                    adresa: formData.Adresa.Adresa,
                    codPostal: formData.Adresa.CodPostal,
                    telefon: formData.Adresa.Telefon,
                    email: formData.Adresa.Email,
                    detalii: formData.Adresa.Detalii
                }
            };

            if (istoricAnaf !== null) {
                payload.istoricAnaf = [istoricAnaf];
            }

            if (formData.AdresaCorespondenta) {
                payload.adresaIdCorespondentaNavigation = {
                    id: formData.AdresaCorespondenta.Id,
                    tariId: formData.AdresaCorespondenta.TariId,
                    judeteId: formData.AdresaCorespondenta.JudeteId,
                    localitatiId: formData.AdresaCorespondenta.LocalitateId,
                    adresa: formData.AdresaCorespondenta.Adresa,
                    codPostal: formData.AdresaCorespondenta.CodPostal,
                    telefon: formData.AdresaCorespondenta.Telefon,
                    email: formData.AdresaCorespondenta.Email,
                    detalii: formData.AdresaCorespondenta.Detalii
                };
            }

            const bankAccounts = [];
            for (let i = 0; i < bankRows.length; i++) {

                const bankRow = bankRows[i];
                const bankAccount = {
                    id: getValue(bankRow, 'Id'),
                    contIban: bankRow.ContIban,
                    denumireBanca: bankRow.DenumireBanca,
                    codBic: bankRow.CodBic,
                    sucursala: bankRow.Sucursala
                };
                bankAccounts.push(bankAccount);
            }

            payload.partenerBanci = bankAccounts;

            console.log('payload', payload);

            return payload;
        } catch (e) {
            console.error(e);
            ToastShowError("A aparut o eroare.");
            return null;
        }
    }

    const onCancel = function () {
        HidePopup(popupPartenerId);
    }

    const onClearInfo = function () {
        partenerId = 0;
        istoricAnaf = null;
    }

    const onEdit = function (item) {
        ShowLoading();
        onClearInfo();
        partenerId = item.data.Id;
        getData();
        item.cancel = true;
    }

    const getData = function () {

        if (partenerId === 0) return;

        if (!partenerId || partenerId < 0) {
            ToastShowError("Id invalid!")
            return;
        }

        ajaxHelper.get(`${apiRoot}/GetPartenerDetalii?partenerId=${partenerId}`, null,
            function (response) {

                HideLoading();

                if (!response || !response.Success) {
                    ToastShowError(response.Message);
                    return;
                }

                ShowPopup(popupPartenerId);

                const frmInstance = $(formPartenerId).dxForm("instance");
                frmInstance.option("formData", response.Data);

                enableSyncAnafBtn();
            },
            function (err) {
                ToastShowError(err.Message);
                HideLoading();
            });
    }

    const onFocusOutCif = function (args) {
        var cif = getUpsertItemCui();
        var txtCod = $('#txtCod').dxTextBox('instance');
        txtCod.option('value', cif);
    }

    const getDataFromAnaf = function () {

        const cui = getUpsertItemCui();

        if (!cui || cui === '') {
            ToastShowError("CUI/CNP invalid!");
            return;
        }

        ajaxHelper.get(`${apiRoot}/GetPartenerDetaliiFromAnaf?cui=${cui}`, null,
            function (response) {

                console.log(response);

                if (!response || !response.Success) {
                    ToastShowError(response.Message);
                    return;
                }

                const data = response.Data;

                const frmInstance = $(formPartenerId).dxForm("instance");
                frmInstance.option("formData", data);
            },
            function (err) {
                ToastShowError(err.Message);
                HideLoading();
            });
    }

    const getPartenerIstoricAnaf = function () {

        const cui = getUpsertItemCui();

        if (!cui || cui === '') {
            ToastShowError("CUI/CNP invalid!");
            return;
        }

        ShowLoading();

        ajaxHelper.get(`${apiRoot}/GetPartenerIstoricAnaf?cui=${cui}`, null,
            function (response) {

                HideLoading();

                if (!response || !response.Success) {
                    ToastShowError(response.Message);
                    return;
                }

                istoricAnaf = response.Data;

                $(gridPartenerAnafId).dxDataGrid({
                    dataSource: response.Data.AnafAttributes
                });
            },
            function (err) {
                ToastShowError(err.Message);
                HideLoading();
            });
    }

    const onAddPartnerBankAction = function () {
        const dataGrid = $(gridPartenerBankId).dxDataGrid("instance");
        dataGrid.beginUpdate();
        dataGrid.addRow();
        dataGrid.endUpdate();
        dataGrid.endCustomLoading();
    }

    const onDelete = function (item) {
        var result = DevExpress.ui.dialog.confirm("<p>Sunteti sigur/a ca doriti stergerea elementului selectat?</p>", "Stergere");
        result.done(function (dialogResult) {
            if (dialogResult) {
                ajaxHelper.delete(`${apiRoot}/Delete/${item.row.key}`,
                    function (response) {
                        HideLoading();
                        if (response) {
                            if (response.Success == false) {
                                ToastShowError(response.Message);
                                return;
                            }
                            ReloadDataGrid(gridParteneriId);
                        } else {
                            ToastShowError("A aparut o eroare la stergerea contractului");
                        }
                    },
                    function (err) {
                        ToastShowError("An error occured");
                        HideLoading();
                    });
            }
        })
    }

    return {
        getUpsertItemId: getUpsertItemId,
        getUpsertItemCui: getUpsertItemCui,
        onAddAction: onAddAction,
        onHidingPopup: onHidingPopup,
        onSave: onSave,
        onCancel: onCancel,
        onEdit: onEdit,
        onDelete: onDelete,
        onAddPartnerBankAction: onAddPartnerBankAction,
        onFocusOutCif: onFocusOutCif,
        getDataFromAnaf: getDataFromAnaf,
        getPartenerIstoricAnaf: getPartenerIstoricAnaf,
    };
})
    ();