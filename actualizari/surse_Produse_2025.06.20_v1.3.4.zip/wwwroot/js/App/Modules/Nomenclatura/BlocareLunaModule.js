﻿const blocareLunaModule = (function () {

    const apiRoot = '/Nomenclatoare/BlocareLuna'
    var unitateId = null;
    var unitate = null;
    var data = null;

    const onUnitateChanged = function (e) {
        if (e.selectedItem) {
            unitateId = e.selectedItem.Id;
            unitate = e.selectedItem.Denumire;
            tryToActivateButton();
        }
    }

    const onDateChanged = function (e) {
        data = e.value;
        tryToActivateButton();
    }

    const tryToActivateButton = function () {
        if (unitateId !== null && data !== null && unitate !== null) {
            const blocareBtn = $("#blocareBtn").dxButton("instance");
            if (blocareBtn) {
                blocareBtn.option("disabled", false);
            }
        }
    }

    const onBlockPeriod = function () {
        const dateOnly = data.split('T')[0];
        const body = {
            UnitatiId: unitateId,
            Data: dateOnly
        }

        ajaxHelper.post(`${apiRoot}/CreateLunaBlocata`, body,
            function (response) {
                if (!response || !response.Success) {
                    ToastShowError(response.Message);
                    return;
                }
                $("#gridLunaBlocata").dxDataGrid("instance").refresh();
                $("#dateSelector").dxDateBox("instance").option("value", null);
                data = null;
                const blocareBtn = $("#blocareBtn").dxButton("instance");
                if (blocareBtn) {
                    blocareBtn.option("disabled", true);
                }
            },
            function (err) {
                ToastShowError(err.Message || "Au aparut erori la transmiterea documentului!");
                HideLoading();
                return;
            });
    }

    return {
        onUnitateChanged: onUnitateChanged,
        onDateChanged: onDateChanged,
        tryToActivateButton: tryToActivateButton,
        onBlockPeriod: onBlockPeriod,
    }
})();