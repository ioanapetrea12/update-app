﻿const comisiiPersonalModule = (function () {
    var comisieId = 0;
    var comisieDetId = 0;
    var comisieModelData = {};
    var editRowIndex = -1;
    var unitateId = '00000000-0000-0000-0000-000000000000';
    var toate = false;

    const apiRoot = "/Nomenclatoare/ComisiiPersonal";

    //grids
    const gridId = "#gridComisiiPersonal";
    const gridDetaliiId = "#grid-comisieDet";

    //popups
    const popupId = "#upsert-popup";
    const popupDetaliiGridId = "#upsert-detaliigridcomisie-popup";

    //forms
    const formId = "#upsert-comisie-form";
    const formDetaliiGridId = "#upsert-detaliigridcomisie-form";

    var onAddAction = function (args) {
        var popup = $(popupId).dxPopup("instance");
        if (popup != undefined) {
            popup.option("title", "Adăugare");
        }
        ShowPopup(popupId);
        onClearInfo();
    }

    var onAddActionDetaliiGrid = function (args) {
        editRowIndex = -1;
        var popup = $(popupDetaliiGridId).dxPopup("instance");
        if (popup != undefined) {
            popup.option("title", "Comisii personal - Actualizează");
        }
        ShowPopup(popupDetaliiGridId);
        onClearInfoDetaliiGrid();
    }

    var onDelete = function (item) {
        var result = DevExpress.ui.dialog.confirm("<p>Sunteți sigur/ă ca doriți ștergerea elementului selectat?</p>", "Ștergere");
        result.done(function (dialogResult) {
            if (dialogResult) {
                var postData = {
                    Key: item.row.key
                };
                ajaxHelper.post(`${apiRoot}/Delete`, postData,
                    function (response) {
                        HideLoading();
                        if (response) {
                            if (response.Success == false) {
                                ToastShowError(response.Message);
                                return;
                            }
                            ReloadDataGrid(gridId);
                        } else {
                            ToastShowError("A apărut o eroare la ștergerea intrărilor");
                        }
                    },
                    function (err) {
                        ToastShowError("An error occured");
                        HideLoading();
                    });
            }
        })
    }

    var onDeleteDetaliiGrid = function (item) {
        var gridDetaliiInstance = $(gridDetaliiId).dxDataGrid("instance");
        var result = DevExpress.ui.dialog.confirm("<p>Sunteti sigur ca doriti stergerea elementului selectat?</p>", "Stergere");
        result.done(function (dialogResult) {
            deletedRowIndex = item.row.rowIndex;

            if (dialogResult) {
                gridDetaliiInstance.deleteRow(deletedRowIndex);
                gridDetaliiInstance.element().find(".dx-row-removed").hide();
            }
        });
    }

    var onResetGrid = function () {
        var grid = $(gridId).dxDataGrid("instance");

        grid.state({});
    }
    var onCancel = function () {
        HidePopup(popupId);
    }

    var onCancelDetaliiGrid = function () {
        HidePopup(popupDetaliiGridId);
    }

    var onHidingPopup = function () {
        global.onHidingUpsertViewPopup(popupId, apiRoot, onClearInfo);
    }

    var onHidingDetaliiGridPopup = function () {
        onClearInfoDetaliiGrid();
        $(popupDetaliiGridId).dxPopup("dispose");
        $(popupDetaliiGridId).load(`${apiRoot}/GetPopupViewDetaliiGrid`);
    }

    var onSave = function (item) {
        ShowLoading();

        var frmInstance = $(formId).dxForm("instance");

        if (!frmInstance.validate().isValid) {
            HideLoading();
            ToastShowError("Date Invalide!");
            return;
        }

        var comisieData = frmInstance.option("formData");
        var detaliiComisie = collectBatchGridData();
        var range = global.getDateRangeValues('#dateRangeBox');

        var postData = {
            Id: comisieId,
            UnitatiId: comisieData.UnitatiId,
            Cod: comisieData.Cod,
            Denumire: comisieData.Denumire,
            TipComisieId: comisieData.TipComisieId,
            GestiuniId: comisieData.GestiuniId,
            DataStart: moment(range[0]).format("YYYY-MM-DD"),
            DataStop: moment(range[1]).format("YYYY-MM-DD"),
            ComisiiPersonalDets: detaliiComisie
        };

        console.log(postData);

        ajaxHelper.post(`${apiRoot}/Upsert`,
            postData,
            function (response) {
                HideLoading();

                if (!response || !response.Success) {
                    ToastShowError(response.Message);
                    return;
                }

                HidePopup(popupId);
                ReloadDataGrid(gridId);
            },
            function (err) {
                ToastShowError(err.Message);
                HideLoading();
            });

        HideLoading();
    }

    var collectBatchGridData = function (bReturnAllDataAsNewLines = false) {
        if (!IsDataGridInstance(gridDetaliiId)) {
            return;
        }

        var acte = GetModifiedDataFromGrid(gridDetaliiId);
        var model = {
            Id: 0,
            TipFunctieComisieId: 0,
            PersonalId: 0,
            Ordine: 0,
            DataStart: null,
            DataStop: null,
            ComisiiBaseId: comisieId,
        };

        return CustomCopyTo(model, acte, bReturnAllDataAsNewLines);
    }

    var onSaveDetaliiGrid = function (item) {
        var frmDetaliiGridInstance = $(formDetaliiGridId).dxForm("instance");
        let formData = frmDetaliiGridInstance.option("formData");
        var range = global.getDateRangeValues('#dateRangeBoxDet');

        if (formData.Ordine === 0) {
            ToastShowError("Nr. Crt. nu poate fi 0!");
            return;
        }

        if (!frmDetaliiGridInstance.validate().isValid) {
            ToastShowError("Date Invalide!")
            return;
        }

        let dataGrid = $(gridDetaliiId).dxDataGrid("instance");
        
        if (editRowIndex >= 0) {
            dataGrid.cellValue(editRowIndex, "TipFunctieComisieId", formData.TipFunctieComisieId);
            dataGrid.cellValue(editRowIndex, "PersonalId", formData.PersonalId);
            dataGrid.cellValue(editRowIndex, "Ordine", formData.Ordine);
            dataGrid.cellValue(editRowIndex, "DataStart", moment(range[0]).format("YYYY-MM-DD"));
            dataGrid.cellValue(editRowIndex, "DataStop", moment(range[1]).format("YYYY-MM-DD"));
            dataGrid.cellValue(editRowIndex, "ComisiiBaseId", comisieId);
        } else {
            dataGrid.on("initNewRow", function (e) {
                e.data["TipFunctieComisieId"] = formData.TipFunctieComisieId;
                e.data["PersonalId"] = formData.PersonalId;
                e.data["Ordine"] = formData.Ordine;
                e.data["DataStart"] = moment(range[0]).format("YYYY-MM-DD");
                e.data["DataStop"] = moment(range[1]).format("YYYY-MM-DD");
                e.data["ComisiiBaseId"] = comisieId;
            });

            dataGrid.beginUpdate();
            dataGrid.addRow();
            dataGrid.endUpdate();
            dataGrid.endCustomLoading();
            dataGrid.off("initNewRow");
        }

        HidePopup(popupDetaliiGridId);
    }

    const onSetPossibleOrder = function() {
        ajaxHelper.get(`${apiRoot}/GetPossibleOrder`, null,
            function (response) {
                HideLoading();
                if (!response || !response.orders) {
                    return;
                }

                const orders = response.orders.sort((a, b) => a - b);
                let newOrder;

                if (orders.length === 0) { newOrder = 1; }
                else if (orders.length > 1) {
                    const lastOrder = orders[orders.length - 1];
                    const secondLastOrder = orders[orders.length - 2];
                    newOrder = (lastOrder + secondLastOrder) / 2;
                }
                //else { newOrder = Math.max(...orders) + 1; }

                var txtOrdine = $('#txtOrdine').dxTextBox('instance');
                txtOrdine.option('value', newOrder);
            },
            function (err) {
                ToastShowError("Au aparut erori la citirea datelor!");
                HideLoading();
            });
    }


    const getComisiiPersonalBaseId = function () {
        return comisieId;
    }

    var onEdit = function (item) {
        var popup = $(popupId).dxPopup("instance");
        if (popup != undefined) {
            popup.option("title", "Actualizare");
        }
        ShowLoading();
        onClearInfo();
        comisieId = item.data.Id;
        getData(item.data.Id);
        item.cancel = true;
    }

    var onEditDetaliiGrid = function (item) {
        var popup = $(popupDetaliiGridId).dxPopup("instance");
        if (popup != undefined) {
            popup.option("title", "Actualizare detalii");
        }

        comisieDetId = item.row?.data.Id;

        editRowIndex = item.row?.rowIndex;
        var clonedData = Object.assign({}, item.row?.data);
        item.event.preventDefault();

        ShowPopup(popupDetaliiGridId);
        var frmDetaliiGridInstance = $(formDetaliiGridId).dxForm("instance");
        frmDetaliiGridInstance.option("formData", clonedData);
        global.setDateRangeValues('#dateRangeBoxDet', clonedData.DataStart, clonedData.DataStop);
    }

    var getData = function (id) {

        if (!id || id < 1) {
            ToastShowError("Id invalid!")
            return;
        }


        ajaxHelper.get(`${apiRoot}/GetComisiiPersonalDetails?comisieId=${id}`, null,
            function (response) {

                HideLoading();

                console.log(response);

                if (!response || !response.Success) {
                    ToastShowError(response.Message);
                    return;
                }

                ShowPopup(popupId);
                var frmInstance = $(formId).dxForm("instance");
                if (frmInstance != undefined) {
                    comisieModelData = response.Data;
                    frmInstance.option("formData", comisieModelData);

                    //for daterange
                    global.setDateRangeValues('#dateRangeBox', comisieModelData.DataStart, comisieModelData.DataStop);
                }
            },
            function (err) {
                ToastShowError("Au apărut erori la citirea datelor!");
                HideLoading();
            });
    }

    var onClearInfo = function () {
        comisieId = 0;
        comisieModelData = null;

        var now = new Date();
        global.setDateRangeValues('#dateRangeBox', new Date(now.getFullYear(), 0, 1), new Date(2099, 11, 31),);
    }

    var onClearInfoDetaliiGrid = function () {
        comisieDetId = 0;
    }

    var getDetaliiGridParam = function (operation, ajaxSettings) {
        if (operation == "load") {
            ajaxSettings.data.comisieId = comisieId;
        }
    }

    var onRowClick = function (item) {
        comisieId = item.data.Id;
    }

    const onUnitatiChanged = function (args) {
        if (args.component.clickedRowData !== null && args.component.clickedRowData !== undefined) {
            unitateId = args.component.clickedRowData.Id;
        } else if (args.value !== 0) {
            unitateId = args.value;
        }

        var gestiuni = $("#ddlGestiuni").dxDropDownBox("instance");
        if (gestiuni)
            gestiuni.option('value', null);
    }
    const setUnitateParam = function (operation, ajaxSettings) {
        if (operation === "load") {
            ajaxSettings.data.UnitateId = unitateId;
        }
    }
    const onGestiuniOpen = function (e) {
        e.component.getDataSource().load().then(function (data) {
            ReloadDataGrid("#ComboTipuriGestiuneGrid");
        })
    }

    const onPerioadaValueChange = function (e) {
        if (e.value === "Active") {
            toate = false;
        } else if (e.value === "Toate") {
            toate = true;
        }
        ReloadDataGrid("#gridComisiiPersonal");
    }

    const getPerioada = function () {
        return toate;
    };

    return {
        onAddAction: onAddAction,
        onResetGrid: onResetGrid,
        onDelete: onDelete,
        onCancel: onCancel,
        onSave: onSave,
        onSetPossibleOrder: onSetPossibleOrder,
        getComisiiPersonalBaseId: getComisiiPersonalBaseId,
        onEdit: onEdit,
        onRowClick: onRowClick,
        onClearInfo: onClearInfo,
        onHidingPopup: onHidingPopup,
        onAddActionDetaliiGrid: onAddActionDetaliiGrid,
        onDeleteDetaliiGrid: onDeleteDetaliiGrid,
        onCancelDetaliiGrid: onCancelDetaliiGrid,
        onHidingDetaliiGridPopup: onHidingDetaliiGridPopup,
        onSaveDetaliiGrid: onSaveDetaliiGrid,
        onEditDetaliiGrid: onEditDetaliiGrid,
        getDetaliiGridParam: getDetaliiGridParam,
        onUnitatiChanged: onUnitatiChanged,
        setUnitateParam: setUnitateParam,
        onGestiuniOpen: onGestiuniOpen,
        onPerioadaValueChange: onPerioadaValueChange,
        getPerioada: getPerioada
    }
})();