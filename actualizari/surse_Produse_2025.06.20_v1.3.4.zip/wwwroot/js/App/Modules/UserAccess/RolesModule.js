const roleModule = (function () {

    let roleId = undefined;

    const apiRoot = "/UserAccess/Roles";
    const gridId = "#grid-roles";
    const popupId = "#upsert-roles-popup";
    const formId = "#upsert-roles-form";

    const onAddAction = function (args) {
        ShowPopup(popupId);
        onClearInfo();
    }

    const onDelete = function (item) {

        console.log(item);
        
        global.onDeleteConfirmation(item, function () {

            ajaxHelper.delete(`${apiRoot}/Delete/${item.row.key}`,
                function (response) {
                    HideLoading();

                    if (!response || !response.Success) {
                        ToastShowError(response.Message);
                        return;
                    }

                    ReloadDataGrid(gridId);
                },
                function (err) {
                    ToastShowError(err.Message);
                    HideLoading();
                });
        });
    }

    const onResetGrid = function () {
        const grid = $(gridId).dxDataGrid("instance");
        grid.state({});
    }
    const onCancel = function () {
        HidePopup(popupId);
    }

    const onHidingPopup = function () {
        global.onHidingUpsertViewPopup(popupId, apiRoot, onClearInfo);
    }

    const onSave = function (item) {
        ShowLoading();

        const frmInstance = $(formId).dxForm("instance");

        if (!frmInstance.validate().isValid) {
            HideLoading();
            ToastShowError("Date Invalide!");
            return;
        }

        const formData = frmInstance.option("formData");

        const payload = {
            Id: formData.Id,
            Name: formData.Name
        };

        console.log(payload);

        ajaxHelper.post(`${apiRoot}/Upsert`,
            payload,
            function (response) {
                HideLoading();

                if (!response || !response.Success) {
                    ToastShowError(response.Message);
                    return;
                }

                HidePopup(popupId);
                ReloadDataGrid(gridId);
            },
            function (err) {
                ToastShowError(err.Message);
                HideLoading();
            });
    }
    const onEdit = function (item) {
        ShowLoading();
        onClearInfo();
        roleId = item.data.Id;
        getData(item.data.Id);
        item.cancel = true;
    }

    const getData = function (id) {

        if (!id) {
            ToastShowError("Id invalid!")
            return;
        }


        ajaxHelper.get(`${apiRoot}/GetRole?roleId=${id}`, null,
            function (response) {

                HideLoading();

                if (!response || !response.Success) {
                    ToastShowError(response.Message);
                    return;
                }

                ShowPopup(popupId);

                const frmInstance = $(formId).dxForm("instance");
                frmInstance.option("formData", response.Data);
            },
            function (err) {
                ToastShowError(err.Message);
                HideLoading();
            });
    }

    const onClearInfo = function () {
        roleId = undefined;
    }

    const onRowClick = function (item) {
        roleId = item.data.Id;
    }

    return {
        onAddAction: onAddAction,
        onResetGrid: onResetGrid,
        onDelete: onDelete,
        onCancel: onCancel,
        onSave: onSave,
        onEdit: onEdit,
        onRowClick: onRowClick,
        onHidingPopup: onHidingPopup
    }
})();
