const userModule = (function () {

    const createAction = "create";
    const updateAction = "update";
    const resetPasswordAction = "resetPassword";

    let selectedUserId = 0;
    let currentAction = "";

    const apiRoot = "/UserAccess/Users";
    const popupCreateId = "#create-user-popup";
    const popupUpdateId = "#update-user-popup";
    const popupResetPasswordId = "#reset-password-popup";


    const formCreateId = "#create-user-form";
    const formUpdateId = "#update-user-form";
    const formResetPasswordId = "#reset-password-form";

    const gridId = "#grid-users";

    const resetCurrentAction = function () {
        currentAction = "";
    }

    const setCreateAction = function (action) {
        currentAction = createAction;
    }

    const setUpdateAction = function (action) {
        currentAction = updateAction;
    }

    const setResetPasswordAction = function () {
        currentAction = resetPasswordAction;
    }

    const onAddAction = function () {
        setCreateAction();
        ShowPopup(popupCreateId);
        onClearInfo();
    }

    const getCurrentPopupId = function () {
        switch (currentAction) {
            case createAction:
                return popupCreateId;
            case updateAction:
                return popupUpdateId;
            case resetPasswordAction:
                return popupResetPasswordId;
            default:
                return "";
        }
    }

    const getCurrentApiMethodPopupView = function () {
        switch (currentAction) {
            case createAction:
                return 'GetCreatePopupView';
            case updateAction:
                return 'GetUpdatePopupView';
            case resetPasswordAction:
                return 'GetResetPasswordPopupView';
            default:
                return "";
        }
    }

    const getCurrentApiMethod = function () {
        switch (currentAction) {
            case createAction:
                return "Create";
            case updateAction:
                return "Update";
            case resetPasswordAction:
                return "ResetPassword";
            default:
                return "";
        }
    }

    const onHidingPopup = function () {

        onClearInfo();

        const popupId = getCurrentPopupId();
        $(popupId).dxPopup("dispose");
        $(popupId).load(`${apiRoot}/${getCurrentApiMethodPopupView()}`);

        resetCurrentAction();
    }

    const onSave = function () {

        const payload = getPayload();

        if (!payload) {
            ToastShowError("A aparut o eroare! Va rugam sa incercati din nou.");
            return;
        }

        ShowLoading();

        const action = getCurrentApiMethod();

        ajaxHelper.post(`${apiRoot}/${action}`, payload,
            function (response) {
                HideLoading();

                if (!response || !response.Success) {
                    ToastShowError(response.Message);
                    return;
                }

                HidePopup(getCurrentPopupId());
                ReloadDataGrid(gridId);
            },
            function (err) {
                ToastShowError(err.Message);
                HideLoading();
            });
    }

    const getPayload = function () {
        switch (currentAction) {
            case createAction:
                return validateAndGetCreatePayload();
            case updateAction:
                return validateAndGetUpdatePayload();
            case resetPasswordAction:
                return validateAndGetResetPasswordPayload();
            default:
                return;
        }
    }

    const validateAndGetCreatePayload = function () {

        const formInstance = $(formCreateId).dxForm('instance');
        const formData = formInstance.option("formData");

        console.log(formData);

        if (!formInstance.validate().isValid) {
            ToastShowError("Datele introduse sunt invalide!");
            return;
        }

        return {
            UnitateId: formData.UnitateId,
            RoleIds: $("#user-roles-dropdown").dxDropDownBox("instance").option("value"),
            Email: formData.Email,
            Username: formData.Username,
            Password: formData.Password
        };
    }

    const validateAndGetUpdatePayload = function () {

        const formInstance = $(formUpdateId).dxForm('instance');
        const formData = formInstance.option("formData");

        console.log(formData);

        if (!formInstance.validate().isValid) {
            ToastShowError("Datele introduse sunt invalide!");
            return;
        }

        return {
            Id: selectedUserId,
            UnitateId: formData.UnitateId,
            RoleIds: $("#user-roles-dropdown").dxDropDownBox("instance").option("value"),
            Email: formData.Email
        };
    }

    const validateAndGetResetPasswordPayload = function () {

        const formInstance = $(formResetPasswordId).dxForm('instance');
        const formData = formInstance.option("formData");

        console.log(formData);

        if (!formInstance.validate().isValid) {
            ToastShowError("Datele introduse sunt invalide!");
            return;
        }

        return {
            Id: selectedUserId,
            Password: formData.Password,
        };
    }

    const onCancel = function () {
        HidePopup(getCurrentPopupId());
        onHidingPopup();
    }

    const onClearInfo = function () {
        selectedUserId = 0;
    }

    const onEdit = function (item) {
        setUpdateAction();
        selectedUserId = item.data.Id;
        getData();
        item.cancel = true;
    }

    const getData = function () {

        if (selectedUserId === 0) return;

        if (!selectedUserId || selectedUserId < 0) {
            ToastShowError("Id invalid!")
            return;
        }

        ShowLoading();

        ajaxHelper.get(`${apiRoot}/GetUser?userId=${selectedUserId}`, null,
            function (response) {

                HideLoading();

                if (!response || !response.Success) {
                    ToastShowError(response.Message);
                    return;
                }

                ShowPopup(popupUpdateId);

                const frmInstance = $(formUpdateId).dxForm("instance");
                frmInstance.option("formData", response.Data);
            },
            function (err) {
                ToastShowError(err.Message);
                HideLoading();
            });
    }

    const onDelete = function (item) {

        global.onDeleteConfirmation(item, function () {

            ajaxHelper.delete(`${apiRoot}/Delete/${item.row.key}`,
                function (response) {
                    HideLoading();

                    if (!response || !response.Success) {
                        ToastShowError(response.Message);
                        return;
                    }

                    ReloadDataGrid(gridId);
                },
                function (err) {
                    ToastShowError(err.Message);
                    HideLoading();
                });
        });
    }

    const onResetPassword = function (item) {
        console.log(item);
        selectedUserId = item.row.data.Id;
        item.row.cancel = true;
        setResetPasswordAction();
        ShowPopup(popupResetPasswordId);
    }

    const gridBox_valueChanged = function (e) {
        var $dataGrid = $("#embedded-datagrid");
        console.log(e);
        console.log($dataGrid);

        if ($dataGrid.length) {
            var dataGrid = $dataGrid.dxDataGrid("instance");
            console.log(dataGrid);
            dataGrid.selectRows(e.value, false);
        }
    }

    return {
        onAddAction: onAddAction,
        onHidingPopup: onHidingPopup,
        onSave: onSave,
        onCancel: onCancel,
        onEdit: onEdit,
        onDelete: onDelete,
        onResetPassword: onResetPassword,
        gridBox_valueChanged: gridBox_valueChanged
    };
})();