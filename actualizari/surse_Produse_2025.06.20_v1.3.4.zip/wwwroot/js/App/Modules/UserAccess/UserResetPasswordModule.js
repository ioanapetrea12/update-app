﻿const userResetPasswordModule = (function () {
    let selectedUserId = "00000000-0000-0000-0000-000000000000";

    const apiRoot = "/UserAccess/Users";
    const popupResetPasswordId = "#reset-user-password-popup";
    const formResetPasswordId = "#reset-user-password-form";

    const onHidingPopup = function () {

        onClearInfo();

        const popupId = popupResetPasswordId;
        $(popupId).dxPopup("dispose");
        $(popupId).load(`${apiRoot}/GetResetUserPasswordPopupView`);
    }

    const onSave = function () {

        const payload = validateAndGetResetPasswordPayload();

        if (!payload) {
            ToastShowError("Date invalide");
            return;
        }

        ShowLoading();

        ajaxHelper.post(`${apiRoot}/ResetUserPassword`, payload,
            function (response) {
                HideLoading();

                if (!response || !response.Success) {
                    ToastShowError(response.Message);
                    return;
                }
                else {
                    ToastShowSuccess("Parola a fost schimbata cu succes!");
                }

                HidePopup(popupResetPasswordId);
            },
            function (err) {
                ToastShowError(err.Message);
                HideLoading();
            });
    }


    const validateAndGetResetPasswordPayload = function () {

        const formInstance = $(formResetPasswordId).dxForm('instance');
        const formData = formInstance.option("formData");

        console.log(formData);

        if (!formInstance.validate().isValid) {
            ToastShowError("Datele introduse sunt invalide!");
            return;
        }

        return {
            Id: selectedUserId,
            Password: formData.Password,
            ConfirmPassword: formData.ConfirmPassword,
        };
    }

    const onCancel = function () {
        HidePopup(popupResetPasswordId);
        onHidingPopup();
    }

    const onClearInfo = function () {
        selectedUserId = "00000000-0000-0000-0000-000000000000"
    }

    const onResetPassword = function (userId) {
        console.log(userId);
        selectedUserId = userId;
        ShowPopup(popupResetPasswordId);
    }


    return {
        onHidingPopup: onHidingPopup,
        onSave: onSave,
        onCancel: onCancel,
        onResetPassword: onResetPassword
    };
})();