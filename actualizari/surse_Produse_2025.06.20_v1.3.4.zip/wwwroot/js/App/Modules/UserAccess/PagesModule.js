const pageModule = (function () {

    const treeId = "#tree-page";
    const apiRoot = "/UserAccess/Pages";

    const reloadTree = function () {
        $(treeId).dxTreeList("instance").refresh();
    }

    const onSaved = function (e) {
        if (!e.changes || e.changes.length === 0) return;

        const change = e.changes[0].data;

        if (!change.Success) {
            const error = change.Errors[0];
            ToastShowError(error.Message);
            return;
        }

        ToastShowSuccess("Operatiune salvata cu succes.");
        reloadTree();
    }

    const onDelete = function (item) {

        global.onDeleteConfirmation(item, function () {

            ajaxHelper.delete(`${apiRoot}/Delete/${item.row.key}`,
                function (response) {
                    HideLoading();

                    if (!response || !response.Success) {
                        ToastShowError(response.Message);
                        return;
                    }

                    reloadTree();
                },
                function (err) {
                    ToastShowError(err.Message);
                    HideLoading();
                });
        });

    }

    return {
        onSaved: onSaved,
        onDelete: onDelete
    }
})();
