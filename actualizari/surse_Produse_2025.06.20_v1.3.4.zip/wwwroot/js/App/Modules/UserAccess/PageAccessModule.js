const pageAccessModule = (function () {

    const apiRoot = "/UserAccess/PageAccess";
    const gridId = "#grid-page-access";
    const popupId = "#upsert-page-access-popup";
    const formId = "#upsert-page-access-form";
    
    let selectedPageAccessId = undefined;

    const getData = function (id) {

        if (!id) {
            ToastShowError("Id invalid!")
            return;
        }


        ajaxHelper.get(`${apiRoot}/GetPageAccessItem?pageAccessId=${id}`, null,
            function (response) {

                HideLoading();

                if (!response || !response.Success) {
                    ToastShowError(response.Message);
                    return;
                }

                ShowPopup(popupId);

                const frmInstance = $(formId).dxForm("instance");
                frmInstance.option("formData", response.Data);
            },
            function (err) {
                ToastShowError(err.Message);
                HideLoading();
            });
    }
    
    const onSave = function () {
        ShowLoading();

        const frmInstance = $(formId).dxForm("instance");

        if (!frmInstance.validate().isValid) {
            HideLoading();
            ToastShowError("Date Invalide!");
            return;
        }

        const formData = frmInstance.option("formData");

        const payload = {
            Id: formData.Id,
            ModuleId: formData.ModuleId,
            PageId: formData.PageId,
            RoleId: formData.RoleId,
            UserId: formData.UserId,
            HasAccess: formData.HasAccess,
            CanAdd: formData.CanAdd,
            CanEdit: formData.CanEdit,
            CanDelete: formData.CanDelete,
            CanPrint: formData.CanPrint,
            CanExport: formData.CanExport,
        };

        console.log(payload);

        ajaxHelper.post(`${apiRoot}/Upsert`,
            payload,
            function (response) {
                HideLoading();

                if (!response || !response.Success) {
                    ToastShowError(response.Message);
                    return;
                }

                HidePopup(popupId);
                ReloadDataGrid(gridId);
            },
            function (err) {
                ToastShowError(err.Message);
                HideLoading();
            });
    }

    const onDelete = function (item) {

        global.onDeleteConfirmation(item, function () {

            ajaxHelper.delete(`${apiRoot}/Delete/${item.row.key}`,
                function (response) {
                    HideLoading();

                    if (!response || !response.Success) {
                        ToastShowError(response.Message);
                        return;
                    }

                    ReloadDataGrid(gridId);
                },
                function (err) {
                    ToastShowError(err.Message);
                    HideLoading();
                });
        });

    }

    const onAddAction = function () {
        console.log("onAddAction");
        ShowPopup(popupId);
        onClearInfo();
    }

    const onClearInfo = function () {
        selectedPageAccessId = undefined;
    }

    const onHidingPopup = function () {
        global.onHidingUpsertViewPopup(popupId, apiRoot, onClearInfo);
    }

    const onCancel = function () {
        HidePopup(popupId);
    }

    const onEdit = function (item) {
        ShowLoading();
        onClearInfo();
        selectedPageAccessId = item.data.Id;
        getData(item.data.Id);
        item.cancel = true;
    }
    
    return {
        onDelete: onDelete,
        onAddAction: onAddAction,
        onCancel: onCancel,
        onHidingPopup: onHidingPopup,
        onSave: onSave,
        onEdit: onEdit
    }
})();
