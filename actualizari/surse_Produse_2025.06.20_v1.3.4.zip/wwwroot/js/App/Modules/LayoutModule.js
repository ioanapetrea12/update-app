﻿const layoutModule = (function () {

    const changeTheme = function (e) {
        //        var selectedTheme = e.component.option("value");
        var selectedTheme = e.component.option('selectedItem');
        var expireDate = new Date();
        expireDate = new Date(expireDate.setFullYear(expireDate.getFullYear() + 1)).toString();
        document.cookie = "currentTheme=" + selectedTheme.Theme + ";expires=" + expireDate + ";path=/";
        document.cookie = "currentThemeID=" + selectedTheme.ID + ";expires=" + expireDate + ";path=/";
        window.location.reload();
    }

    return {
        changeTheme: changeTheme
    }

}());