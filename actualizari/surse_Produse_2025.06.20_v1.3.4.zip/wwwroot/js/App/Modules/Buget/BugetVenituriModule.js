﻿var bugetVenituriModule = (function () {
    var bugetVenituriId = 0;
    var bugetBaseId = 0;
    var programBugetarId = null;
    var activitateId = null;
    var proiectBaseId = null;
    var bugetVenituriData = {};

    var onResetGrid = function () {
        var grid = $("#gridBugetDetaliiVenituri").dxDataGrid("instance");

        grid.state({});
    }
    var onCancel = function () {
        bugetBaseId = 0;
        capitolId = null;
        programBugetarId = null;
        activitateId = null;
        proiectBaseId = null;
        modOperareId = null;
        titluId = null;

        window.location.href = '/Buget/OperareBuget/Index';
    }

    var onClearInfo = function () {
        bugetVenituriId = 0;
        bugetBaseId = 0;
        bugetVenituriModelData = null;

        capitolId = null;
        programBugetarId = null;
        activitateId = null;
        proiectBaseId = null;
        modOperareId = null;
        titluId = null;
    }

    var onToolbarPreparing = function (e) {
        var toolbarItems = e.toolbarOptions.items;
        $.each(toolbarItems, function (_, item) {
            if (item.name === "saveButton" || item.name === "revertButton") {
                item.visible = false; // ascunde butoanele save si cancel in batch edit mode
            }
        });
    }

    var onRowClick = function (item) {
        bugetVenituriId = item.data.Id;
    }

    var onProgramBugetarChange = function (e) {
        if (e.component.clickedRowData !== null && e.component.clickedRowData !== undefined) {
            programBugetarId = e.component.clickedRowData.Id;
        }
        else
            programBugetarId = e.value;

        reloadDataGrid();
    }

    var onActivitateChange = function (e) {
        if (e.component.clickedRowData !== null && e.component.clickedRowData !== undefined) {
            activitateId = e.component.clickedRowData.Id;
        }
        else
            activitateId = e.value;

        reloadDataGrid();
    }

    var onProiectBaseChange = function (e) {
        if (e.component.clickedRowData !== null && e.component.clickedRowData !== undefined) {
            proiectBaseId = e.component.clickedRowData.Id;
        }
        else
            proiectBaseId = e.value;

        reloadDataGrid();
    }

    var reloadDataGrid = function () {
        var grid = $("#gridBugetDetaliiVenituri").dxDataGrid("instance");
        if (grid) {
            grid.getDataSource().reload();
        }
    }

    var getGridsParam = function (operation, ajaxSettings) {
        if (operation === "load") {

            // Get the current URL's query parameters
            const urlParams = new URLSearchParams(window.location.search);

            // Access the 'BugetBaseId' parameter value
            bugetBaseId = urlParams.get('BugetBaseId');

            ajaxSettings.data.proiectBaseId = proiectBaseId;
            ajaxSettings.data.activitateId = activitateId;
            ajaxSettings.data.programBugetarId = programBugetarId;
            ajaxSettings.data.bugetBaseId = bugetBaseId;
        }
    }


    return {
        onToolbarPreparing: onToolbarPreparing,
        onResetGrid: onResetGrid,
        getGridsParam: getGridsParam,
        onCancel: onCancel,
        onRowClick: onRowClick,
        onClearInfo: onClearInfo,
        onProgramBugetarChange: onProgramBugetarChange,
        onActivitateChange: onActivitateChange,
        onProiectBaseChange: onProiectBaseChange

    }
})();