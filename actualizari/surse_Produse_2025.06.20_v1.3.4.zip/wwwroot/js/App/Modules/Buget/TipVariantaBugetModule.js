﻿var tipVariantaBugetModule = (function () {
    var tipVariantaBugetId = 0;
    var tipVariantaBugetlData = {};

    var onAddAction = function (args) {
        var popup = $("#upsert-tipvariantabuget-popup").dxPopup("instance");
        if (popup != undefined) {
            popup.option("title", "Adaugare");
        }
        ShowPopup("#upsert-tipvariantabuget-popup");
        onClearInfo();
    }

    var onDelete = function (item) {
        var result = DevExpress.ui.dialog.confirm("<p>Sunteti sigur/a ca doriti stergerea elementului selectat?</p>", "Stergere");
        result.done(function (dialogResult) {
            if (dialogResult) {
                if (dialogResult) {
                    var postData = {
                        Key: item.row.key
                    };
                    ajaxHelper.post("/Buget/TipVariantaBuget/Delete", postData,
                        function (response) {
                            HideLoading();
                            if (response) {
                                if (response.Success == false) {
                                    ToastShowError(response.Message);
                                    return;
                                }
                                ReloadDataGrid("#gridTipuriVariantaBuget");
                            } else {
                                ToastShowError("A aparut o eroare la stergerea intrarilor");
                            }
                        },
                        function (err) {
                            ToastShowError("An error occured");
                            HideLoading();
                        });
                }
            }
        })
    }

    var onResetGrid = function () {
        var grid = $("#gridTipuriVariantaBuget").dxDataGrid("instance");

        grid.state({});
    }
    var onCancel = function () {
        HidePopup("#upsert-tipvariantabuget-popup");
    }

    var onHidingPopup = function () {
        onClearInfo();
        $("#upsert-tipvariantabuget-popup").dxPopup("dispose");
        $("#upsert-tipvariantabuget-popup").load("/Buget/TipVariantaBuget/GetPopupTipVariantaBuget");
    }

    var onSave = function (item) {
        ShowLoading();

        var frmInstance = $("#upsert-tipvariantabuget-form").dxForm("instance");

        if (!frmInstance.validate().isValid) {
            HideLoading();
            ToastShowError("Date Invalide!");
            return;
        }

        var tipVariantaBugetData = frmInstance.option("formData");
        var postData = {
            Id: tipVariantaBugetId,
            Cod: tipVariantaBugetData.Cod,
            Denumire: tipVariantaBugetData.Denumire,
            DataStop: moment(tipVariantaBugetData.DataStop).format("YYYY-MM-DD"),
            DataStart: moment(tipVariantaBugetData.DataStart).format("YYYY-MM-DD")
        };
        console.log(postData);

        ajaxHelper.post("/Buget/TipVariantaBuget/Upsert",
            postData,
            function (response) {

                console.log(response);

                HideLoading();

                if (!response || !response.Success) {
                    ToastShowError(response.Message);
                    return;
                }

                HidePopup("#upsert-tipvariantabuget-popup");
                ReloadDataGrid("#gridTipuriVariantaBuget");
            },
            function (err) {
                ToastShowError(err.Message);
                HideLoading();
            });

        HideLoading();
    }
    var onEdit = function (item) {
        var popup = $("#upsert-tipvariantabuget-popup").dxPopup("instance");
        if (popup != undefined) {
            popup.option("title", "Actualizare");
        }
        ShowLoading();
        onClearInfo();
        tipVariantaBugetId = item.data.Id;
        getData(item.data.Id);
        item.cancel = true;
    }

    var getData = function (id) {

        if (!id || id < 1) {
            ToastShowError("Id invalid!")
            return;
        }


        ajaxHelper.get("/Buget/TipVariantaBuget/GetTipVariantaBugetDetails?tipVariantaBugetId=" + id, null,
            function (response) {

                HideLoading();

                console.log(response);

                if (!response || !response.Success) {
                    ToastShowError(response.Message);
                    return;
                }

                ShowPopup("#upsert-tipvariantabuget-popup");
                var frmInstance = $("#upsert-tipvariantabuget-form").dxForm("instance");
                if (frmInstance != undefined) {
                    tipVariantaBugetModelData = response.Data;
                    frmInstance.option("formData", tipVariantaBugetModelData);
                }
            },
            function (err) {
                ToastShowError("Au aparut erori la citirea datelor!");
                HideLoading();
            });
    }

    var onClearInfo = function () {
        tipVariantaBugetId = 0;
        tipVariantaBugetModelData = null;
    }

    var onRowClick = function (item) {
        tipVariantaBugetId = item.data.Id;
    }

    return {
        onAddAction: onAddAction,
        onResetGrid: onResetGrid,
        onDelete: onDelete,
        onCancel: onCancel,
        onSave: onSave,
        onEdit: onEdit,
        onRowClick: onRowClick,
        onHidingPopup: onHidingPopup
    }
})();