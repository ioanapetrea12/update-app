﻿var operareBugetModule = (function () {
    var operareBugetId = 0;
    var operareBugetlData = {};

    var onAddAction = function (args) {
        var popup = $("#upsert-operarebuget-popup").dxPopup("instance");
        if (popup != undefined) {
            popup.option("title", "Adaugare");
        }
        ShowPopup("#upsert-operarebuget-popup");
        onClearInfo();
    }

    var onDelete = function (item) {
        var result = DevExpress.ui.dialog.confirm("<p>Sunteti sigur/a ca doriti stergerea elementului selectat?</p>", "Stergere");
        result.done(function (dialogResult) {
            if (dialogResult) {
                if (dialogResult) {
                    var postData = {
                        Key: item.row.key
                    };
                    ajaxHelper.post("/Buget/OperareBuget/Delete", postData,
                        function (response) {
                            HideLoading();
                            if (response) {
                                if (response.Success == false) {
                                    ToastShowError(response.Message);
                                    return;
                                }
                                ReloadDataGrid("#gridOperariBuget");
                            } else {
                                ToastShowError("A aparut o eroare la stergerea intrarilor");
                            }
                        },
                        function (err) {
                            ToastShowError("An error occured");
                            HideLoading();
                        });
                }
            }
        })
    }

    var onResetGrid = function () {
        var grid = $("#gridOperariBuget").dxDataGrid("instance");

        grid.state({});
    }
    var onCancel = function () {
        HidePopup("#upsert-operarebuget-popup");
    }

    var onHidingPopup = function () {
        onClearInfo();
        $("#upsert-operarebuget-popup").dxPopup("dispose");
        $("#upsert-operarebuget-popup").load("/Buget/OperareBuget/GetPopupOperareBuget");
    }

    var onSave = function (item) {
        ShowLoading();

        var frmInstance = $("#upsert-operarebuget-form").dxForm("instance");

        if (!frmInstance.validate().isValid) {
            HideLoading();
            ToastShowError("Date Invalide!");
            return;
        }

        var operareBugetData = frmInstance.option("formData");
        var postData = {
            Id: operareBugetId,
            Nr: operareBugetData.Nr,
            Denumire: operareBugetData.Denumire,
            TipBugetId: operareBugetData.TipBugetId,
            TipVariantaBugetId: operareBugetData.TipVariantaBugetId,
            DataBuget: moment(operareBugetData.DataBuget).format("YYYY-MM-DD")
        };
        console.log(postData);

        ajaxHelper.post("/Buget/OperareBuget/Upsert",
            postData,
            function (response) {

                console.log(response);

                HideLoading();

                if (!response || !response.Success) {
                    ToastShowError(response.Message);
                    return;
                }

                HidePopup("#upsert-operarebuget-popup");
                ReloadDataGrid("#gridOperariBuget");
            },
            function (err) {
                ToastShowError(err.Message);
                HideLoading();
            });

        HideLoading();
    }
    var onEdit = function (item) {
        var popup = $("#upsert-operarebuget-popup").dxPopup("instance");
        if (popup != undefined) {
            popup.option("title", "Actualizare");
        }
        ShowLoading();
        onClearInfo();
        operareBugetId = item.data.Id;
        getData(item.data.Id);
        item.cancel = true;
    }

    var getData = function (id) {

        if (!id || id < 1) {
            ToastShowError("Id invalid!")
            return;
        }


        ajaxHelper.get("/Buget/OperareBuget/GetOperareBugetDetails?operareBugetId=" + id, null,
            function (response) {

                HideLoading();

                console.log(response);

                if (!response || !response.Success) {
                    ToastShowError(response.Message);
                    return;
                }

                ShowPopup("#upsert-operarebuget-popup");
                var frmInstance = $("#upsert-operarebuget-form").dxForm("instance");
                if (frmInstance != undefined) {
                    operareBugetModelData = response.Data;
                    frmInstance.option("formData", operareBugetModelData);
                }
            },
            function (err) {
                ToastShowError("Au aparut erori la citirea datelor!");
                HideLoading();
            });
    }

    var onClearInfo = function () {
        operareBugetId = 0;
        operareBugetModelData = null;
    }

    var onRowClick = function (item) {
        operareBugetId = item.data.Id;
    }

    return {
        onAddAction: onAddAction,
        onResetGrid: onResetGrid,
        onDelete: onDelete,
        onCancel: onCancel,
        onSave: onSave,
        onEdit: onEdit,
        onRowClick: onRowClick,
        onHidingPopup: onHidingPopup
    }
})();