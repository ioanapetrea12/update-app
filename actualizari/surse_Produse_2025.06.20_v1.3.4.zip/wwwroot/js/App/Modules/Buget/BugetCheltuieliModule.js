﻿var bugetCheltuieliModule = (function () {
    var bugetCheltuieliId = 0;
    var bugetBaseId = 0;
    var capitolId = null;
    var programBugetarId = null;
    var activitateId = null;
    var proiectBaseId = null;
    var modOperareId = null;
    var titluId = null;
    var bugetCheltuieliData = {};

    var onResetGrid = function () {
        var grid = $("#gridBugetDetaliiCheltuieli").dxDataGrid("instance");

        grid.state({});
    }
    var onCancel = function () {
        bugetBaseId = 0;
        capitolId = null;
        programBugetarId = null;
        activitateId = null;
        proiectBaseId = null;
        modOperareId = null;
        titluId = null;

        window.location.href = '/Buget/OperareBuget/Index';
    }

    var onClearInfo = function () {
        bugetCheltuieliId = 0;
        bugetBaseId = 0;
        bugetCheltuieliModelData = null;

        capitolId = null;
        programBugetarId = null;
        activitateId = null;
        proiectBaseId = null;
        modOperareId = null;
        titluId = null;
    }

    var onToolbarPreparing = function(e) {
        var toolbarItems = e.toolbarOptions.items;
        $.each(toolbarItems, function (_, item) {
            if (item.name === "saveButton" || item.name === "revertButton") {
                item.visible = false; // ascunde butoanele save si cancel in batch edit mode
            }
        });
    }

    var onRowClick = function (item) {
        bugetCheltuieliId = item.data.Id;
    }

    var onCapitolChange = function (e) {
        if (e.component.clickedRowData !== null && e.component.clickedRowData !== undefined) {
            capitolId = e.component.clickedRowData.Id;
        }
        else 
            capitolId = e.value;

        reloadDataGrid();
    }

    var onProgramBugetarChange = function (e) {
        if (e.component.clickedRowData !== null && e.component.clickedRowData !== undefined) {
            programBugetarId = e.component.clickedRowData.Id;
        }
        else 
            programBugetarId = e.value;

        reloadDataGrid();
    }

    var onActivitateChange = function (e) {
        if (e.component.clickedRowData !== null && e.component.clickedRowData !== undefined) {
            activitateId = e.component.clickedRowData.Id;
        }
        else
            activitateId = e.value;

        reloadDataGrid();
    }

    var onProiectBaseChange = function (e) {
        if (e.component.clickedRowData !== null && e.component.clickedRowData !== undefined) {
            proiectBaseId = e.component.clickedRowData.Id;
        }
        else 
            proiectBaseId = e.value;

        reloadDataGrid();
    }

    var onModOperareChange = function (e) {
        if (e.component.clickedRowData !== null && e.component.clickedRowData !== undefined) {
            modOperareId = e.component.clickedRowData.Id;
        }
        else
            modOperareId = e.value;

        reloadDataGrid();
    }

    var onTitluChange = function (e) {
        if (e.component.clickedRowData !== null && e.component.clickedRowData !== undefined) {
            titluId = e.component.clickedRowData.Id;
        }
        else
            titluId = e.value;

        reloadDataGrid();
    }

    var reloadDataGrid = function () {
        var grid = $("#gridBugetDetaliiCheltuieli").dxDataGrid("instance");
        if (grid) {
            grid.getDataSource().reload();
        }
    }

    var getGridsParam = function (operation, ajaxSettings) {
        if (operation === "load") {

            // Get the current URL's query parameters
            const urlParams = new URLSearchParams(window.location.search);

            // Access the 'BugetBaseId' parameter value
            bugetBaseId = urlParams.get('BugetBaseId');

            ajaxSettings.data.capitolId = capitolId;
            ajaxSettings.data.proiectBaseId = proiectBaseId;
            ajaxSettings.data.activitateId = activitateId;
            ajaxSettings.data.programBugetarId = programBugetarId;
            ajaxSettings.data.titluId = titluId;
            ajaxSettings.data.bugetBaseId = bugetBaseId;
        }
    }

    var onEditorPrepared = function (e) {
        if (e.parentType === "dataRow") {
        switch (e.dataField) {
            case "SumaCaT1":
            case "SumaCbT1":
            case "InfluentaCaT1":
            case "InfluentaCbT1":
            case "SumaCaT2":
            case "SumaCbT2":
            case "InfluentaCaT2":
            case "InfluentaCbT2":
                e.editorElement.dxNumberBox("instance").option("value", e.value || 0);
                break;

            case "Articol":
                // Disable editing for a specific field
                e.editorElement.attr("disabled", true);
                break;

            case "Tip":
                // Add a specific CSS class to the editor for styling
                e.editorElement.addClass("highlight-editor");
                break;

            default:
                // Apply any generic customizations here
                break;
        }
    }
}


    return {
        onToolbarPreparing: onToolbarPreparing,
        onResetGrid: onResetGrid,
        getGridsParam: getGridsParam,
        onCancel: onCancel,
        onRowClick: onRowClick,
        onClearInfo: onClearInfo,
        onCapitolChange: onCapitolChange,
        onProgramBugetarChange: onProgramBugetarChange,
        onActivitateChange: onActivitateChange,
        onProiectBaseChange: onProiectBaseChange,
        onModOperareChange: onModOperareChange,
        onTitluChange: onTitluChange,
        onEditorPrepared: onEditorPrepared

    }
})();