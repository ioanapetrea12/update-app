﻿var tipBugetModule = (function () {
    var tipBugetId = 0;
    var tipBugetlData = {};

    var onAddAction = function (args) {
        var popup = $("#upsert-tipbuget-popup").dxPopup("instance");
        if (popup != undefined) {
            popup.option("title", "Adaugare");
        }
        ShowPopup("#upsert-tipbuget-popup");
        onClearInfo();
    }

    var onDelete = function (item) {
        var result = DevExpress.ui.dialog.confirm("<p>Sunteti sigur/a ca doriti stergerea elementului selectat?</p>", "Stergere");
        result.done(function (dialogResult) {
            if (dialogResult) {
                if (dialogResult) {
                    var postData = {
                        Key: item.row.key
                    };
                    ajaxHelper.post("/Buget/TipBuget/Delete", postData,
                        function (response) {
                            HideLoading();
                            if (response) {
                                if (response.Success == false) {
                                    ToastShowError(response.Message);
                                    return;
                                }
                                ReloadDataGrid("#gridTipuriBuget");
                            } else {
                                ToastShowError("A aparut o eroare la stergerea intrarilor");
                            }
                        },
                        function (err) {
                            ToastShowError("An error occured");
                            HideLoading();
                        });
                }
            }
        })
    }

    var onResetGrid = function () {
        var grid = $("#gridTipuriBuget").dxDataGrid("instance");

        grid.state({});
    }
    var onCancel = function () {
        HidePopup("#upsert-tipbuget-popup");
    }

    var onHidingPopup = function () {
        onClearInfo();
        $("#upsert-tipbuget-popup").dxPopup("dispose");
        $("#upsert-tipbuget-popup").load("/Buget/TipBuget/GetPopupTipBuget");
    }

    var onSave = function (item) {
        ShowLoading();

        var frmInstance = $("#upsert-tipbuget-form").dxForm("instance");

        if (!frmInstance.validate().isValid) {
            HideLoading();
            ToastShowError("Date Invalide!");
            return;
        }

        var tipBugetData = frmInstance.option("formData");
        var postData = {
            Id: tipBugetId,
            Cod: tipBugetData.Cod,
            Denumire: tipBugetData.Denumire,
            DenumireScurta: tipBugetData.DenumireScurta,
            DataStop: moment(tipBugetData.DataStop).format("YYYY-MM-DD"),
            DataStart: moment(tipBugetData.DataStart).format("YYYY-MM-DD")
        };
        console.log(postData);

        ajaxHelper.post("/Buget/TipBuget/Upsert",
            postData,
            function (response) {

                console.log(response);

                HideLoading();

                if (!response || !response.Success) {
                    ToastShowError(response.Message);
                    return;
                }

                HidePopup("#upsert-tipbuget-popup");
                ReloadDataGrid("#gridTipuriBuget");
            },
            function (err) {
                ToastShowError(err.Message);
                HideLoading();
            });

        HideLoading();
    }
    var onEdit = function (item) {
        var popup = $("#upsert-tipbuget-popup").dxPopup("instance");
        if (popup != undefined) {
            popup.option("title", "Actualizare");
        }
        ShowLoading();
        onClearInfo();
        tipBugetId = item.data.Id;
        getData(item.data.Id);
        item.cancel = true;
    }

    var getData = function (id) {

        if (!id || id < 1) {
            ToastShowError("Id invalid!")
            return;
        }


        ajaxHelper.get("/Buget/TipBuget/GetTipBugetDetails?tipBugetId=" + id, null,
            function (response) {

                HideLoading();

                console.log(response);

                if (!response || !response.Success) {
                    ToastShowError(response.Message);
                    return;
                }

                ShowPopup("#upsert-tipbuget-popup");
                var frmInstance = $("#upsert-tipbuget-form").dxForm("instance");
                if (frmInstance != undefined) {
                    tipBugetModelData = response.Data;
                    frmInstance.option("formData", tipBugetModelData);
                }
            },
            function (err) {
                ToastShowError("Au aparut erori la citirea datelor!");
                HideLoading();
            });
    }

    var onClearInfo = function () {
        tipBugetId = 0;
        tipBugetModelData = null;
    }

    var onRowClick = function (item) {
        tipBugetId = item.data.Id;
    }

    return {
        onAddAction: onAddAction,
        onResetGrid: onResetGrid,
        onDelete: onDelete,
        onCancel: onCancel,
        onSave: onSave,
        onEdit: onEdit,
        onRowClick: onRowClick,
        onHidingPopup: onHidingPopup
    }
})();