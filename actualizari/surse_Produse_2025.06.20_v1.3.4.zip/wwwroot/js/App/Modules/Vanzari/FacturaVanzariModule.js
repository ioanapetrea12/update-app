﻿var facturaVanzariModule = (function () {
    const dataLucru = new Date(window.AppConfig.dataLucru);

    var facturaVanzariId = 0;
    var partenerId = 0;
    var contractId = 0;
    var documentBaseIdPrimar = 0;
    var configurareId = 0;
    var baseSumaFactura = 0; 
    var facturaVanzariModelData = {};
    var selectedIds = [];
    var isStorno = false;
    var topFacturiId = 0;

    const apiRoot = "/Vanzari/FacturaVanzari";
    const gridId = "#gridFacturaVanzari";
    const gridLnkId = "#gridLnksVanzari";
    const popupId = "#upsert-facturavanzari-popup";
    const formId = "#upsert-facturavanzari-form";

    var unitateId = '00000000-0000-0000-0000-000000000000';

    var onAddAction = function (args) {
        var popup = $(popupId).dxPopup("instance");
        if (popup !== undefined) {
            popup.option("title", "Adaugare");
        }
        ShowPopup(popupId);
        setFieldsReadOnly(false);
        onClearInfo();

        var frmInstance = $(formId).dxForm("instance");
        //implicit campul StareSold este 0 - "In Sold"
        frmInstance.option("formData.StareSold", 0);
        var numberBoxSumaFacturaInstance = $("#SumaFactura").dxNumberBox("instance");

        if (numberBoxSumaFacturaInstance) {
            numberBoxSumaFacturaInstance.option("readOnly", true);
        }
        else {
            console.error("NumberBox instance SumaFactura not found at the time of execution.");
        }

        var dataBoxDataFacturaInstance = $("#DataFactura").dxDateBox("instance");

        if (dataBoxDataFacturaInstance) {
            dataBoxDataFacturaInstance.option("value", dataLucru);
        }
        else {
            console.error("DateBox instance DataFactura not found at the time of execution.");
        }

        var selectBoxStareSoldInstance = $("#StareSold").dxSelectBox("instance");

        if (selectBoxStareSoldInstance) {
            selectBoxStareSoldInstance.option("readOnly", true);
        } else {
            console.error("SelectBox instance StareSold not found at the time of execution.");
        }
    }

    var onDelete = function (item) {
        var result = DevExpress.ui.dialog.confirm("<p>Sunteti sigur/a ca doriti stergerea elementului selectat?</p>", "Stergere");
        result.done(function (dialogResult) {
            if (dialogResult) {
                ajaxHelper.delete(`${apiRoot}/Delete/${item.row.key}`,
                    function (response) {
                        HideLoading();
                        if (response) {
                            ReloadDataGrid(gridId);
                        } else {
                            ToastShowError("A aparut o eroare la stergerea intrarilor");
                        }
                    },
                    function (err) {
                        ToastShowError("An error occured");
                        HideLoading();
                    });
            }
        })
    }

    var onResetGrid = function () {
        var grid = $(gridId).dxDataGrid("instance");

        grid.state({});
    }
    var onCancel = function () {
        HidePopup(popupId);
    }

    var onHidingPopup = function () {
        global.onHidingUpsertViewPopup(popupId, apiRoot, onClearInfo);
    }

    var onSave = function (item) {
        ShowLoading();

        var frmInstance = $(formId).dxForm("instance");

        if (!frmInstance.validate().isValid) {
            HideLoading();
            ToastShowError("Date Invalide!");
            return;
        }

        if (facturaVanzariId > 0 && !isStorno) {
            //add the Id column from the grid with lnks to the selectedIds array
            var gridLnks = $(gridLnkId).dxDataGrid("instance");
            var allRows = gridLnks.getDataSource().items();

            selectedIds = allRows.map(function (row) {
                return row.Id;
            });

            ToastShowError("Nu puteti modifica o factura!");
            HideLoading();
            return;
        }
        
        var facturaVanzariData = frmInstance.option("formData");

        if (selectedIds.length === 0 && !isStorno) {
            ToastShowError("Nu ati selectat nici un aviz!");
            HideLoading();
            return;
        }

        var postData = {
            Id: facturaVanzariId,
            UnitatiId: unitateId,
            ConfigFacturiId: facturaVanzariData.ConfigFacturiId,
            TopFacturiId: facturaVanzariData.TopFacturiId,
            PartenerId: facturaVanzariData.PartenerId,
            ContractBaseId: facturaVanzariData.ContractBaseId,
            SerieFactura: facturaVanzariData.SerieFactura,
            NrFactura: facturaVanzariData.NrFactura,
            SumaFactura: facturaVanzariData.SumaFactura,
            DataFactura: moment(facturaVanzariData.DataFactura).format("YYYY-MM-DD"),
            StareSold: facturaVanzariData.StareSold,
            IsStorno: isStorno,
            ProcentAdaos: facturaVanzariData.ProcentAdaos,
            ConfigFacturiIdAdaos: facturaVanzariData.ConfigFacturiIdAdaos,
            ListaAvize: selectedIds,
        };

        ajaxHelper.post(`${apiRoot}/Upsert`,
            postData,
            function (response) {
                HideLoading();

                if (!response || !response.Success) {
                    ToastShowError(response.Message);
                    return;
                }

                HidePopup(popupId);
                ReloadDataGrid(gridId);
            },
            function (err) {
                ToastShowError(err.Message);
                HideLoading();
            });

        HideLoading();
    }

    var onEdit = function (item, bStorno = false) {
        var popup = $(popupId).dxPopup("instance");
        if (popup !== undefined) {
            popup.option("title", isStorno ? "Stornare factura" : "Actualizare");
        }
        ShowLoading();
        onClearInfo();
        isStorno = bStorno;
        let data = item.data?item.data:item.row.data;
        facturaVanzariId = data.Id;
        getData(data.Id);
        item.cancel = true;
    }

    var getData = function (id) {
        if (!id || id < 1) {
            ToastShowError("Id invalid!")
            return;
        }

        ajaxHelper.get(`${apiRoot}/GetFacturaVanzariDetails?facturaVanzariId=${id}`, null,
            function (response) {

                HideLoading();

                if (!response || !response.Success) {
                    ToastShowError(response.Message);
                    return;
                }

                ShowPopup(popupId);
                var frmInstance = $(formId).dxForm("instance");
                if (frmInstance !== undefined) {
                    frmInstance.option("formData", response.Data);

                    //setare readOnly pentru campuri la editare
                    setFieldsReadOnly(true);

                    if (isStorno) {
                        var dataBoxDataFacturaInstance = $("#DataFactura").dxDateBox("instance");

                        if (dataBoxDataFacturaInstance) {
                            dataBoxDataFacturaInstance.option("value", dataLucru);
                            dataBoxDataFacturaInstance.option("label", "Data storno factura");
                        }
                        else {
                            console.error("DateBox instance DataFactura not found at the time of execution.");
                        }
                    }
                }
            },
            function (err) {
                ToastShowError("Au aparut erori la citirea datelor!");
                HideLoading();
            });
    }

    var onClearInfo = function () {
        facturaVanzariId = 0;
        topFacturiId = 0;
        partenerId = 0;
        contractId = 0;
        documentBaseIdPrimar = 0;
        unitateId = '00000000-0000-0000-0000-000000000000';
        configurareId = 0;
        selectedIds = [];
        isStorno = false;
    }

    var onRowClick = function (item) {
        facturaVanzariId = item.data.Id;
    }

    var getPartenerId = function () {
        return partenerId;
    }

    var getLnkGridParam  = function (operation, ajaxSettings) {
        if (operation === "load") {
            ajaxSettings.data.unitatiId = unitateId;
            ajaxSettings.data.facturaId = facturaVanzariId;
            ajaxSettings.data.partenerId = partenerId;
            ajaxSettings.data.contractId = contractId;
        }
    }

    var getDocumentBaseIdPrimar = function () {
        return documentBaseIdPrimar;
    }

    var onTopFacturiChange = function (args) {
        if (args.component.clickedRowData !== null && args.component.clickedRowData !== undefined) {
            var clickedData = args.component.clickedRowData;
            topFacturiId = args.component.clickedRowData.Id;
            var frmInstance = $(formId).dxForm("instance");
            frmInstance.option("formData.SerieFactura", clickedData.Serie);
            frmInstance.option("formData.NrFactura", clickedData.NumarCurent.toString());
        } else {
            topFacturiId = args.value;
        }
    }

    var onUnitatiChanged = function (args) {
        if (args.component.clickedRowData !== null && args.component.clickedRowData !== undefined) {
            unitateId = args.component.clickedRowData.Id;
        } else if (args.value !== 0) {
            unitateId = args.value;
        }

        var topFacturiDropdown = $("#TopFacturiId").dxDropDownBox("instance");
        if (topFacturiDropdown) {
            topFacturiDropdown.option("value", null);
            topFacturiDropdown.getDataSource().reload();
        }

        var contractDropdown = $("#ContractBaseId").dxDropDownBox("instance");
        if (contractDropdown) {
            contractDropdown.option("value", null);
            contractDropdown.getDataSource().reload();
        }

        ReloadDataGrid(gridLnkId);
    }

    var onPartenerChange = function (args) {
        if (args.component.clickedRowData !== null && args.component.clickedRowData !== undefined) {
            partenerId = args.component.clickedRowData.Id;
        }
        else {
            partenerId = args.value;
        }

        var contractDropdown = $("#ContractBaseId").dxDropDownBox("instance");
        if (contractDropdown) {
            contractDropdown.option("value", null);
            contractDropdown.getDataSource().reload();
        }

        ReloadDataGrid(gridLnkId);
    }

    var onContractChange = function (args) {
        if (args.component.clickedRowData !== null && args.component.clickedRowData !== undefined) {
            contractId = args.component.clickedRowData.Id;
        }
        else {
            contractId = args.value;
        }
        ReloadDataGrid(gridLnkId);
    }

    var onProcentAdaosChange = function (args) {
        let procentAdaos = args.value;

        var dropDownConfigAdaosInstance = $("#ConfigFacturiIdAdaos").dxDropDownBox("instance");

        let isConfigAdaosReadonly = (procentAdaos == 0);

        if (dropDownConfigAdaosInstance) {
            dropDownConfigAdaosInstance.option("readOnly", isConfigAdaosReadonly);
            dropDownConfigAdaosInstance.focus();
        } else {
            console.error("DropDownBox instance ConfigFacturiIdAdaos not found at the time of execution.");
        }
    }

    var onConfigurareChange = function (args) {
        if (args.component.clickedRowData !== null && args.component.clickedRowData !== undefined) {
            configurareId = args.component.clickedRowData.Id;
        }
        else {
            configurareId = args.value;
        }
    }

    var setFieldsReadOnly = function (isReadonly) {
        var dropDownUnitatiInstance = $("#UnitatiId").dxDropDownBox("instance");

        if (dropDownUnitatiInstance) {
            dropDownUnitatiInstance.option("readOnly", isReadonly);
        }
        else {
            console.error("DropDownBox instance UnitatiId not found at the time of execution.");
        }

        var dropDownTopFacturiInstance = $("#TopFacturiId").dxDropDownBox("instance");

        if (dropDownTopFacturiInstance) {
            dropDownTopFacturiInstance.option("readOnly", isReadonly);
        } else {
            console.error("DropDownBox instance TopFacturiId not found at the time of execution.");
        }

        var dropDownConfigInstance = $("#ConfigFacturiId").dxDropDownBox("instance");

        if (dropDownConfigInstance) {
            dropDownConfigInstance.option("readOnly", isReadonly);
        } else {
            console.error("DropDownBox instance ConfigFacturiId not found at the time of execution.");
        }

        var dropDownConfigAdaosInstance = $("#ConfigFacturiIdAdaos").dxDropDownBox("instance");

        if (dropDownConfigAdaosInstance) {
            dropDownConfigAdaosInstance.option("readOnly", isReadonly);
        } else {
            console.error("DropDownBox instance ConfigFacturiIdAdaos not found at the time of execution.");
        }

        var dropDownPartenerInstance = $("#PartenerId").dxDropDownBox("instance");

        if (dropDownPartenerInstance) {
            dropDownPartenerInstance.option("readOnly", isReadonly);
        }
        else {
            console.error("DropDownBox instance PartenerId not found at the time of execution.");
        }

        var dropDownContractInstance = $("#ContractBaseId").dxDropDownBox("instance");

        if (dropDownContractInstance) {
            dropDownContractInstance.option("readOnly", isReadonly);
        }
        else {
            console.error("DropDownBox instance ContractBaseId not found at the time of execution.");
        }

        var selectBoxStareSoldInstance = $("#StareSold").dxSelectBox("instance");

        if (selectBoxStareSoldInstance) {
            selectBoxStareSoldInstance.option("readOnly", isReadonly);
        } else {
            console.error("SelectBox instance StareSold not found at the time of execution.");
        }

        var textBoxNrFacturaInstance = $("#NrFactura").dxTextBox("instance");

        if (textBoxNrFacturaInstance) {
            textBoxNrFacturaInstance.option("readOnly", isReadonly);
        }
        else {
            console.error("TextBox instance NrFactura not found at the time of execution.");
        }

        var textBoxSerieFacturaInstance = $("#SerieFactura").dxTextBox("instance");

        if (textBoxSerieFacturaInstance) {
            textBoxSerieFacturaInstance.option("readOnly", isReadonly);
        }
        else {
            console.error("TextBox instance NrFactura not found at the time of execution.");
        }

        var dateBoxDataFacturaInstance = $("#DataFactura").dxDateBox("instance");

        if (dateBoxDataFacturaInstance) {
            dateBoxDataFacturaInstance.option("readOnly", !isStorno?isReadonly:false);
        }
        else {
            console.error("DateBox instance DataFactura not found at the time of execution.");
        }

        var numberBoxSumaFacturaInstance = $("#SumaFactura").dxNumberBox("instance");

        if (numberBoxSumaFacturaInstance) {
            numberBoxSumaFacturaInstance.option("readOnly", isReadonly);
        }
        else {
            console.error("NumberBox instance SumaFactura not found at the time of execution.");
        }

        var gridListaAvizeInstance = $("#gridLnksVanzari").dxDataGrid("instance");

        if (gridListaAvizeInstance) {
            gridListaAvizeInstance.option("selection.mode", isReadonly ? "none" : "multiple");
        }
        else {
            console.error("DataGrid instance gridLnksVanzari not found at the time of execution.");
        }
    }

    var initSumaCalculator = function () {
        var numberBox = $("#SumaFactura").dxNumberBox("instance");
        if (numberBox) {
            baseSumaFactura = parseFloat(numberBox.option("value")) || 0;
        }
    };

    var onGridSelectionChanged = function (e) {
        var addedIds = e.currentSelectedRowKeys;    // IDs that were just selected.
        var removedIds = e.currentDeselectedRowKeys;  // IDs that were just deselected.

        addedIds.forEach(function (id) {
            if (selectedIds.indexOf(id) === -1) {
                selectedIds.push(id);
            }
        });

        removedIds.forEach(function (id) {
            var index = selectedIds.indexOf(id);
            if (index !== -1) {
                selectedIds.splice(index, 1);
            }
        });

        console.log("Selected IDs:", selectedIds);

        var grid = e.component;
        var selectedRows = grid.getSelectedRowsData();
        var additionalSum = 0;

        for (var i = 0; i < selectedRows.length; i++) {
            additionalSum += parseFloat(selectedRows[i].Suma) || 0;
        }

        var newTotal = baseSumaFactura + additionalSum;
        var numberBox = $("#SumaFactura").dxNumberBox("instance");
        if (numberBox) {
            numberBox.option("value", newTotal);
        }
    };

    var onPopupShown = function (e) {
        initSumaCalculator();
    };

    var onListareFactura = function (item) {
        var codRaport = -9;
        var facturaId = item.row.data.Id;
        ShowLoading();
        ajaxHelper.get(`${apiRoot}/GetFacturaLinkRaport?facturaId=${facturaId}&codInternRaport=${codRaport}`, null,
            function (response) {
                if (!response || !response.Success) {
                    ToastShowError(response.Message);
                    return;
                }

                window.open(response.Data, '_blank');
                HideLoading();
            },
            function (error) {

            });
        HideLoading();
    };

    var onStornareFactura = function (item) {
        isStorno = true;
        onEdit(item, isStorno);
        $('.lista-avize-group').hide();
    };

    const setUnitateParam = function (operation, ajaxSettings) {
        if (operation === "load") {
            ajaxSettings.data.UnitateId = unitateId;
        }
    }

    var onPopupShown = function (e) {
        initSumaCalculator();
    };

    var onDownloadXMLEFactura = function (id) {
        var body = {
            Id: id
        }
        ajaxHelper.post(`${apiRoot}/DownloadXMLEFactura`, body,
            function (response) {
                if (!response || !response.Success) {
                    ToastShowError(response.Message);
                    return;
                }
                const fileName = response.Data.FileName;
                const contentBase64 = response.Data.Content; // This is the Base64 encoded string
                const fileType = response.Data.FileType;

                // Convert the Base64 string to a Blob
                const blob = base64ToBlob(contentBase64, fileType);
                const link = document.createElement('a');
                link.href = URL.createObjectURL(blob);
                link.download = fileName;
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
                URL.revokeObjectURL(link.href);
            },
            function (err) {
                ToastShowError("Au aparut erori la citirea datelor!");
                HideLoading();
            });
    };

    // Function to convert a Base64 string to a Blob
    const base64ToBlob = (base64, fileType) => {
        const byteCharacters = atob(base64);
        const byteNumbers = new Array(byteCharacters.length);
        for (let i = 0; i < byteCharacters.length; i++) {
            byteNumbers[i] = byteCharacters.charCodeAt(i);
        }
        const byteArray = new Uint8Array(byteNumbers);
        return new Blob([byteArray], { type: fileType });
    };

    return {
        onAddAction: onAddAction,
        getPartenerId: getPartenerId,
        getDocumentBaseIdPrimar: getDocumentBaseIdPrimar,
        getLnkGridParam: getLnkGridParam,
        setFieldsReadOnly: setFieldsReadOnly,
        setUnitateParam: setUnitateParam,
        onTopFacturiChange: onTopFacturiChange,
        onUnitatiChanged: onUnitatiChanged,
        onPartenerChange: onPartenerChange,
        onContractChange: onContractChange,
        onConfigurareChange: onConfigurareChange,
        onProcentAdaosChange: onProcentAdaosChange,
        onDownloadXMLEFactura: onDownloadXMLEFactura,
        onResetGrid: onResetGrid,
        onDelete: onDelete,
        onCancel: onCancel,
        onSave: onSave,
        onEdit: onEdit,
        onRowClick: onRowClick,
        onHidingPopup: onHidingPopup,
        initSumaCalculator: initSumaCalculator,
        onGridSelectionChanged: onGridSelectionChanged,
        onPopupShown: onPopupShown,
        onListareFactura: onListareFactura,
        onStornareFactura: onStornareFactura
    }
})();