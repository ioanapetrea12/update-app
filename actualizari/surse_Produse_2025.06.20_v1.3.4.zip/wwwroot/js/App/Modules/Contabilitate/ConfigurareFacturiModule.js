﻿var configurareFacturiModule = (function () {
    var configurareFacturiId = 0;

    const apiRoot = "/Contabilitate/ConfigurareFacturi";
    const gridId = "#gridConfigurareFacturi";
    const popupId = "#upsert-configurarefacturi-popup";
    const formId = "#upsert-configurarefacturi-form";

    var onAddAction = function (args) {
        var popup = $(popupId).dxPopup("instance");
        if (popup !== undefined) {
            popup.option("title", "Adaugare");
        }
        ShowPopup(popupId);
        onClearInfo();
    }

    var onDelete = function (item) {
        var result = DevExpress.ui.dialog.confirm("<p>Sunteti sigur/a ca doriti stergerea elementului selectat?</p>", "Stergere");
        result.done(function (dialogResult) {
            if (dialogResult) {
                ajaxHelper.delete(`${apiRoot}/Delete/${item.row.key}`,
                    function (response) {
                        HideLoading();
                        if (response) {
                            if (response.Success == false) {
                                ToastShowError(response.Message);
                                return;
                            }
                            ReloadDataGrid(gridId);
                        } else {
                            ToastShowError("A aparut o eroare la stergerea intrarilor");
                        }
                    },
                    function (err) {
                        ToastShowError("An error occured");
                        HideLoading();
                    });
            }
        })
    }

    var onResetGrid = function () {
        var grid = $(gridId).dxDataGrid("instance");

        grid.state({});
    }
    var onCancel = function () {
        HidePopup(popupId);
    }

    var onHidingPopup = function () {
        global.onHidingUpsertViewPopup(popupId, apiRoot, onClearInfo);
    }

    var onSave = function (item) {
        ShowLoading();

        var frmInstance = $(formId).dxForm("instance");

        if (!frmInstance.validate().isValid) {
            HideLoading();
            ToastShowError("Date Invalide!");
            return;
        }

        var configurareFacturiData = frmInstance.option("formData");

        var postData = {
            Id: configurareFacturiId,
            PlanContIdDebit: configurareFacturiData.PlanContIdDebit,
            PlanContIdCredit: configurareFacturiData.PlanContIdCredit,
            TextStandard: configurareFacturiData.TextStandard,
            NrNotaContabila: configurareFacturiData.NrNotaContabila,
            FunctionalaId: configurareFacturiData.FunctionalaId,
            EconomicaId: configurareFacturiData.EconomicaId,
            TipOpExecutieId: configurareFacturiData.TipOpExecutieId,
            MonedaId: configurareFacturiData.MonedaId,
            CotaTvaid: configurareFacturiData.CotaTvaid,
            Adaos: configurareFacturiData.Adaos,
        };

        ajaxHelper.post(`${apiRoot}/Upsert`,
            postData,
            function (response) {
                HideLoading();

                if (!response || !response.Success) {
                    ToastShowError(response.Message);
                    return;
                }

                HidePopup(popupId);
                ReloadDataGrid(gridId);
            },
            function (err) {
                ToastShowError(err.Message);
                HideLoading();
            });

        HideLoading();
    }
    var onEdit = function (item) {
        var popup = $(popupId).dxPopup("instance");
        if (popup !== undefined) {
            popup.option("title", "Actualizare");
        }
        ShowLoading();
        onClearInfo();
        configurareFacturiId = item.data.Id;
        getData(item.data.Id);
        item.cancel = true;
    }

    var getData = function (id) {

        if (!id || id < 1) {
            ToastShowError("Id invalid!")
            return;
        }

        ajaxHelper.get(`${apiRoot}/GetConfigurareFacturiDetails?configurareFacturiId=${id}`, null,
            function (response) {

                HideLoading();

                if (!response || !response.Success) {
                    ToastShowError(response.Message);
                    return;
                }

                ShowPopup(popupId);
                var frmInstance = $(formId).dxForm("instance");
                if (frmInstance !== undefined) {
                    frmInstance.option("formData", response.Data);
                }
            },
            function (err) {
                ToastShowError("Au aparut erori la citirea datelor!");
                HideLoading();
            });
    }

    var onClearInfo = function () {
        configurareFacturiId = 0;
    }

    var onRowClick = function (item) {
        configurareFacturiId = item.data.Id;
    }

    return {
        onAddAction: onAddAction,
        onResetGrid: onResetGrid,
        onDelete: onDelete,
        onCancel: onCancel,
        onSave: onSave,
        onEdit: onEdit,
        onRowClick: onRowClick,
        onHidingPopup: onHidingPopup
    }
})();