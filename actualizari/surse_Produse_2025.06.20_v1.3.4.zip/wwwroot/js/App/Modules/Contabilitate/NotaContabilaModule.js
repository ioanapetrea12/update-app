﻿const notaContabilaModule = (function () {
    const dataLucru = new Date(window.AppConfig.dataLucru);
    var notaContabilaId = 0;
    var tranzactId = 0;
    var documentId = 0;
    var monedaId = 0;
    var editRowIndex = -1;
    var isReadOnly = false;
    var notaContabilaModelData = {};

    var bAdaugare = false;
    var selectedAn = 0;
    var selectedLuna = 0;
    var selectedUnitate = null;
    var unitateId = '00000000-0000-0000-0000-000000000000';

    const apiRoot = "/Contabilitate/NotaContabila";
    const apiRootCursValutar = "/Nomenclatoare/CursValutar";

    const gridId = "#gridNotaContabila";
    const gridTranzactId = "#grid-tranzact-note-contabile";
    const popupId = "#upsert-notaContabila-popup";
    const popupTranzactId = "#upsert-notaContabilaTranzact-popup";
    const formId = "#upsert-notaContabila-form";
    const formTranzactId = "#upsert-notaContabilaTranzact-form";

    const onAddAction = function (args) {
        var popup = $(popupId).dxPopup("instance");
        if (popup != undefined) {
            popup.option("title", "Adaugare");
        }
        ShowPopup(popupId);
        onClearInfo();

        bAdaugare = true;

        var dropdownBoxUnitateInstance = $("#UnitatiId").dxDropDownBox("instance");
        if (dropdownBoxUnitateInstance) {
            dropdownBoxUnitateInstance.option("value", selectedUnitate);
        }
        else {
            console.error("DropDownBox instance UnitatiId not found at the time of execution.");
        }

        var dropdownBoxMonedaInstance = $("#MonedaIdValuta").dxDropDownBox("instance");
        if (dropdownBoxMonedaInstance) {
            dropdownBoxMonedaInstance.option("value", 33);
        }
        else {
            console.error("DropDownBox instance MonedaIdValuta not found at the time of execution.");
        }

        var numberBoxCursValutarInstance = $("#CursValutar").dxNumberBox("instance");
        if (numberBoxCursValutarInstance) {
            numberBoxCursValutarInstance.option("disabled", true);
        }
        else {
            console.error("NumberBox instance CursValutar not found at the time of execution.");
        }

        var dataBoxDataDocumentInstance = $("#DataDocument").dxDateBox("instance");

        if (dataBoxDataDocumentInstance) {
            dataBoxDataDocumentInstance.option("value", dataLucru);
        }
        else {
            console.error("DateBox instance DataDocument not found at the time of execution.");
        }

        var dataBoxDataInregistrareInstance = $("#DataInregistrare").dxDateBox("instance");

        if (dataBoxDataInregistrareInstance) {
            dataBoxDataInregistrareInstance.option("value", dataLucru);
        }
        else {
            console.error("DateBox instance DataInregistrare not found at the time of execution.");
        }

        var checkBoxIsStornoInstance = $("#IsStorno").dxCheckBox("instance");

        if (checkBoxIsStornoInstance) {
            checkBoxIsStornoInstance.option("value", false);
        }
        else {
            console.error("CheckBox instance IsStorno not found at the time of execution.");
        }
    }

    const onAddActionTranzactGrid = function (args) {
        editRowIndex = -1;
        var popup = $(popupTranzactId).dxPopup("instance");
        if (popup != undefined) {
            popup.option("title", "Adaugare tranzactie");
        }
        ShowPopup(popupTranzactId);
        onClearInfoTranzactGrid();
    }

    const onDelete = function (item) {
        var result = DevExpress.ui.dialog.confirm("<p>Sunteti sigur/a ca doriti stergerea elementului selectat?</p>", "Stergere");
        result.done(function (dialogResult) {
            if (dialogResult) {
                ajaxHelper.delete(`${apiRoot}/Delete/${item.row.key}`,
                    function (response) {
                        HideLoading();
                        if (response) {
                            if (response.Success == false) {
                                ToastShowError(response.Message);
                                return;
                            }
                            ReloadDataGrid(gridId);
                        } else {
                            ToastShowError("A aparut o eroare la stergerea intrarilor");
                        }
                    },
                    function (err) {
                        ToastShowError("An error occured");
                        HideLoading();
                    });
            }
        })
    }

    const onDeleteTranzactGrid = function (item) {
        var gridTranzactInstance = $(gridTranzactId).dxDataGrid("instance");
        var result = DevExpress.ui.dialog.confirm("<p>Sunteti sigur ca doriti stergerea elementului selectat?</p>", "Stergere");
        result.done(function (dialogResult) {
            deletedRowIndex = item.row.rowIndex;

            if (dialogResult) {
                gridTranzactInstance.deleteRow(deletedRowIndex);
                gridTranzactInstance.element().find(".dx-row-removed").hide();
            }
        });
    }

    const collectBatchGridData = function (bReturnAllDataAsNewLines = false) {
        if (!IsDataGridInstance(gridTranzactId)) {
            return;
        }

        var tranzactii = GetModifiedDataFromGrid(gridTranzactId);
        var model = {
            Id: 0,
            NrCrt: 0,
            PlanContIdDebit: 0,
            PlanContIdCredit: 0,
            PartenerIdDebit: 0,
            PartenerIdCredit: 0,
            DocumentIdPrimar: 0,
            DocumentIdDebit: 0,
            DocumentIdCredit: 0,
            FunctionalaId: 0,
            EconomicaId: 0,
            Suma: 0,
            SumaValuta: 0,
            Explicatii: "",
            TipOpExecutieId: 0,
            ProgramBugetarId: 0,
            ProiectBaseId: 0,
            ContractBaseId: 0,
            IsActive: true
        };

        return CustomCopyTo(model, tranzactii, bReturnAllDataAsNewLines);
    }

    const collectAllGridDataAsModified = function () {
        if (!IsDataGridInstance(gridTranzactId)) {
            return;
        }

        var dataGridInstance = $(gridTranzactId).dxDataGrid("instance");

        var dataSource = dataGridInstance.getDataSource();
        // Get all loaded data items
        var tranzactii = dataSource.items();
        var model = {
            Id: 0,
            NrCrt: 0,
            PlanContIdDebit: 0,
            PlanContIdCredit: 0,
            PartenerIdDebit: 0,
            PartenerIdCredit: 0,
            DocumentIdPrimar: 0,
            DocumentIdDebit: 0,
            DocumentIdCredit: 0,
            FunctionalaId: 0,
            EconomicaId: 0,
            Suma: 0,
            SumaValuta: 0,
            Explicatii: "",
            TipOpExecutieId: 0,
            ProgramBugetarId: 0,
            ProiectBaseId: 0,
            ContractBaseId: 0,
            IsActive: true
        };

        return CustomCopyToAsModified(model, tranzactii);
    }

    const onResetGrid = function () {
        var grid = $(gridId).dxDataGrid("instance");

        grid.state({});
    }

    const onResetTranzactGrid = function () {
        var grid = $(gridTranzactId).dxDataGrid("instance");

        grid.state({});
    }

    const onCancel = function () {
        HidePopup(popupId);
    }

    const onCancelTranzactGrid = function () {
        HidePopup(popupTranzactId);
    }

    const onHidingPopup = function () {
        global.onHidingUpsertViewPopup(popupId, apiRoot, onClearInfo);
    }

    const onHidingTranzactPopup = function () {
        onClearInfoTranzactGrid();
        $(popupTranzactId).dxPopup("dispose");
        $(popupTranzactId).load(`${apiRoot}/GetPopupViewTranzactGrid`);
    }

    const onEditingStart = function (e) {
        e.cancel = true;
    }

    const onSave = function (item) {
        ShowLoading();

        var frmInstance = $(formId).dxForm("instance");

        if (!frmInstance.validate().isValid) {
            HideLoading();
            ToastShowError("Date Invalide!");
            return;
        }

        var cursValutar = 0;
        var numberBoxCursValutarInstance = $("#CursValutar").dxNumberBox("instance");

        if (numberBoxCursValutarInstance) 
            cursValutar = numberBoxCursValutarInstance.option("value");
        

        var monedaIdValuta = 0;
        var dropDownBoxMonedaIdValutaInstance = $("#MonedaIdValuta").dxDropDownBox("instance");

        if (dropDownBoxMonedaIdValutaInstance)
            monedaIdValuta = dropDownBoxMonedaIdValutaInstance.option("value");

        if (monedaIdValuta !== 0 && monedaIdValuta !== 33) {
            //validare curs valutar
            if (cursValutar === 0) {
                HideLoading();
                ToastShowError("Cursul valutar nu poate fi 0!");
                return;
            }
        }

        var tranzactii = collectBatchGridData();
        if (bAdaugare && tranzactii.length == 0) {
            HideLoading();
            ToastShowError("Nu ati adaugat nicio tranzactie!");
            return;
        }
        else if (!bAdaugare && tranzactii.length == 0) {
            tranzactii = collectAllGridDataAsModified();
        }

        const notaContabilaData = frmInstance.option("formData");
        
        const postData = {
            Id: notaContabilaId,
            UnitatiId: notaContabilaData.UnitatiId,
            NumarDocument: notaContabilaData.NumarDocument,
            DataDocument: moment(notaContabilaData.DataDocument).format("YYYY-MM-DD"),
            TipDocumentId: notaContabilaData.TipDocumentId,
            DataInregistrare: moment(notaContabilaData.DataInregistrare).format("YYYY-MM-DD"),
            MonedaIdValuta: notaContabilaData.MonedaIdValuta,
            CursValutar: notaContabilaData.CursValutar,
            CotaTvaid: notaContabilaData.CotaTvaid,
            NrNotaContabila: notaContabilaData.NrNotaContabila,
            CodCpvid: notaContabilaData.CodCpvid,
            IsStorno: notaContabilaData.IsStorno,
            TranzactLines: tranzactii,
        };

        console.log(postData);

        ajaxHelper.post(`${apiRoot}/Upsert`,
            postData,
            function (response) {

                console.log(response);

                HideLoading();

                if (!response || !response.Success) {
                    ToastShowError(response.Message);
                    return;
                }

                HidePopup(popupId);
                ReloadDataGrid(gridId);
            },
            function (err) {
                ToastShowError(err.Message);
                HideLoading();
            });

        HideLoading();
    }

    const onSaveTranzactGrid = function (item) {
        var frmTranzactGridInstance = $(formTranzactId).dxForm("instance");

        if (!frmTranzactGridInstance.validate().isValid) {
            ToastShowError("Date Invalide!")
            return;
        }

        var numberBoxSumaInstance = $("#Suma").dxNumberBox("instance");
        if (numberBoxSumaInstance) {
            if (numberBoxSumaInstance.option("value") === 0) {
                HideLoading();
                ToastShowError("Suma nu poate fi 0!");
                return;
            }
        }

        let dataGrid = $(gridTranzactId).dxDataGrid("instance");
        let formData = frmTranzactGridInstance.option("formData");
        if (editRowIndex >= 0) {
            dataGrid.cellValue(editRowIndex, "NrCrt", formData.NrCrt);
            dataGrid.cellValue(editRowIndex, "PlanContIdDebit", formData.PlanContIdDebit);
            dataGrid.cellValue(editRowIndex, "PlanContIdCredit", formData.PlanContIdCredit);
            dataGrid.cellValue(editRowIndex, "PartenerIdDebit", formData.PartenerIdDebit);
            dataGrid.cellValue(editRowIndex, "PartenerIdCredit", formData.PartenerIdCredit);
            dataGrid.cellValue(editRowIndex, "DocumentIdPrimar", formData.DocumentIdPrimar);
            dataGrid.cellValue(editRowIndex, "DocumentIdDebit", formData.DocumentIdDebit);
            dataGrid.cellValue(editRowIndex, "DocumentIdCredit", formData.DocumentIdCredit);
            dataGrid.cellValue(editRowIndex, "FunctionalaId", formData.FunctionalaId);
            dataGrid.cellValue(editRowIndex, "EconomicaId", formData.EconomicaId);
            dataGrid.cellValue(editRowIndex, "Suma", formData.Suma);
            dataGrid.cellValue(editRowIndex, "SumaValuta", formData.SumaValuta);
            dataGrid.cellValue(editRowIndex, "Explicatii", formData.Explicatii);
            dataGrid.cellValue(editRowIndex, "TipOpExecutieId", formData.TipOpExecutieId);
            dataGrid.cellValue(editRowIndex, "ProgramBugetarId", formData.ProgramBugetarId);
            dataGrid.cellValue(editRowIndex, "ProiectBaseId", formData.ProiectBaseId);
            dataGrid.cellValue(editRowIndex, "ContractBaseId", formData.ContractBaseId);
            dataGrid.cellValue(editRowIndex, "IsActive", formData.IsActive);
        } else {
            dataGrid.on("initNewRow", function (e) {
                e.data["NrCrt"] = formData.NrCrt;
                e.data["PlanContIdDebit"] = formData.PlanContIdDebit;
                e.data["PlanContIdCredit"] = formData.PlanContIdCredit;
                e.data["PartenerIdDebit"] = formData.PartenerIdDebit;
                e.data["PartenerIdCredit"] = formData.PartenerIdCredit;
                e.data["DocumentIdPrimar"] = formData.DocumentIdPrimar;
                e.data["DocumentIdDebit"] = formData.DocumentIdDebit;
                e.data["DocumentIdCredit"] = formData.DocumentIdCredit;
                e.data["FunctionalaId"] = formData.FunctionalaId;
                e.data["EconomicaId"] = formData.EconomicaId;
                e.data["Suma"] = formData.Suma;
                e.data["SumaValuta"] = formData.SumaValuta??0;
                e.data["Explicatii"] = formData.Explicatii;
                e.data["TipOpExecutieId"] = formData.TipOpExecutieId;
                e.data["ProgramBugetarId"] = formData.ProgramBugetarId;
                e.data["ProiectBaseId"] = formData.ProiectBaseId;
                e.data["ContractBaseId"] = formData.ContractBaseId;
                e.data["IsActive"] = formData.IsActive;
            });

            dataGrid.beginUpdate();
            dataGrid.addRow();
            dataGrid.endUpdate();
            dataGrid.endCustomLoading();
            dataGrid.off("initNewRow");
        }

        HidePopup(popupTranzactId);
    }

    const onSumaValueChanged = function (e) {
        var cursValutar = 0;
        var numberBoxCursValutarInstance = $("#CursValutar").dxNumberBox("instance");

        if (numberBoxCursValutarInstance) {
            cursValutar = numberBoxCursValutarInstance.option("value");

            var sumaValuta = (e.value && e.value !== 0 && cursValutar && cursValutar !== 0) ? e.value / cursValutar : 0;
            var numberBoxSumaValutaInstance = $("#SumaValuta").dxNumberBox("instance");
            if (numberBoxSumaValutaInstance) {
                numberBoxSumaValutaInstance.option("value", sumaValuta);
            }
            else {
                console.error("NumberBox instance SumaValuta not found at the time of execution.");
            }
            
        }
        else {
            console.error("NumberBox instance CursValutar not found at the time of execution.");
        }
    }

    const onEdit = function (item) {
        var popup = $(popupId).dxPopup("instance");
        if (popup != undefined) {
            popup.option("title", "Actualizare");
        }
        ShowLoading();
        onClearInfo();
        notaContabilaId = item.data.Id;
        documentId = item.data.DocumentIdPrimar;
        getData(item.data.Id);
        item.cancel = true;
    }

    const onEditTranzactGrid = function (item) {
        var popup = $(popupTranzactId).dxPopup("instance");
        if (popup != undefined) {
            popup.option("title", "Actualizare tranzactie");
        }

        tranzactId = item.row?.data.Id;

        editRowIndex = item.row?.rowIndex;
        var clonedData = Object.assign({}, item.row?.data);
        item.event.preventDefault();

        ShowPopup(popupTranzactId);
        var frmTranzactGridInstance = $(formTranzactId).dxForm("instance");
        frmTranzactGridInstance.option("formData", clonedData);
    }

    const getData = function (id) {

        if (!id || id < 1) {
            ToastShowError("Id invalid!")
            return;
        }

        ajaxHelper.get(`${apiRoot}/GetNotaContabila?notaContabilaId=${id}`, null,
            function (response) {

                HideLoading();

                console.log(response);

                if (!response || !response.Success) {
                    ToastShowError(response.Message);
                    return;
                }

                ShowPopup(popupId);
                var frmInstance = $(formId).dxForm("instance");
                if (frmInstance != undefined) {
                    notaContabilaModelData = response.Data;
                    frmInstance.option("formData", notaContabilaModelData);
                }
            },
            function (err) {
                ToastShowError("Au aparut erori la citirea datelor!");
                HideLoading();
            });
    }

    const onClearInfo = function () {
        bAdaugare = false;
        notaContabilaId = 0;
        documentId = 0;
        unitateId = '00000000-0000-0000-0000-000000000000';
        notaContabilaModelData = null;
    }

    const onClearInfoTranzactGrid = function () {
        tranzactId = 0;
        notaContabilaModelData = null;
        editRowIndex = -1;
    }

    const onRowClick = function (item) {
        notaContabilaId = item.data.Id;
        documentId = item.data.DocumentIdPrimar;
    }

    const onRowClickTranzactGrid = function (item) {
        tranzactId = item.data.Id;
    }

    const onSetDocumentId = function (operation, ajaxSettings) {
        ajaxSettings.data.documentId = documentId;
    }

    const getUnitatiId = function () {
        return unitateId !== '00000000-0000-0000-0000-000000000000' ? unitateId : selectedUnitate;
    }

    const getUnitateSelectat = function () {
        selectedUnitate = $("#sbUnitate").dxSelectBox('instance').option('value');
    }

    const getAnulSelectat = function() {
         selectedAn = $("#sbAn").dxSelectBox('instance').option('value');
    }

    const getLunaSelectat = function() {
         selectedLuna = $("#sbLuna").dxSelectBox('instance').option('value');
    }

    const refreshGrid = function () {
        ReloadDataGrid(gridId);
    }

    const checkIfIsReadOnly = function () {
        return isReadOnly;
    }

    const onUnitatiChanged = function (args) {
        if (args.component.clickedRowData !== null && args.component.clickedRowData !== undefined) {
            unitateId = args.component.clickedRowData.Id;
        } else if (args.value !== 0) {
            unitateId = args.value;
        }

        var topFacturiDropdown = $("#TopFacturiId").dxDropDownBox("instance");
        if (topFacturiDropdown) {
            topFacturiDropdown.option("value", null);
            topFacturiDropdown.getDataSource().reload();
        }

        var contractDropdown = $("#ContractBaseId").dxDropDownBox("instance");
        if (contractDropdown) {
            contractDropdown.option("value", null);
            contractDropdown.getDataSource().reload();
        }

    }

    const onMonedaChanged = function (args) {
        if (args.component.clickedRowData !== null && args.component.clickedRowData !== undefined) {
            monedaId = args.component.clickedRowData.Id;
            var codMoneda = args.component.clickedRowData.Simbol;

            if (codMoneda === 'RON' || args.value === null) {
                var numberBoxCursValutarInstance = $("#CursValutar").dxNumberBox("instance");
                if (numberBoxCursValutarInstance) {
                    numberBoxCursValutarInstance.option("value", 0);
                    numberBoxCursValutarInstance.option("disabled", true);
                }
            }
            else {
                var dataBoxDataDocumentInstance = $("#DataDocument").dxDateBox("instance");
                var dataDocument = dataBoxDataDocumentInstance.option("value");
                if (dataDocument) {
                    dataDocument = moment(dataDocument).format("YYYY-MM-DD");
                }
                else {
                    console.error("DateBox instance DataDocument not found at the time of execution.");
                }

                ajaxHelper.get(`${apiRootCursValutar}/GetCursValutar?monedaId=${monedaId}&dataCurs=${dataDocument}`, null,
                    function (response) {
                        console.log(response);

                        if (!response || response === 0) {
                            console.log(`Cursul valutar intors pentru moneda selectata ${monedaId} la data =${dataDocument} este 0!`);
                        }

                        var frmInstance = $(formId).dxForm("instance");
                        if (frmInstance != undefined) {

                            var numberBoxCursValutarInstance = $("#CursValutar").dxNumberBox("instance");
                            if (numberBoxCursValutarInstance) {
                                numberBoxCursValutarInstance.option("value", response);
                            }
                            else {
                                console.error("NumberBox instance CursValutar not found at the time of execution.");
                            }
                        }
                    },
                    function (err) {
                        ToastShowError("Au aparut erori la citirea cursului valutar pentru moneda selectata!");
                    });
            }

        } else if (args.value !== 0) {
            monedaId = args.value;
        }
    }

    const onDataDocumentChanged = function (args) {
        var dataDocument = args.value;
        if (dataDocument) {
            dataDocument = moment(dataDocument).format("YYYY-MM-DD");
        }
        else {
            console.error("DataDocument este null");
        }
        var monedaIdValuta = 0;
        var dropDownBoxMonedaIdValutaInstance = $("#MonedaIdValuta").dxDropDownBox("instance");
        if (dropDownBoxMonedaIdValutaInstance) {
            monedaIdValuta = dropDownBoxMonedaIdValutaInstance.option("value");
        }
        else {
            console.error("DropDownBox instance MonedaIdValuta not found at the time of execution.");
        }
        if (monedaIdValuta !== 0 && monedaIdValuta !== 33) {
            ajaxHelper.get(`${apiRootCursValutar}/GetCursValutar?monedaId=${monedaIdValuta}&dataCurs=${dataDocument}`, null,
                function (response) {
                    console.log(response);
                    if (!response || response === 0) {
                        console.log(`Cursul valutar intors pentru moneda selectata ${monedaId} la data =${dataDocument} este 0!`);
                    }
                    var frmInstance = $(formId).dxForm("instance");
                    if (frmInstance != undefined) {
                        var numberBoxCursValutarInstance = $("#CursValutar").dxNumberBox("instance");
                        if (numberBoxCursValutarInstance) {
                            numberBoxCursValutarInstance.option("value", response);
                        }
                        else {
                            console.error("NumberBox instance CursValutar not found at the time of execution.");
                        }
                    }
                },
                function (err) {
                    ToastShowError("Au aparut erori la citirea cursului valutar pentru moneda selectata!");
                });
        }
    }

    const onBeforeSend = function (operation, ajaxSettings) {
        ajaxSettings.data.selectedUnitate = selectedUnitate;
        ajaxSettings.data.selectedLuna = selectedLuna;
        ajaxSettings.data.selectedAn = selectedAn;
    }

    return {
        onAddAction: onAddAction,
        onAddActionTranzactGrid: onAddActionTranzactGrid,
        onRowClickTranzactGrid: onRowClickTranzactGrid,
        onClearInfo: onClearInfo,
        onClearInfoTranzactGrid: onClearInfoTranzactGrid,
        onEditingStart: onEditingStart,
        onResetGrid: onResetGrid,
        onResetTranzactGrid: onResetTranzactGrid,
        onDelete: onDelete,
        onDeleteTranzactGrid: onDeleteTranzactGrid,
        onCancel: onCancel,
        onCancelTranzactGrid: onCancelTranzactGrid,
        onSave: onSave,
        onSaveTranzactGrid: onSaveTranzactGrid,
        onEdit: onEdit,
        onEditTranzactGrid: onEditTranzactGrid,
        onRowClick: onRowClick,
        onRowClickTranzactGrid: onRowClickTranzactGrid,
        onHidingPopup: onHidingPopup,
        onHidingTranzactPopup: onHidingTranzactPopup,
        onSetDocumentId: onSetDocumentId,
        getAnulSelectat: getAnulSelectat,
        getLunaSelectat: getLunaSelectat,
        getUnitateSelectat: getUnitateSelectat,
        getUnitatiId: getUnitatiId,
        refreshGrid: refreshGrid,
        checkIfIsReadOnly: checkIfIsReadOnly,
        onUnitatiChanged: onUnitatiChanged,
        onMonedaChanged: onMonedaChanged,
        onDataDocumentChanged: onDataDocumentChanged,
        onSumaValueChanged: onSumaValueChanged,
        onBeforeSend: onBeforeSend
    }
})();