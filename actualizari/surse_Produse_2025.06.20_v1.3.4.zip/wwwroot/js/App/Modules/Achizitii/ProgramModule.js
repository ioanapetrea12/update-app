﻿var programModule = (function () {
    var programId = 0;
    var produsBazaId = 0;
    var programDetId = 0;
    var programIdDetalii = 0;
    var genereazaProgram = false;
    var editRowIndex = -1;
    var isReadOnly = false;

    const apiRoot = "/Achizitii/Program";
    const gridId = "#gridProgram";
    const gridDetaliiId = "#gridDetaliiProgram";
    const gridCentralizatorId = "#gridCentralizatorProgram";
    const popupId = "#upsert-program-popup";
    const popupDetaliiId = "#upsert-detaliiprogram-popup";
    const popupDetaliiGridId = "#upsert-detaliigridprogram-popup";
    const popupAprobareId = "#aprobare-program-popup";
    const formId = "#upsert-program-form";
    const formDetaliiId = "#upsert-detaliiprogram-form";
    const formDetaliiGridId = "#upsert-detaliigridprogram-form";

    const onAddAction = function (args) {
        var popup = $(popupId).dxPopup("instance");
        if (popup != undefined) {
            popup.option("title", "Adaugare");
        }
        isReadOnly = false;

        ShowPopup(popupId);
        onClearInfo();

        var frmInstance = $(formId).dxForm("instance");
        frmInstance.option("formData", { Stare: 1 });
    }

    const onAddActionDetaliiGrid = function (args) {
        editRowIndex = -1;
        var popup = $(popupDetaliiGridId).dxPopup("instance");
        if (popup != undefined) {
            popup.option("title", "Adaugare detaliu program");
        }
        ShowPopup(popupDetaliiGridId);
        onClearInfoDetaliiGrid();
    }

    const onEditingStart = function (e) {
        e.cancel = true;
    }

    const onDelete = function (item) {
        var result = DevExpress.ui.dialog.confirm("<p>Sunteti sigur/a ca doriti stergerea elementului selectat?</p>", "Stergere");
        result.done(function (dialogResult) {
            if (dialogResult) {
                var postData = {
                    Key: item.row.key
                };
                ajaxHelper.post(`${apiRoot}/Delete`, postData,
                    function (response) {
                        HideLoading();
                        if (response) {
                            if (response.Success == false) {
                                ToastShowError(response.Message);
                                return;
                            }
                            ReloadDataGrid(gridId);
                        } else {
                            ToastShowError("A aparut o eroare la stergerea intrarilor");
                        }
                    },
                    function (err) {
                        ToastShowError("An error occured");
                        HideLoading();
                    });
            }
        })
    }

    const onDeleteDetaliiGrid = function (item) {
        var gridDetaliiInstance = $(gridDetaliiId).dxDataGrid("instance");
        var result = DevExpress.ui.dialog.confirm("<p>Sunteti sigur ca doriti stergerea elementului selectat?</p>", "Stergere");
        result.done(function (dialogResult) {
            deletedRowIndex = item.row.rowIndex;

            if (dialogResult) {
                gridDetaliiInstance.deleteRow(deletedRowIndex);
                gridDetaliiInstance.element().find(".dx-row-removed").hide();
            }
        });
    }

    const collectBatchGridData = function (bReturnAllDataAsNewLines = false) {
        if (!IsDataGridInstance(gridDetaliiId)) {
            return;
        }

        var detaliiProgram = GetModifiedDataFromGrid(gridDetaliiId);
        var model = {
            Id: 0,
            UnitatiId: null,
            ProdusId: null,
            Umid: 0,
            T1in: 0,
            T2in: 0,
            T3in: 0,
            T4in: 0,
            T1out: 0,
            T2out: 0,
            T3out: 0,
            T4out: 0,
            PlanAchizitieBaseId: programIdDetalii,
            IsActive: true
        };

        return CustomCopyTo(model, detaliiProgram, bReturnAllDataAsNewLines);
    }

    const onResetGrid = function () {
        var grid = $(gridId).dxDataGrid("instance");

        grid.state({});
    }

    const onResetDetaliiGrid = function () {
        var grid = $(gridDetaliiId).dxDataGrid("instance");

        grid.state({});
    }

    const onResetCentralizatorGrid = function () {
        var grid = $(gridCentralizatorId).dxDataGrid("instance");

        grid.state({});
    }

    const onCancel = function () {
        HidePopup(popupId);
    }

    const onCancelDetalii = function () {
        HidePopup(popupDetaliiId);
    }

    const onCancelDetaliiGrid = function () {
        HidePopup(popupDetaliiGridId);
    }

    const onCancelAprobare = function () {
        HidePopup(popupAprobareId);
    }

    const onHidingPopup = function () {
        global.onHidingUpsertViewPopup(popupId, apiRoot, onClearInfo);
    }

    const onHidingDetaliiPopup = function () {
        onClearInfoDetalii();
        $(popupDetaliiId).dxPopup("dispose");
        $(popupDetaliiId).load(`${apiRoot}/GetPopupViewDetalii`);
    }

    var onHidingDetaliiGridPopup = function () {
        onClearInfoDetaliiGrid();
        $(popupDetaliiGridId).dxPopup("dispose");
        $(popupDetaliiGridId).load(`${apiRoot}/GetPopupViewDetaliiGrid`);
    }

    const onHidingAprobarePopup = function () {
        $(popupAprobareId).dxPopup("dispose");
        $(popupAprobareId).load(`${apiRoot}/GetPopupViewAprobare`);
    }

    const onSave = function (item) {
        ShowLoading();

        var frmInstance = $(formId).dxForm("instance");

        if (!frmInstance.validate().isValid) {
            HideLoading();
            ToastShowError("Date Invalide!");
            return;
        }

        var programData = frmInstance.option("formData");

        var postData = {
            Id: programId,
            Cod: programData.Cod,
            Denumire: programData.Denumire,
            TipPlanId: programData.TipPlanId,
            ProdusIdBaza: programData.ProdusIdBaza,
            Stare: programData.Stare,
            DataPlan: moment(programData.DataPlan).format("YYYY-MM-DD"),
            GenereazaProgram: genereazaProgram
        };

        postData.DataAprobarePlan = programData.DataAprobarePlan !== undefined && programData.DataAprobarePlan !== null
            ? moment(programData.DataAprobarePlan).format("YYYY-MM-DD")
            : programData.DataAprobarePlan;

        console.log(postData);

        ajaxHelper.post(`${apiRoot}/Upsert`,
            postData,
            function (response) {
                HideLoading();

                if (!response || !response.Success) {
                    ToastShowError(response.Message);
                    return;
                }

                HidePopup(popupId);
                ReloadDataGrid(gridId);
            },
            function (err) {
                ToastShowError(err.Message);
                HideLoading();
            });

        HideLoading();
    }

    const onSaveDetalii = function (item) {
        ShowLoading();

        var frmInstance = $(formDetaliiId).dxForm("instance");

        if (!frmInstance.validate().isValid) {
            HideLoading();
            ToastShowError("Date Invalide!");
            return;
        }

        var programData = frmInstance.option("formData");
        var detaliiProgram = collectBatchGridData(genereazaProgram);

        var postData = {
            Id: programData.Id, //programIdDetalii
            Cod: programData.Cod,
            Denumire: programData.Denumire,
            TipPlanId: programData.TipPlanId,
            ProdusIdBaza: programData.ProdusIdBaza,
            Stare: programData.Stare,
            DataPlan: moment(programData.DataPlan).format("YYYY-MM-DD"),
            GenereazaProgram: genereazaProgram,
            DetaliiProgram: detaliiProgram
        };

        postData.DataAprobarePlan = programData.DataAprobarePlan !== undefined && programData.DataAprobarePlan !== null
            ? moment(programData.DataAprobarePlan).format("YYYY-MM-DD")
            : programData.DataAprobarePlan;

        console.log(postData);

        ajaxHelper.post(`${apiRoot}/Upsert`,
            postData,
            function (response) {
                HideLoading();

                if (!response || !response.Success) {
                    ToastShowError(response.Message);
                    return;
                }

                HidePopup(popupDetaliiId);
                ReloadDataGrid(gridId);
            },
            function (err) {
                ToastShowError(err.Message);
                HideLoading();
            });

        HideLoading();
    }

    const onSaveDetaliiGrid = function (item) {
        var frmDetaliiGridInstance = $(formDetaliiGridId).dxForm("instance");

        if (!frmDetaliiGridInstance.validate().isValid) {
            ToastShowError("Date Invalide!")
            return;
        }

        let dataGrid = $(gridDetaliiId).dxDataGrid("instance");
        let formData = frmDetaliiGridInstance.option("formData");
        if (editRowIndex >= 0) {
            dataGrid.cellValue(editRowIndex, "UnitatiId", formData.UnitatiId);
            dataGrid.cellValue(editRowIndex, "ProdusId", formData.ProdusId);
            dataGrid.cellValue(editRowIndex, "Umid", formData.Umid);
            dataGrid.cellValue(editRowIndex, "T1in", formData.T1in);
            dataGrid.cellValue(editRowIndex, "T2in", formData.T2in);
            dataGrid.cellValue(editRowIndex, "T3in", formData.T3in);
            dataGrid.cellValue(editRowIndex, "T4in", formData.T4in);
            dataGrid.cellValue(editRowIndex, "T1out", formData.T1out);
            dataGrid.cellValue(editRowIndex, "T2out", formData.T2out);
            dataGrid.cellValue(editRowIndex, "T3out", formData.T3out);
            dataGrid.cellValue(editRowIndex, "T4out", formData.T4out);
            dataGrid.cellValue(editRowIndex, "PlanAchizitieBaseId", programIdDetalii);
            dataGrid.cellValue(editRowIndex, "IsActive", formData.IsActive);
        } else {
            dataGrid.on("initNewRow", function (e) {
                e.data["UnitatiId"] = formData.UnitatiId;
                e.data["ProdusId"] = formData.ProdusId;
                e.data["Umid"] = formData.Umid;
                e.data["T1in"] = formData.T1in;
                e.data["T2in"] = formData.T2in;
                e.data["T3in"] = formData.T3in;
                e.data["T4in"] = formData.T4in;
                e.data["T1out"] = formData.T1out;
                e.data["T2out"] = formData.T2out;
                e.data["T3out"] = formData.T3out;
                e.data["T4out"] = formData.T4out;
                e.data["PlanAchizitieBaseId"] = programIdDetalii;
                e.data["IsActive"] = formData.IsActive;
            });

            dataGrid.beginUpdate();
            dataGrid.addRow();
            dataGrid.endUpdate();
            dataGrid.endCustomLoading();
            dataGrid.off("initNewRow");
        }

        HidePopup(popupDetaliiGridId);
    }

    const onEdit = function (item) {
        var popup = $(popupId).dxPopup("instance");
        if (popup != undefined) {
            popup.option("title", "Actualizare");
        }
        ShowLoading();
        onClearInfo();
        programId = item.data.Id;
        isReadOnly = !!(item.data.Stare == 2);
        getData(programId, popupId, formId);
        item.cancel = true;
    }

    const onEditDetalii = function (item) {
        var popup = $(popupDetaliiId).dxPopup("instance");
        if (popup != undefined) {
            popup.option("title", "Actualizare detalii");
        }
        ShowLoading();
        onClearInfo();
        isReadOnly = !!(item.row.data.Stare == 2);
        programIdDetalii = item.row?.data.Id;
        getData(programIdDetalii, popupDetaliiId, formDetaliiId);
        item.cancel = true;
    }

    const onEditDetaliiGrid = function (item) {
        var popup = $(popupDetaliiGridId).dxPopup("instance");
        if (popup != undefined) {
            popup.option("title", "Actualizare detalii");
        }

        programDetId = item.row?.data.Id;

        editRowIndex = item.row?.rowIndex;
        var clonedData = Object.assign({}, item.row?.data);
        item.event.preventDefault();

        ShowPopup(popupDetaliiGridId);
        var frmDetaliiGridInstance = $(formDetaliiGridId).dxForm("instance");
        frmDetaliiGridInstance.option("formData", clonedData);
    }

    const getData = function (id, popupId, formId) {

        if (!id || id < 1) {
            ToastShowError("Id invalid!")
            return;
        }

        ajaxHelper.get(`${apiRoot}/GetProgramDetails?programId=${id}`, null,
            function (response) {

                HideLoading();

                if (!response || !response.Success) {
                    ToastShowError(response.Message);
                    return;
                }

                ShowPopup(popupId);
                var frmInstance = $(formId).dxForm("instance");
                if (frmInstance != undefined) {
                    let programModelData = response.Data;
                    frmInstance.option("formData", programModelData);
                }
            },
            function (err) {
                ToastShowError("Au aparut erori la citirea datelor!");
                HideLoading();
            });
    }

    const onClearInfo = function () {
        programId = 0;
        isReadOnly = false;

        var now = new Date();
        global.setDateRangeValues('#dateRangeBox', new Date(now.getFullYear(), 0, 1), new Date(2099, 11, 31),);
    }

    const onClearInfoDetalii = function () {
        programIdDetalii = 0;
        genereazaProgram = false;
    }

    const onClearInfoDetaliiGrid = function () {
        programDetId = 0;
    }

    const onRowClick = function (item) {
        programId = item.data.Id;
    }

    const onRowClickDetaliiGrid = function (item) {
        programDetId = item.data.Id;
    }

    const onProdusBazaValueChanged = function (args) {
        if (args.component.clickedRowData !== null && args.component.clickedRowData !== undefined) {
            produsBazaId = args.component.clickedRowData.Id;
        }
        else {
            produsBazaId = args.value;
        }

        ReloadDataGrid(gridDetaliiId);
    }

    const onGenereazaProgramClick = function () {
        var result = DevExpress.ui.dialog.confirm("<p>Sunteti sigur/a ca doriti generarea programului selectat? Accesati butonul <b>DA</b> daca doriti sa continuati acest proces sau <b>NU</b> in cazul in care nu doriti generarea programului</p>", "Generare");
        result.done(function (dialogResult) {
            if (dialogResult) {
                genereazaProgram = true;

                //reload the details grid to get the new data (using the genereazaProgram parameter)
                ReloadDataGrid(gridDetaliiId);
            }
        })
    }

    const onVizualizeazaProgramClick = function () {
        var codRaport = -12;

        ShowLoading();
        ajaxHelper.get(`${apiRoot}/VizualizareProgram?programId=${programIdDetalii}&codInternRaport=${codRaport}`, null,
            function (response) {
                if (!response || !response.Success) {
                    ToastShowError(response.Message);
                    return;
                }

                window.open(response.Data, '_blank');
                HideLoading();
            },
            function (error) {

            });
        HideLoading();
    }

    const onAprobaProgramClick = function (item) {
        //open popup aprobare
        var popup = $(popupAprobareId).dxPopup("instance");
        if (popup != undefined) {
            popup.option("title", "Aprobare");
        }

        var clonedData = Object.assign({}, item.row?.data);
        item.event.preventDefault();
        if (clonedData.DataAprobarePlan === null)
            clonedData.DataAprobarePlan = clonedData.DataLucru;
        ShowPopup(popupAprobareId);
        var aprobareGridInstance = $("#aprobare-program-form").dxForm("instance");
        aprobareGridInstance.option("formData", clonedData);
        var denumire = clonedData.Denumire;
        if (denumire) {
            document.getElementById("aprobareText").innerHTML =
                `<p>Sunteti sigur/a ca doriti aprobarea programului selectat 
                <b>'${denumire}'</b>? Accesati butonul <b>DA</b> daca doriti sa continuati acest proces sau <b>NU</b> in cazul in care nu doriti.</p>
        <p>Asigurati-va ca data de aprobare este completata corect.</p>`;
        }
    }

    const onPrintRaport = function (e) {
        var codRaport = -10;
        var programId = e.row.data.Id;
        ShowLoading();
        ajaxHelper.get(`${apiRoot}/GetProgramLinkRaport?programId=${programId}&codInternRaport=${codRaport}`, null,
            function (response) {
                if (!response || !response.Success) {
                    ToastShowError(response.Message);
                    return;
                }

                window.open(response.Data, '_blank');
                HideLoading();
            },
            function (error) {

            });
        HideLoading();
    }

    const getDetaliiGridParam = function (operation, ajaxSettings) {
        if (operation === "load") {
            ajaxSettings.data.programId = programIdDetalii;
            ajaxSettings.data.genereazaProgram = genereazaProgram;
        }
    }

    const getCentralizatorGridParam = function (operation, ajaxSettings) {
        if (operation === "load") {
            ajaxSettings.data.programId = programIdDetalii;
        }
    }

    const checkIfIsReadOnly = function () {
        return !!isReadOnly;
    }

    const showAprobare = function (e) {
        if (e.row.data.Stare === 2)
            return false;
        return true;
    }

    const getProdusBazaId = function () {
        let formInstance = $(formDetaliiId).dxForm("instance");
        let formData = formInstance.option("formData");
        if (formData.ProdusIdBaza !== undefined && formData.ProdusIdBaza !== null) {
            return formData.ProdusIdBaza;
        }
        return 0;
    }

    const onAprobare = function () {
        let dataGrid = $("#aprobare-program-form").dxForm("instance");
        if (!dataGrid.validate().isValid) {
            HideLoading();
            ToastShowError("Date Invalide!");
            return;
        }
        let formData = dataGrid.option("formData");
        var postData = {
            Id: formData.Id,
            DataAprobarePlan: moment(formData.DataAprobarePlan).format("YYYY-MM-DD")
        };
        ajaxHelper.post(`${apiRoot}/AprobareProgram`, postData,
            function (response) {
                HideLoading();
                if (response) {
                    HidePopup(popupAprobareId);
                    ReloadDataGrid(gridId);
                } else {
                    ToastShowError("A aparut o eroare la aprobarea programului");
                }
            },
            function (err) {
                ToastShowError("An error occured");
                HideLoading();
            });
    }

    return {
        onAddAction: onAddAction,
        onAddActionDetaliiGrid: onAddActionDetaliiGrid,
        onResetGrid: onResetGrid,
        onResetDetaliiGrid: onResetDetaliiGrid,
        onResetCentralizatorGrid: onResetCentralizatorGrid,
        onDelete: onDelete,
        onDeleteDetaliiGrid: onDeleteDetaliiGrid,
        onCancel: onCancel,
        onCancelDetalii: onCancelDetalii,
        onCancelDetaliiGrid: onCancelDetaliiGrid,
        onSave: onSave,
        onSaveDetalii: onSaveDetalii,
        onSaveDetaliiGrid: onSaveDetaliiGrid,
        onEdit: onEdit,
        onEditingStart: onEditingStart,
        onEditDetaliiGrid: onEditDetaliiGrid,
        onRowClick: onRowClick,
        onRowClickDetaliiGrid: onRowClickDetaliiGrid,
        onProdusBazaValueChanged: onProdusBazaValueChanged,
        getProdusBazaId: getProdusBazaId,
        onGenereazaProgramClick: onGenereazaProgramClick,
        onVizualizeazaProgramClick: onVizualizeazaProgramClick,
        onAprobaProgramClick: onAprobaProgramClick,
        onPrintRaport: onPrintRaport,
        onEditDetalii: onEditDetalii,
        onHidingPopup: onHidingPopup,
        onHidingDetaliiPopup: onHidingDetaliiPopup,
        onHidingDetaliiGridPopup: onHidingDetaliiGridPopup,
        getDetaliiGridParam: getDetaliiGridParam,
        getCentralizatorGridParam: getCentralizatorGridParam,
        checkIfIsReadOnly: checkIfIsReadOnly,
        onAprobare: onAprobare,
        onHidingAprobarePopup: onHidingAprobarePopup,
        onCancelAprobare: onCancelAprobare,
        showAprobare: showAprobare
    }
})();