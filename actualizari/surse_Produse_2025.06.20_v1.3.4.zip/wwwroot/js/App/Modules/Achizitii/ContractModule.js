﻿const contracteModule = (function () {
    var dataDocument = new Date(window.AppConfig.dataLucru);
    var contractId = 0;
    var partenerId = 0;
    var scopAchizitieId = 0;
    var myIndex = 0;
    var docScanRowIndex = -1;
    var docScanRowIdentifier = '';
    var docScanIsNewRow = false;
    var newFiles = [];
    var contractModelData = {};
    var isCancelled = false;

    const apiRoot = "/Achizitii/Contract";
    const gridId = "#grid-contracte";
    const popupId = "#upsert-contract-popup";
    const formId = "#contractForm";
    const disponibilCpGridvId = "#DefalcareCodCPVGrid";
    const documenteGridId = "#ContractDocScanGrid";
    const apiRootCursValutar = "/Nomenclatoare/CursValutar";

    var unitateId = '00000000-0000-0000-0000-000000000000';
    var cursValutar = 0;
    var cotaTva = 0;
    var defaultMonedaId = 0;
    var monedaId = 0;

    var onAddAction = function (args) {
        var popup = $(popupId).dxPopup("instance");
        if (popup != undefined) {
            popup.option("title", "Adaugare");
        }
        ShowPopup(popupId);
        onClearInfo();

        setDefaultMoneda();
    }

    var onDelete = function (item) {
        var result = DevExpress.ui.dialog.confirm("<p>Sunteti sigur/a ca doriti stergerea elementului selectat?</p>", "Stergere");
        result.done(function (dialogResult) {
            if (dialogResult) {
                ajaxHelper.delete(`${apiRoot}/Delete/${item.row.key}`,
                    function (response) {
                        HideLoading();
                        if (response) {
                            if (response.Success == false) {
                                ToastShowError(response.Message);
                                return;
                            }
                            ReloadDataGrid(gridId);
                        } else {
                            ToastShowError("A aparut o eroare la stergerea contractului");
                        }
                    },
                    function (err) {
                        ToastShowError("An error occured");
                        HideLoading();
                    });
            }
        })
    }

    var onResetGrid = function () {
        var grid = $(gridId).dxDataGrid("instance");

        grid.state({});
    }
    var onCancel = function () {
        HidePopup(popupId);
    }

    var onHidingPopup = function () {
        global.onHidingUpsertViewPopup(popupId, apiRoot, onClearInfo);
    }

    var onSave = function (item) {
        ShowLoading();

        var frmInstance = $(formId).dxForm("instance");

        if (!frmInstance.validate().isValid) {
            HideLoading();
            ToastShowError("Date Invalide!");
            return;
        }

        const formData = frmInstance.option("formData");

        const postData = getSubmitPayload(formData);

        ajaxHelper.post(`${apiRoot}/Upsert`,
            postData,
            function (response) {
                HideLoading();

                if (!response || !response.Success) {
                    ToastShowError(response.Message);
                    if (response.Message === 'Nu exista curs valutar pentru moneda selectata la data contractului') {
                        var dbMoneda = $('#dbMoneda').dxDropDownBox('instance');
                        if (dbMoneda) {
                            dbMoneda.option('isValid', false);
                        }
                    }
                    return;
                }

                HidePopup(popupId);
                ReloadDataGrid(gridId);
            },
            function (err) {
                ToastShowError(err.Message);
                HideLoading();
            });
    }

    var getSubmitPayload = function (formData) {

        var payload = {
            Id: contractId,
            UnitatiId: formData.UnitatiId,
            Idparinte: formData.Idparinte,
            NrContract: formData.NrContract,
            DataContract: moment(formData.DataContract).format("YYYY-MM-DD"),
            DataStartContract: moment(formData.DataStartContract).format("YYYY-MM-DD"),
            DataStopContract: moment(formData.DataStopContract).format("YYYY-MM-DD"),
            DenumireContract: formData.DenumireContract,
            PartenerId: formData.PartenerId,
            TipContractId: formData.TipContractId,
            CotaTvaid: formData.CotaTvaid,
            ValoareContractfaraTva: formData.ValoareContractfaraTva,
            ValoareContract: formData.ValoareContract,
            MonedaIdvaluta: formData.MonedaIdvaluta,
            ValoareContractValuta: formData.ValoareContractValuta,
            CursValutar: formData.CursValutar,
            SoldContract: formData.SoldContract,
            StadiuContractId: formData.StadiuContractId,
            ProceduraAchizitieId: formData.ProceduraAchizitieId,
            NrAnunt: formData.NrAnunt,
            CompartimentId: formData.CompartimentId,
            PersonalIdresponsabil: formData.PersonalIdresponsabil,
            PrelungireContract: formData.PrelungireContract,
            ReprezentantClient: formData.ReprezentantClient,
            Amendamente: formData.Amendamente,
            Penalitati: formData.Penalitati,
            DataReziliere: moment(formData.DataReziliere).format("YYYY-MM-DD"),
            ModalitateReziliere: formData.ModalitateReziliere,
            PeriodicitateFacturaId: formData.PeriodicitateFacturaId,
            CuantumGbe: formData.CuantumGbe,
            ValoareSgb: formData.ValoareSgb,
            TermenConstituireGbe: formData.TermenConstituireGbe,
            TermenGbe: moment(formData.TermenGbe).format("YYYY-MM-DD"),
            EliberareGbe: moment(formData.EliberareGbe).format("YYYY-MM-DD"),
            TermenLivrare: moment(formData.TermenLivrare).format("YYYY-MM-DD"),
            MonedaIdgbe: formData.MonedaIdgbe,
            TipAchizitieId: formData.TipAchizitieId,
            CriteriuAtribuireId: formData.CriteriuAtribuireId,
            ValoareMinima: formData.ValoareMinima,
            CantitateMinima: formData.CantitateMinima,
            CantitateMaxima: formData.CantitateMaxima,
            TemaAchizitieId: formData.TemaAchizitieId,
            ObiectivInvestitieId: formData.ObiectivInvestitieId,
            CodAngajament: formData.CodAngajament,
            IndAngajament: formData.IndAngajament,
            Detalii: formData.Detalii
        };

        const gridtermeneInstance = $("#grid-termene").dxDataGrid('instance');
        if (gridtermeneInstance !== undefined) {
            const items = gridtermeneInstance.getVisibleRows().filter(x => !x.removed && x.data).map(x => x.data);

            const itemsToAdd = [];
            for (let i = 0; i < items.length; i++) {

                const itemRow = items[i];
                var currentId = getValue(itemRow, 'Id');
                if (currentId === null)
                    currentId = 0;
                const item = {
                    id: currentId,
                    termenLivrare: moment(itemRow.TermenLivrare).format("YYYY-MM-DD"),
                    detaliiTermenLivrare: itemRow.DetaliiTermenLivrare
                };
                itemsToAdd.push(item);
            }
            payload.ContractDets = itemsToAdd;
        }
        else {
            payload.ContractDets = null;
        }

        const gridDocumenteInstance = $("#grid-docs").dxDataGrid('instance');
        if (gridDocumenteInstance !== undefined) {
            const items = gridDocumenteInstance.getVisibleRows().filter(x => !x.removed && x.data).map(x => x.data);

            const itemsToAdd = [];
            for (let i = 0; i < items.length; i++) {

                const itemRow = items[i];
                var currentId = getValue(itemRow, 'Id');
                if (currentId === null)
                    currentId = 0;
                const item = {
                    id: 0,
                    dataDocument: moment(itemRow.DataDocument).format("YYYY-MM-DD"),
                    descriereDocument: itemRow.DescriereDocument,
                    nrDocument: itemRow.NrDocument,
                    identifier: itemRow.Identifier,
                };
                itemsToAdd.push(item);
            }
            payload.ContractBaseDocumenteScans = itemsToAdd;
        }
        else {
            payload.ContractBaseDocumenteScans = null;
        }

        const gridDerulareInstance = $("#grid-derulare").dxDataGrid('instance');
        if (gridDerulareInstance !== undefined) {
            const items = gridDerulareInstance.getVisibleRows().filter(x => !x.removed && x.data).map(x => x.data);

            const itemsToAdd = [];
            for (let i = 0; i < items.length; i++) {

                var itemRow = items[i];

                var currentId = getValue(itemRow, 'Id');
                if (currentId === null)
                    currentId = 0;
                const item = {
                    id: currentId,
                    denumirePartener: itemRow.DenumirePartener,
                    valoareOferta: itemRow.ValoareOferta,
                    punctaj: itemRow.Punctaj
                };
                itemsToAdd.push(item);
            }
            payload.DerulareAchizities = itemsToAdd;
        }
        else {
            payload.DerulareAchizities = null;
        }

        payload.DisponibilCpv = null;
        return payload;
    }

    var onEdit = function (item) {
        var popup = $(popupId).dxPopup("instance");
        if (popup != undefined) {
            popup.option("title", "Actualizare");
        }
        ShowLoading();
        onClearInfo();
        setDefaultMoneda();
        contractId = item.data.Id;
        isCancelled = item.data.Anulat;
        //console.log(isCancelled);
        getData(item.data.Id);
        item.cancel = true;
    }

    var getData = function (id) {

        if (!id || id < 1) {
            ToastShowError("Id invalid!")
            return;
        }

        ajaxHelper.get(`${apiRoot}/GetContractDetails?contractId=${id}`, null,
            function (response) {

                HideLoading();

                if (!response || !response.Success) {
                    ToastShowError(response.Message);
                    return;
                }

                ShowPopup(popupId);
                var frmInstance = $(formId).dxForm("instance");
                if (frmInstance != undefined) {
                    contractModelData = response.Data;
                    cursValutar = contractModelData.CursValutar;
                    cotaTva = contractModelData.CotaTvaValoare;
                    frmInstance.option("formData", contractModelData);
                }
            },
            function (err) {
                ToastShowError("Au aparut erori la citirea datelor!");
                HideLoading();
            });
    }

    const onClearInfo = function () {
        contractId = 0;
        contractModelData = null;
        isCancelled = false;
        monedaId = 0;
        cursValutar = 0;
        defaultMonedaId = 0;
        cotaTva = 0;
    }

    const onRowClick = function (item) {
        contractId = item.data.Id;
    }
    const getCurrentYear = function () {
        var currentYear = new Date().getFullYear();
        var nbSelYear = $('#nbSelYear').dxNumberBox('instance');
        selectedYear = currentYear;
        nbSelYear.option('value', currentYear);
    }
    const onNumberBoxValueChange = function (arg) {
        selectedYear = arg.value;
        onResetGrid();
    }

    const getSelectedYear = function () {
        return selectedYear;
    }

    const onUnitatiChanged = function (args) {
        if (args.component.clickedRowData !== null && args.component.clickedRowData !== undefined) {
            unitateId = args.component.clickedRowData.Id;
        } else if (args.value !== 0) {
            unitateId = args.value;
        }

        var subcontract = $("#ddlSubcontract").dxDropDownBox("instance");
        //resetam valoarea din comboPartenerDet pentru a se reface filtrarea
        subcontract.option('value', null);
    }

    const onPartnerChanged = function (args) {
        if (args.component.clickedRowData !== null && args.component.clickedRowData !== undefined) {
            partenerId = args.component.clickedRowData.Id;

        }
        //pentru situatia in care se schimba valoarea din cod si nu de catre utilizator
        else if (args.value !== 0) {
            partenerId = args.value;
        }

        var subcontract = $("#ddlSubcontract").dxDropDownBox("instance");
        //resetam valoarea din comboPartenerDet pentru a se reface filtrarea
        subcontract.option('value', null);
    }

    const onOpen = function (e) {
        e.component.getDataSource().load().then(function (data) {
            ReloadDataGrid("#ComboContracteGrid");
        })
    }
    const setSubContractsParams = function (operation, ajaxSettings) {
        if (operation === "load") {
            ajaxSettings.data.unitateId = unitateId;
            ajaxSettings.data.contractId = contractId;
            ajaxSettings.data.partenerId = partenerId;
        }
    }
    const formatNumberForROCulture = function (value) {
        if (value !== undefined)
            return new Intl.NumberFormat('ro-RO', {
                style: 'decimal',
                minimumFractionDigits: 2,
                maximumFractionDigits: 2,
            }).format(value) + ' RON';
        else
            return 0;
    }

    const getContractBaseId = function () {
        return contractId;
    }
    const onDeleteBatchRow = function (param, grid) {
        var result = DevExpress.ui.dialog.confirm("<p>Sunteti sigur ca doriti stergerea elementului selectat?</p>", "Stergere");
        result.done(function (dialogResult) {
            deletedRowIndex = param.row.rowIndex;

            if (dialogResult) {
                if (IsDataGridInstance(grid)) {
                    var gridInstance = $(grid).dxDataGrid('instance');
                    gridInstance.deleteRow(deletedRowIndex);
                    gridInstance.element().find(".dx-row-removed").hide();
                }
            }
        });
    }
    const onContractRowClick = function (e) {
        contractBaseId = e.data.Id;
    }
    const onAddTermenLivrare = function () {
        var dataGrid = $("#grid-termene").dxDataGrid("instance");
        dataGrid.beginUpdate();
        dataGrid.addRow();
        dataGrid.endUpdate();
        dataGrid.endCustomLoading();
    }

    const onAddDocumenteScan = function (e) {
        var dataGrid = $("#grid-docs").dxDataGrid("instance");
        myIndex = myIndex - 1;
        docScanRowIdentifier = '';
        dataGrid.on("initNewRow", function (e) {
            e.data["Id"] = myIndex;
            docScanRowIdentifier = GenerateGuid();
            e.data["Identifier"] = docScanRowIdentifier;
        });
        dataGrid.beginUpdate();
        dataGrid.addRow();
        dataGrid.endUpdate();
        dataGrid.endCustomLoading();
    }
    const onAddDetaliiOfertanti = function () {
        var dataGrid = $("#grid-derulare").dxDataGrid("instance");
        dataGrid.beginUpdate();
        dataGrid.addRow();
        dataGrid.endUpdate();
        dataGrid.endCustomLoading();
    }

    const onFileUploaderValueChanged = function (e) {
        const files = e.value;
        if (files.length > 0) {
            $.each(files, (i, file) => {
                var fileIndex = -1;
                if (!docScanIsNewRow) {
                    //rand existent - inlocuire fisier
                    fileIndex = newFiles.indexOfObject("ExistingId", docScanRowIdentifier);
                }
                else {
                    //rand nou
                    fileIndex = newFiles.indexOfObject("Identifier", myIndex);
                }

                var date = new Date(file.lastModified);
                var dataGrid = $(documenteGridId).dxDataGrid("instance");

                if (fileIndex === -1) {
                    newFiles.push({ Identifier: myIndex, File: file, ExistingId: docScanRowIdentifier });
                }
                else {
                    newFiles[fileIndex].File = file;
                }
                dataGrid.cellValue(docScanRowIndex, "NumeDocument", file.name);
                dataGrid.cellValue(docScanRowIndex, "DataDocument", date);
                dataGrid.cellValue(docScanRowIndex, "DataOperare", new Date());
            });
        }
    }

    const onDisableCell = function (e) {
        if (e.rowType === "data" && !e.column.allowEditing) {
            e.cellElement.css('backgroundColor', 'lightgray'); // Light gray background
        }
    }
    const onDefalcareCPVCellChanged = function (e) {
        if (e.parentType === "dataRow" && e.dataField === "ValoareLeiFaraTVA") {
            e.editorOptions.format = "#,##0.00 RON";
            e.editorOptions.onValueChanged = function (args) {
                var dataGrid = $(disponibilCpGridvId).dxDataGrid('instance');
                var rowIndex = e.row.rowIndex;
                // Fetching the entire row data
                var rowData = dataGrid.getDataSource().items()[rowIndex];
                var valCuTva = args.value * (1 + (cotaTva / 100));

                dataGrid.cellValue(rowIndex, "ValoareLeiCuTVA", valCuTva);
                dataGrid.cellValue(rowIndex, "ValoareLeiFaraTVA", args.value);
                dataGrid.cellValue(rowIndex, "DisponibilPAAPRamasFaraTVA", rowData.DisponibilPAAPFaraTVA - args.value);
                dataGrid.cellValue(rowIndex, "DisponibilPAAPRamasCuTVA", rowData.DisponibilPAAPCuTVA - valCuTva);

                dataGrid.repaintRows([rowIndex]);
            };
        }
        if (e.parentType === "dataRow" && e.dataField === "DisponibilPAAPFaraTVA") {
            e.editorOptions.onValueChanged = function (args) {
            }
        }
    }

    const setDisponibilParams = function (operation, ajaxSettings) {
        if (operation === "load") {
            if (contractModelData === undefined || contractModelData === null) {
                ajaxSettings.data.contractId = contractId;
            }
            else {
                ajaxSettings.data.scopAchizitieId = scopAchizitieId;
                if (scopAchizitieId !== contractModelData.ScopAchizitieId) {
                    ajaxSettings.data.contractId = null;
                    contractModelData.ScopAchizitieId = scopAchizitieId;
                }
                else {
                    ajaxSettings.data.contractId = contractModelData.Id;
                }
            }
        }
    }

    const onScopAchizitieChanged = function (args) {
        if (args.component.clickedRowData !== null && args.component.clickedRowData !== undefined) {
            $(disponibilCpGridvId).dxDataGrid('instance').getDataSource().load().then(function (data) {
                var modifiedItems = collectBatchDisponibilCPV();
                if (data.length > 0 && (modifiedItems != undefined && modifiedItems.length > 0)) {
                    var result = DevExpress.ui.dialog.confirm("<p>Sunteti sigur ca doriti schimbarea scopului selectat?<br/> Se vor pierde valorile introduse!</p>", "Schimba scop achizitie");
                    result.done(function (dialogResult) {
                        scopAchizitieId = args.component.clickedRowData.Id;
                        if (dialogResult) {
                            ReloadDataGrid(disponibilCpGridvId);
                            if (IsDataGridInstance(disponibilCpGridvId)) {
                                var dataGrid = $(disponibilCpGridvId).dxDataGrid('instance');
                                var frmInstance = $(formId).dxForm("instance");
                                var formData = frmInstance.option("formData");

                                dataGrid.getDataSource().load().then(function (data) {
                                    if (data.length === 1) {
                                        //populare linie cu valorile din contractBase
                                        dataGrid.cellValue(0, "ValoareLeiCuTVA", formData.ValoareContract);
                                        dataGrid.cellValue(0, "ValoareLeiFaraTVA", formData.ValoareContractfaraTva);
                                        dataGrid.cellValue(0, "DisponibilPAAPRamasFaraTVA", data[0].DisponibilPAAPFaraTVA - formData.ValoareContractfaraTva);
                                        dataGrid.cellValue(0, "DisponibilPAAPRamasCuTVA", data[0].DisponibilPAAPCuTVA - formData.ValoareContract);
                                    }
                                });
                            }
                        }
                    });
                }
                else if (data.length === 0 || (modifiedItems != undefined && modifiedItems.length === 0)) {
                    scopAchizitieId = args.component.clickedRowData.Id;

                    //daca avem intrari in grid, se schimba scopul si trebuie sa stergem din db acele intrari care au id valid    
                    if (data.length > 0) {
                        onDeleteCPV(data);
                    }

                    //incarcam noile date
                    ReloadDataGrid(disponibilCpGridvId);
                    if (IsDataGridInstance(disponibilCpGridvId)) {
                        var dataGrid = $(disponibilCpGridvId).dxDataGrid('instance');
                        var frmInstance = $(formId).dxForm("instance");
                        var formData = frmInstance.option("formData");

                        dataGrid.getDataSource().load().then(function (data) {
                            if (data.length === 1) {
                                //populare linie cu valorile din contractBase
                                if (formData.ValoareContract !== undefined && formData.ValoareContractfaraTva !== undefined) {
                                    dataGrid.cellValue(0, "ValoareLeiCuTVA", formData.ValoareContract);
                                    dataGrid.cellValue(0, "ValoareLeiFaraTVA", formData.ValoareContractfaraTva);
                                    dataGrid.cellValue(0, "DisponibilPAAPRamasFaraTVA", data[0].DisponibilPAAPFaraTVA - formData.ValoareContractfaraTva);
                                    dataGrid.cellValue(0, "DisponibilPAAPRamasCuTVA", data[0].DisponibilPAAPCuTVA - formData.ValoareContract);
                                }
                            }
                        });
                    }
                }
            })
        }
        //pentru situatia in care se schimba valoarea din cod si nu de catre utilizator
        else if (args.value !== 0) {
            scopAchizitieId = args.value;
        }

    }

    const collectBatchDisponibilCPV = function () {
        if (!IsDataGridInstance(disponibilCpGridvId)) {
            return;
        }

        var defaclcareCPV = GetModifiedDataFromGrid(disponibilCpGridvId);
        var model = {
            Id: 0,
            Identifier: '',
            CodCPVID: 0,
            FunctionalaID: 0,
            EconomicaID: 0,
            ValoarePAAPFaraTVA: 0,
            ValoarePAAPCuTVA: 0,
            DisponibilPAAPFaraTVA: 0,
            DisponibilPAAPCuTVA: 0,
            ValoareLeiFaraTVA: 0,
            ValoareLeiCuTVA: 0,
            DisponibilPAAPRamasFaraTVA: 0,
            DisponibilPAAPRamasCuTVA: 0,
            scopAchizitieId: 0,
            ObiectPAAP: '',
            VariantaDetID: 0
        };
        var modifiedItems = CustomCopyTo(model, defaclcareCPV);

        for (let index = 0; index < modifiedItems.length; index++) {
            modifiedItems[index].scopAchizitieId = scopAchizitieId;
        }

        return modifiedItems;
    }
    const getDetailsCancelled = function (e) {
        if (contractBaseData !== null && contractBaseData !== undefined) {
            e.element.dxFileUploader('instance').option('visible', !contractBaseData.Anulat);
        }
        else {
            e.element.dxFileUploader('instance').option('visible', true);
        }
    }
    const onFocusedRowChangeDocScan = function (e) {
        docScanRowIndex = e.rowIndex;
        docScanRowIdentifier = e.row.data.Identifier;
        docScanIsNewRow = e.row.isNewRow !== undefined;
    }
    var deleteFileRow = function (param) {
        var result = DevExpress.ui.dialog.confirm("<p>Sunteti sigur ca doriti stergerea elementului selectat?</p>", "Stergere");
        result.done(function (dialogResult) {
            deletedRowIndex = param.row.rowIndex;

            if (dialogResult) {
                var gridInstance = $(documenteGridId).dxDataGrid('instance');
                gridInstance.deleteRow(deletedRowIndex);
                gridInstance.element().find(".dx-row-removed").hide();
            }
        });
    }
    const onCancelContract = function (e) {
        var result = DevExpress.ui.dialog.confirm("<p>Sunteti sigur ca doriti anularea contractului?</p>", "Anulare contract");
        result.done(function (dialogResult) {

            if (dialogResult) {
                var postData = {
                    id: e.row.data.Id,
                    cancelStatus: true
                };
                ajaxHelper.post(`${apiRoot}/SetCancelStatus`, postData,
                    function (response) {
                        if (response && response.Success) {
                            ReloadDataGrid(gridId);
                        }
                        else {
                            ToastShowError("A aparut o problema cu anulare contractului");
                        }
                    })
            }
        });
    }
    const onActivateContract = function (e) {
        var result = DevExpress.ui.dialog.confirm("<p>Sunteti sigur ca doriti reactivarea contractului?</p>", "Reactivare contract");
        result.done(function (dialogResult) {

            if (dialogResult) {
                var postData = {
                    id: e.row.data.Id,
                    cancelStatus: false
                };
                ajaxHelper.post(`${apiRoot}/SetCancelStatus`, postData,
                    function (response) {
                        if (response && response.Success) {
                            ReloadDataGrid(gridId);
                        }
                        else {
                            ToastShowError("A aparut o problema cu anulare contractului");
                        }
                    })
            }
        });
    }
    const getCancelledVisibile = function (e) {
        var data = e.row.data;
        if (data !== undefined) {
            return data.Anulat;
        }
        else {
            return true;
        }
    }
    const getActiveVisible = function (e) {
        var data = e.row.data;
        if (data !== undefined) {
            return !data.Anulat;
        }
        else {
            return false;
        }
    }
    const isReadOnly = function () {
        //console.log(isCancelled);
        return !!isCancelled;
    }

    const onMonedaChanged = function (args) {
        if (args.component.clickedRowData !== null && args.component.clickedRowData !== undefined) {
            monedaId = args.component.clickedRowData.Id;
            var dbDataContract = $('#dbDataContract').dxDateBox('instance');
            if (dbDataContract) {
                dataDocument = moment(dbDataContract.option('value')).format("YYYY-MM-DD")
            }

            if (monedaId !== defaultMonedaId) {
                ajaxHelper.get(`${apiRootCursValutar}/GetCursValutar?monedaId=${monedaId}&dataCurs=${dataDocument}`, null,
                    function (response) {
                        if (!response || response === 0) {
                            ToastShowError("Nu exista curs valutar pentru moneda selectata la data contractului");
                        }
                        var dbMoneda = $('#dbMoneda').dxDropDownBox('instance');
                        if (dbMoneda) {
                            dbMoneda.option('isValid', !(!response || response === 0));
                        }
                        cursValutar = response ?? 0;

                        var txtCursValutar = $('#txtCursValutar').dxNumberBox('instance');
                        if (txtCursValutar) {
                            txtCursValutar.option('value', cursValutar);
                        }
                    },
                    function (err) {
                        ToastShowError("Au aparut erori la citirea cursului valutar pentru moneda selectata!");
                    });
            }
        }
        else if (args.value !== 0) {
            monedaId = args.value;
        }

        var txtValContractValuta = $('#txtValContractValuta').dxNumberBox('instance');
        if (txtValContractValuta) {
            if (monedaId !== defaultMonedaId) {
                txtValContractValuta.option('disabled', false);
            }
            else {
                txtValContractValuta.option('value', 0);
                txtValContractValuta.option('disabled', true);
            }
        }
    }

    const onTextBoxValueChanged = function (args) {
        if (args.event !== null && args.event !== undefined && args.event.type == 'change') {
            var frmInstance = $("#contractForm").dxForm("instance");
            if (args.element[0].id == 'txtValContractFaraTva') {
                var valFaraTva = args.value;
                var valCuTva = valFaraTva * (1 + (cotaTva / 100));
                frmInstance.updateData("ValoareContract", valCuTva);
            }

            if (args.element[0].id == 'txtValContractValuta') {
                var valFaraTva = args.value * cursValutar;
                frmInstance.updateData("ValoareContractfaraTva", valFaraTva);

                //daca avem cota tva deja selectata, modificam si valoarea cu tva
                var valCuTva = valFaraTva * (1 + (cotaTva / 100));
                frmInstance.updateData("ValoareContract", valCuTva);
            }
        }
    }
    const onDropdownValueChanged = function (args) {
        var frmInstance = $("#contractForm").dxForm("instance");
        var formData = frmInstance.option("formData");
        if (args.component.clickedRowData !== null && args.component.clickedRowData !== undefined) {
            cotaTva = args.component.clickedRowData.Valoare;

            var valFaraTva = formData.ValoareContractfaraTva;
            var valCuTva = valFaraTva * (1 + (cotaTva / 100));
            frmInstance.updateData("ValoareContract", valCuTva);
        }
        //pentru situatia in care se schimba valoarea din cod si nu de catre utilizator
        else if (args.value !== 0) {
            cotaTva = formData.CotaTvaValoare;
        }
    }

    const onDataContractChanged = function (args) {
        if (args.value !== null && args.value !== undefined && args.value !== 0) {
            dataDocument = moment(args.value).format("YYYY-MM-DD");

            if (monedaId !== 0 && monedaId !== defaultMonedaId) {
                ajaxHelper.get(`${apiRootCursValutar}/GetCursValutar?monedaId=${monedaId}&dataCurs=${dataDocument}`, null,
                    function (response) {
                        if (!response || response === 0) {
                            ToastShowError("Nu exista curs valutar pentru moneda selectata la data contractului");
                        }
                        var dbMoneda = $('#dbMoneda').dxDropDownBox('instance');
                        if (dbMoneda) {
                            dbMoneda.option('isValid', !(!response || response === 0));
                        }
                        cursValutar = response ?? 0;
                    },
                    function (err) {
                        ToastShowError("Au aparut erori la citirea cursului valutar pentru moneda selectata!");
                    });
            }
        }
    }

    const setDefaultMoneda = function () {
        ajaxHelper.get('/Nomenclatoare/Moneda/GetMonedaBySimbol?simbol=RON', null,
            function (response) {
                if (response && response.Success) {
                    defaultMonedaId = response.Data.Id;
                }
            },
            function (err) {
                ToastShowError("Au aparut erori la aducerea monedei!");
            });
    }

    return {
        onAddAction: onAddAction,
        onResetGrid: onResetGrid,
        onDelete: onDelete,
        onCancel: onCancel,
        onSave: onSave,
        onEdit: onEdit,
        onRowClick: onRowClick,
        onHidingPopup: onHidingPopup,
        getCurrentYear: getCurrentYear,
        onNumberBoxValueChange: onNumberBoxValueChange,
        getSelectedYear: getSelectedYear,
        onPartnerChanged: onPartnerChanged,
        onOpen: onOpen,
        setSubContractsParams: setSubContractsParams,
        formatNumberForROCulture: formatNumberForROCulture,
        getContractBaseId: getContractBaseId,
        onDeleteBatchRow: onDeleteBatchRow,
        onContractRowClick: onContractRowClick,
        onAddTermenLivrare: onAddTermenLivrare,
        onAddDocumenteScan: onAddDocumenteScan,
        onAddDetaliiOfertanti: onAddDetaliiOfertanti,
        onDisableCell: onDisableCell,
        onDefalcareCPVCellChanged: onDefalcareCPVCellChanged,
        setDisponibilParams: setDisponibilParams,
        onScopAchizitieChanged: onScopAchizitieChanged,
        getDetailsCancelled: getDetailsCancelled,
        onFocusedRowChangeDocScan: onFocusedRowChangeDocScan,
        deleteFileRow: deleteFileRow,
        onCancelContract: onCancelContract,
        onActivateContract: onActivateContract,
        getCancelledVisibile: getCancelledVisibile,
        getActiveVisible: getActiveVisible,
        onUnitatiChanged: onUnitatiChanged,
        isReadOnly: isReadOnly,
        onMonedaChanged: onMonedaChanged,
        onTextBoxValueChanged: onTextBoxValueChanged,
        onDropdownValueChanged: onDropdownValueChanged,
        onDataContractChanged: onDataContractChanged
    }
})();