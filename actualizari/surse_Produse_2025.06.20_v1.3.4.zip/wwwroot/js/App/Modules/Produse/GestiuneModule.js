﻿var gestiuneModule = (function () {
    var gestiuneId = 0;
    var gestiuneLnkId = 0;
    var editRowIndex = -1;
    var parinteGestiuneId = null;
    var parinteLnkGestiuneId = null;
    var gestiuneData = {};

    const apiRoot = "/Produse/Gestiune";
    const popupId = "#upsert-gestiune-popup";
    const pupupLnkId = "#upsert-gestiunelnk-popup";
    const formId = "#upsert-gestiune-form";
    const formLnkId = "#upsert-gestiunelnk-form";
    const treeId = "#treeGestiune";
    const treeLnkId = "#treeLnkGestiune";

    var onAddAction = function (args) {
        var popup = $(popupId).dxPopup("instance");
        if (popup != undefined) {
            popup.option("title", "Adaugare");
        }
        ShowPopup(popupId);
        onClearInfo();

        if (args.row?.data?.Id) {
            parinteGestiuneId = args.row.data.Id;
        }
    }

    var onAddActionLnk = function (args) {
        editRowIndex = -1;
        var popup = $(pupupLnkId).dxPopup("instance");
        if (popup != undefined) {
            popup.option("title", "Adaugare Legatura Tip Spatiu Depozitare");
        }

        ShowPopup(pupupLnkId);
        onClearLnkInfo();

        if (args.row?.data?.Id) {
            parinteLnkGestiuneId = args.row.data.Id;
        }
    }

    const onEditingStart = function (e) {
        e.cancel = true;
    }

    var collectBatchGridData = function (bReturnAllDataAsNewLines = false) {
        if (!IsTreeListInstance(treeLnkId)) {
            return;
        }

        var acte = GetModifiedDataFromTree(treeLnkId);
        var model = {
            Id: 0,
            IdParinte: null,
            CodLocDepozitare: 0,
            NumarInventar: 0,
            NumarUnitatiTipLocDepozitare: 0,
            Adresa: '',
            Ordine: 0,
            DataStart: null,
            DataStop: null,
            TipLocDepozitareId: null,
            GestiuneId: gestiuneId,
        };

        return CustomCopyTo(model, acte, bReturnAllDataAsNewLines);
    }

    var onDelete = function (item) {
        var result = DevExpress.ui.dialog.confirm("<p>Sunteti sigur/a ca doriti stergerea gestiunii selectate ?</p>", "Stergere");
        result.done(function (dialogResult) {
            if (dialogResult) {
                ajaxHelper.delete(`${apiRoot}/Delete/${item.row.key}`,
                    function (response) {
                        HideLoading();
                        if (response) {
                            if (response.Success == false) {
                                ToastShowError(response.Message);
                                return;
                            }
                            ReloadTreeList(treeId);
                        } else {
                            ToastShowError("A aparut o eroare la stergerea intrarilor");
                        }
                    },
                    function (err) {
                        ToastShowError("An error occured");
                        HideLoading();
                    });
            }
        })
    }

    var onDeleteLnk = function (item) {
        var treeLnkInstance = $(treeLnkId).dxTreeList("instance");
        var result = DevExpress.ui.dialog.confirm("<p>Sunteti sigur ca doriti stergerea elementului selectat?</p>", "Stergere");
        result.done(function (dialogResult) {
            deletedRowIndex = item.row.rowIndex;

            if (dialogResult) {
                treeLnkInstance.deleteRow(deletedRowIndex);
                treeLnkInstance.element().find(".dx-row-removed").hide();
            }
        });
    }

    var onResetGrid = function () {
        var tree = $(treeId).dxTreeList("instance");

        tree.state({});
    }

    var onResetLnkGrid = function () {
        var tree = $(treeLnkId).dxTreeList("instance");

        tree.state({});
    }

    var onCancel = function () {
        onClearInfo();
        HidePopup(popupId);
    }

    var onCancelLnk = function () {
        onClearLnkInfo();
        HidePopup("#upsert-gestiunelnk-popup");
    }

    var onHidingPopup = function () {
        global.onHidingUpsertViewPopup(popupId, apiRoot, onClearInfo);
    }

    var onHidingLnkPopup = function () {
        onClearLnkInfo();
        $(pupupLnkId).dxPopup("dispose");
        $(pupupLnkId).load(`${apiRoot}/GetPopupViewLnk`);
    }

    var onSave = function (item) {
        ShowLoading();

        var frmInstance = $(formId).dxForm("instance");

        if (!frmInstance.validate().isValid) {
            HideLoading();
            ToastShowError("Date Invalide!");
            return;
        }

        var gestiuneData = frmInstance.option("formData");
        var range = global.getDateRangeValues('#dateRangeBox');
        var legaturi = collectBatchGridData();

        var postData = {
            Id: gestiuneId,
            Idparinte: parinteGestiuneId,
            UnitatiId: gestiuneData.UnitatiId,
            Cod: gestiuneData.Cod,
            Denumire: gestiuneData.Denumire,
            TipGestiuneId: gestiuneData.TipGestiuneId,
            Ordine: gestiuneData.Ordine,
            ParteneriId: gestiuneData.ParteneriId,
            LegaturiGestiuneTipLocDepozitare: legaturi,
            DataStart: moment(range[0]).format("YYYY-MM-DD"),
            DataStop: moment(range[1]).format("YYYY-MM-DD"),
        };
        console.log(postData);

        ajaxHelper.post(`${apiRoot}/Upsert`,
            postData,
            function (response) {
                HideLoading();

                if (!response || !response.Success) {
                    ToastShowError(response.Message);
                    return;
                }

                HidePopup(popupId);
                ReloadTreeList(treeId);
            },
            function (err) {
                ToastShowError(err.Message);
                HideLoading();
            });

        HideLoading();
    }

    var onSaveLnk = function (item) {
        var frmLnkInstance = $(formLnkId).dxForm("instance");
        var range = global.getDateRangeValues('#dateRangeBoxLnk');

        if (!frmLnkInstance.validate().isValid) {
            ToastShowError("Date Invalide!")
            return;
        }

        if (parinteLnkGestiuneId === 0 || parinteLnkGestiuneId === null) {
            parinteLnkGestiuneId = undefined;
        }

        let dataGrid = $(treeLnkId).dxTreeList("instance");
        let formData = frmLnkInstance.option("formData");
        if (editRowIndex >= 0) {
            dataGrid.cellValue(editRowIndex, "CodLocDepozitare", formData.CodLocDepozitare);
            dataGrid.cellValue(editRowIndex, "NumarInventar", formData.NumarInventar);
            dataGrid.cellValue(editRowIndex, "NumarUnitatiTipLocDepozitare", formData.NumarUnitatiTipLocDepozitare);
            dataGrid.cellValue(editRowIndex, "TipLocDepozitareId", formData.TipLocDepozitareId);
            dataGrid.cellValue(editRowIndex, "IdParinte", parinteLnkGestiuneId);
            dataGrid.cellValue(editRowIndex, "Ordine", formData.Ordine);
            dataGrid.cellValue(editRowIndex, "Adresa", formData.Adresa);
            dataGrid.cellValue(editRowIndex, "DataStart", moment(range[0]).format("YYYY-MM-DD"));
            dataGrid.cellValue(editRowIndex, "DataStop", moment(range[1]).format("YYYY-MM-DD"));
            dataGrid.cellValue(editRowIndex, "GestiuneId", gestiuneId);
        } else {
            dataGrid.on("initNewRow", function (e) {
                e.data["CodLocDepozitare"] = formData.CodLocDepozitare;
                e.data["NumarInventar"] = formData.NumarInventar;
                e.data["NumarUnitatiTipLocDepozitare"] = formData.NumarUnitatiTipLocDepozitare;
                e.data["TipLocDepozitareId"] = formData.TipLocDepozitareId;
                e.data["IdParinte"] = parinteLnkGestiuneId;
                e.data["Ordine"] = formData.Ordine;
                e.data["Adresa"] = formData.Adresa;
                e.data["DataStart"] = moment(range[0]).format("YYYY-MM-DD");
                e.data["DataStop"] = moment(range[1]).format("YYYY-MM-DD");
                e.data["GestiuneId"] = gestiuneId;
            });

            dataGrid.beginUpdate();
            dataGrid.addRow();
            dataGrid.endUpdate();
            dataGrid.endCustomLoading();
            dataGrid.off("initNewRow");
        }

        HidePopup(pupupLnkId);
    }

    var onEdit = function (item) {
        var popup = $(popupId).dxPopup("instance");
        if (popup != undefined) {
            popup.option("title", "Actualizare Gestiune");
        }
        ShowLoading();
        onClearInfo();
        gestiuneId = item.row?.data.Id;
        parinteGestiuneId = item.row?.data.IdParinte;
        getData(gestiuneId);
        item.cancel = true;
    }

    var onEditLnk = function (item) {
        var popup = $("#upsert-gestiunelnk-popup").dxPopup("instance");
        if (popup != undefined) {
            popup.option("title", "Actualizare Legatura Tip Spatiu Depozitare");
        }

        gestiuneLnkId = item.row?.data.Id;
        parinteGestiuneLnkId = item.row?.data.IdParinte;

        editRowIndex = item.row?.rowIndex;
        var clonedData = Object.assign({}, item.row?.data);
        item.event.preventDefault();

        ShowPopup(pupupLnkId);
        var frmLnkInstance = $(formLnkId).dxForm("instance");
        frmLnkInstance.option("formData", clonedData);
        global.setDateRangeValues('#dateRangeBoxLnk', clonedData.DataStart, clonedData.DataStop);
    }

    var getData = function (id) {
        if (!id || id < 1) {
            ToastShowError("Id invalid!")
            return;
        }

        ajaxHelper.get(`${apiRoot}/GetGestiuneDetails?id=${id}`, null,
            function (response) {

                HideLoading();

                console.log(response);

                if (!response || !response.Success) {
                    ToastShowError(response.Message);
                    return;
                }

                ShowPopup(popupId);
                var frmInstance = $(formId).dxForm("instance");
                if (frmInstance != undefined) {
                    gestiuneModelData = response.Data;
                    frmInstance.option("formData", gestiuneModelData);

                    //for daterange
                    global.setDateRangeValues('#dateRangeBox', gestiuneModelData.DataStart, gestiuneModelData.DataStop);
                }
            },
            function (err) {
                ToastShowError("Au aparut erori la citirea datelor!");
                HideLoading();
            });
    }

    var onClearInfo = function () {
        gestiuneId = 0;
        gestiuneLnkId = 0;
        parinteGestiuneId = null;
        gestiuneModelData = null;

        var now = new Date();
        global.setDateRangeValues('#dateRangeBox', new Date(now.getFullYear(), 0, 1), new Date(2099, 11, 31),);
    }

    var onClearLnkInfo = function () {
        gestiuneLnkId = 0;
        parinteLnkGestiuneId = null;

        var now = new Date();
        global.setDateRangeValues('#dateRangeBoxLnk', new Date(now.getFullYear(), 0, 1), new Date(2099, 11, 31),);
    }

    var onRowClick = function (item) {
        gestiuneId = item.data.Id;
    }

    var getLnkGridParam = function (operation, ajaxSettings) {
        if (operation === "load") {
            ajaxSettings.data.id = gestiuneId;
        }
    }

    var onRowLnkClick = function (item) {
        gestiuneLnkId = item.data.Id;
    }

    var showAction = function (params) {
        var data = params.row.data;
        if (!data) {
            return false;
        }

        return true;
    }

    return {
        onAddAction: onAddAction,
        onAddActionLnk: onAddActionLnk,
        onResetGrid: onResetGrid,
        onResetLnkGrid: onResetLnkGrid,
        onDelete: onDelete,
        onDeleteLnk: onDeleteLnk,
        onCancel: onCancel,
        onCancelLnk: onCancelLnk,
        onSave: onSave,
        onSaveLnk: onSaveLnk,
        onEdit: onEdit,
        onEditingStart: onEditingStart,
        onEditLnk: onEditLnk,
        onRowClick: onRowClick,
        onRowLnkClick: onRowLnkClick,
        getLnkGridParam: getLnkGridParam,
        showAction: showAction,
        onHidingPopup: onHidingPopup,
        onHidingLnkPopup: onHidingLnkPopup
    }
})();