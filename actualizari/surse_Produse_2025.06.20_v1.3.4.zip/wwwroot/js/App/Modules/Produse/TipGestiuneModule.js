﻿var tipGestiuneModule = (function () {
    var tipGestiuneId = 0;

    const apiRoot = "/Produse/TipGestiune";
    const gridId = "#gridTipuriGestiune";
    const popupId = "#upsert-tipGestiune-popup";
    const formId = "#upsert-tipGestiune-form";

    var onAddAction = function (args) {
        var popup = $(popupId).dxPopup("instance");
        if (popup !== undefined) {
            popup.option("title", "Adaugare");
        }
        ShowPopup(popupId);
        onClearInfo();
    }

    var onDelete = function (item) {
        var result = DevExpress.ui.dialog.confirm("<p>Sunteti sigur/a ca doriti stergerea elementului selectat?</p>", "Stergere");
        result.done(function (dialogResult) {
            if (dialogResult) {
                ajaxHelper.delete(`${apiRoot}/Delete/${item.row.key}`,
                    function (response) {
                        HideLoading();
                        if (response) {
                            if (response.Success == false) {
                                ToastShowError(response.Message);
                                return;
                            }
                            ReloadDataGrid(gridId);
                        } else {
                            ToastShowError("A aparut o eroare la stergerea intrarilor");
                        }
                    },
                    function (err) {
                        ToastShowError("An error occured");
                        HideLoading();
                    });
            }
        })
    }

    var onResetGrid = function () {
        var grid = $(gridId).dxDataGrid("instance");

        grid.state({});
    }
    var onCancel = function () {
        HidePopup(popupId);
    }

    var onHidingPopup = function () {
        global.onHidingUpsertViewPopup(popupId, apiRoot, onClearInfo);
    }

    var onSave = function (item) {
        ShowLoading();

        var frmInstance = $(formId).dxForm("instance");

        if (!frmInstance.validate().isValid) {
            HideLoading();
            ToastShowError("Date Invalide!");
            return;
        }

        var tipGestiuneData = frmInstance.option("formData");
        var range = global.getDateRangeValues('#dateRangeBox');

        var postData = {
            Id: tipGestiuneId,
            Cod: tipGestiuneData.Cod,
            Denumire: tipGestiuneData.Denumire,
            IsDefault: tipGestiuneData.IsDefault,
            DataStart: moment(range[0]).format("YYYY-MM-DD"),
            DataStop: moment(range[1]).format("YYYY-MM-DD")
        };

        ajaxHelper.post(`${apiRoot}/Upsert`,
            postData,
            function (response) {
                HideLoading();

                if (!response || !response.Success) {
                    ToastShowError(response.Message);
                    return;
                }

                HidePopup(popupId);
                ReloadDataGrid(gridId);
            },
            function (err) {
                ToastShowError(err.Message);
                HideLoading();
            });

        HideLoading();
    }
    var onEdit = function (item) {
        var popup = $(popupId).dxPopup("instance");
        if (popup !== undefined) {
            popup.option("title", "Actualizare");
        }
        ShowLoading();
        onClearInfo();
        tipGestiuneId = item.data.Id;
        getData(item.data.Id);
        item.cancel = true;
    }

    var getData = function (id) {

        if (!id || id < 1) {
            ToastShowError("Id invalid!")
            return;
        }


        ajaxHelper.get(`${apiRoot}/GetTipGestiuneDetails?tipGestiuneId=${id}`, null, 
            function (response) {

                HideLoading();

                if (!response || !response.Success) {
                    ToastShowError(response.Message);
                    return;
                }

                ShowPopup(popupId);
                var frmInstance = $(formId).dxForm("instance");
                if (frmInstance !== undefined) {
                    frmInstance.option("formData", response.Data);

                    global.setDateRangeValues('#dateRangeBox', response.Data.DataStart, response.Data.DataStop);
                }
            },
            function (err) {
                ToastShowError("Au aparut erori la citirea datelor!");
                HideLoading();
            });
    }

    var onClearInfo = function () {
        tipGestiuneId = 0;
        var now = new Date();
        global.setDateRangeValues('#dateRangeBox', new Date(now.getFullYear(), 0, 1), new Date(2099, 11, 31),);
    }

    var onRowClick = function (item) {
        tipGestiuneId = item.data.Id;
    }

    return {
        onAddAction: onAddAction,
        onResetGrid: onResetGrid,
        onDelete: onDelete,
        onCancel: onCancel,
        onSave: onSave,
        onEdit: onEdit,
        onRowClick: onRowClick,
        onHidingPopup: onHidingPopup
    }
})();