﻿var tipLocDepozitareModule = (function () {
    var tipLocDepozitareId = 0;

    const apiRoot = "/Produse/TipLocDepozitare";
    const gridId = "#gridTipuriLocDepozitare";
    const popupId = "#upsert-tipLocDepozitare-popup";
    const formId = "#upsert-tipLocDepozitare-form";

    var calculateVolumCalculat = function () {
        var frmInstance = $(formId).dxForm("instance");
        if (frmInstance) {
            var formData = frmInstance.option("formData");
            var inaltime = parseFloat(formData.Inaltime) || 0;
            var latime = parseFloat(formData.Latime) || 0;
            var adancime = parseFloat(formData.Adancime) || 0;

            var volumCalculat = inaltime * latime * adancime;

            // Update the VolumCalculat field in the form
            frmInstance.updateData("VolumCalculat", volumCalculat);
        }
    };

    var onAddAction = function (args) {
        var popup = $(popupId).dxPopup("instance");
        if (popup !== undefined) {
            popup.option("title", "Adaugare");
        }
        ShowPopup(popupId);
        onClearInfo();
    }

    var onDelete = function (item) {
        var result = DevExpress.ui.dialog.confirm("<p>Sunteti sigur/a ca doriti stergerea elementului selectat?</p>", "Stergere");
        result.done(function (dialogResult) {
            if (dialogResult) {
                ajaxHelper.delete(`${apiRoot}/Delete/${item.row.key}`,
                    function (response) {
                        HideLoading();
                        if (response) {
                            if (response.Success == false) {
                                ToastShowError(response.Message);
                                return;
                            }
                            ReloadDataGrid(gridId);
                        } else {
                            ToastShowError("A aparut o eroare la stergerea intrarilor");
                        }
                    },
                    function (err) {
                        ToastShowError("An error occured");
                        HideLoading();
                    });
            }
        })
    }

    var onResetGrid = function () {
        var grid = $(gridId).dxDataGrid("instance");

        grid.state({});
    }
    var onCancel = function () {
        HidePopup(popupId);
    }

    var onHidingPopup = function () {
        global.onHidingUpsertViewPopup(popupId, apiRoot, onClearInfo);
    }

    var onSave = function (item) {
        ShowLoading();

        var frmInstance = $(formId).dxForm("instance");

        if (!frmInstance.validate().isValid) {
            HideLoading();
            ToastShowError("Date Invalide!");
            return;
        }

        var tipLocDepozitareData = frmInstance.option("formData");
        var range = global.getDateRangeValues('#dateRangeBox');

        var postData = {
            Id: tipLocDepozitareId,
            Cod: tipLocDepozitareData.Cod,
            Denumire: tipLocDepozitareData.Denumire,
            Inaltime: tipLocDepozitareData.Inaltime,
            Latime: tipLocDepozitareData.Latime,
            Adancime: tipLocDepozitareData.Adancime,
            VolumCalculat: tipLocDepozitareData.VolumCalculat,
            VolumRezervor: tipLocDepozitareData.VolumRezervor,
            DataStart: moment(range[0]).format("YYYY-MM-DD"),
            DataStop: moment(range[1]).format("YYYY-MM-DD")
        };

        ajaxHelper.post(`${apiRoot}/Upsert`,
            postData,
            function (response) {
                HideLoading();

                if (!response || !response.Success) {
                    ToastShowError(response.Message);
                    return;
                }

                HidePopup(popupId);
                ReloadDataGrid(gridId);
            },
            function (err) {
                ToastShowError(err.Message);
                HideLoading();
            });

        HideLoading();
    }
    var onEdit = function (item) {
        var popup = $(popupId).dxPopup("instance");
        if (popup !== undefined) {
            popup.option("title", "Actualizare");
        }
        ShowLoading();
        onClearInfo();
        tipLocDepozitareId = item.data.Id;
        getData(item.data.Id);
        item.cancel = true;
    }

    var getData = function (id) {

        if (!id || id < 1) {
            ToastShowError("Id invalid!")
            return;
        }


        ajaxHelper.get(`${apiRoot}/GetTipLocDepozitareDetails?tipLocDepozitareId=${id}`, null,
            function (response) {

                HideLoading();

                if (!response || !response.Success) {
                    ToastShowError(response.Message);
                    return;
                }

                ShowPopup(popupId);
                var frmInstance = $(formId).dxForm("instance"); 
                if (frmInstance !== undefined) {
                    frmInstance.option("formData", response.Data);

                    global.setDateRangeValues('#dateRangeBox', response.Data.DataStart, response.Data.DataStop);
                }
            },
            function (err) {
                ToastShowError("Au aparut erori la citirea datelor!");
                HideLoading();
            });
    }

    var onClearInfo = function () {
        tipLocDepozitareId = 0;
        var now = new Date();
        global.setDateRangeValues('#dateRangeBox', new Date(now.getFullYear(), 0, 1), new Date(2099, 11, 31),);
    }

    var onRowClick = function (item) {
        tipLocDepozitareId = item.data.Id;
    }

    return {
        calculateVolumCalculat: calculateVolumCalculat,
        onAddAction: onAddAction,
        onResetGrid: onResetGrid,
        onDelete: onDelete,
        onCancel: onCancel,
        onSave: onSave,
        onEdit: onEdit,
        onRowClick: onRowClick,
        onHidingPopup: onHidingPopup
    }
})();