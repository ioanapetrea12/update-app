﻿
const formularModule = (function () {

    var formularId = 0;
    var formularDetId = 0;
    var parinteFormularId = 0;
    const apiRoot = "/Produse/Formular";
    const gridId = "#treeFormular";
    const popupId = "#upsert-popup";
    const popupDetId = "#upsert-popup-det";
    const formId = "#upsert-formular";
    var unitateId = '00000000-0000-0000-0000-000000000000';
    var docScanRowIndex = -1;
    var docScanRowIdentifier = '';
    var docScanIsNewRow = false;
    var newFiles = [];
    var myIndex = 0;
    var upsertDetId = '';
    var isReadOnly = false;

    var onAddAction = function (args) {
        var popup = $(popupId).dxPopup("instance");
        if (popup != undefined) {
            popup.option("title", "Adaugare");
        }
        upsertDetId = '#form-formular-det';
        ShowPopup(popupId);
        onClearInfo();

        if (args.row?.data?.Id) {
            parinteFormularId = args.row.data.Id;
            isReadOnly = true;
            setFieldsReadOnly(isReadOnly);
            getData(parinteFormularId,true);

        }
        else {
            isReadOnly = false;
            setFieldsReadOnly(isReadOnly);
        }
    }

    var onAddActionDet = function (args) {
        editRowIndex = -1;
        var popup = $(popupDetId).dxPopup("instance");
        if (popup != undefined) {
            popup.option("title", "Adaugare detalii formular");
        }
        ShowPopup(popupDetId);
    }

    var onDelete = function (item) {
        var result = DevExpress.ui.dialog.confirm("<p>Sunteti sigur/a ca doriti stergerea elementului selectat?</p>", "Stergere");
        result.done(function (dialogResult) {
            if (dialogResult) {
                var postData = {
                    Id: item.row.key
                };
                ajaxHelper.post(`${apiRoot}/Delete`, postData,
                    function (response) {
                        HideLoading();
                        if (!response || !response.Success) {
                            ToastShowError("A aparut o eroare la stergerea inregistrarii");
                            return;
                        }
                        if (response.Success == false) {
                            ToastShowError(response.Message);
                            return;
                        }
                        ReloadTreeList(gridId);
                    },
                    function (err) {
                        ToastShowError("An error occured");
                        HideLoading();
                    });
            }
        })
    }

    var onResetGrid = function () {
        var grid = $(gridId).dxDataGrid("instance");

        grid.state({});
    }
    var onCancel = function () {
        HidePopup(popupId);
    }

    var onCancelDet = function () {
        HidePopup(popupDetId);
    }

    const onHidingPopup = function () {
        global.onHidingUpsertViewPopup(popupId, apiRoot, onClearInfo);
    }

    const onHidingPopupDet = function () {
        $('#upsert-popup-det').dxPopup("dispose");
        $('#upsert-popup-det').load(`${apiRoot}/GetPopupFormularViewDet?module=Formular`);

    }

    const toBase64 = file => new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => resolve(reader.result.split(',')[1]);
        reader.onerror = error => reject(error);
    });

    const getFilesToUpload = async function () {
        const payload = { FormularFiles: null };
        if (newFiles !== null && newFiles.length > 0) {
            const filesToAdd = await Promise.all(newFiles.map(async (itemRow) => {
                const fileExtension = itemRow.File.name.split('.').pop();
                const fileType = getMimeTypeByExtension(fileExtension) || itemRow.File.type;

                return {
                    Identifier: itemRow.Identifier,
                    ExistingId: itemRow.ExistingId,
                    AddedFile: {
                        FileName: itemRow.File.name,
                        FileContent: await toBase64(itemRow.File),
                        FileType: fileType.split(':')[1].split(';')[0]
                    }
                };
            }));
            payload.FormularFiles = filesToAdd;
        }
        return payload;
    }


    var onSave = async function (item) {
        ShowLoading();

        var frmInstance = $(formId).dxForm("instance");

        if (!frmInstance.validate().isValid) {
            HideLoading();
            ToastShowError("Date Invalide!");
            return;
        }

        const formularData = frmInstance.option("formData");


        const postData = {
            Id: formularId,
            IdParinte: parinteFormularId != 0 ? parinteFormularId : null,
            UnitatiId: formularData.UnitatiId,
            Denumire: formularData.Denumire,
            TermenLivrare: moment(formularData.TermenLivrare).format("YYYY-MM-DD"),
            ProdusId: formularData.ProdusId,
            Umid: formularData.Umid,
            Cantitate: formularData.Cantitate,
            ParteneriId: formularData.ParteneriId,
            Conformitate: formularData.Conformitate,
            Prelungire: formularData.Prelungire,
            Anulare: formularData.Anulare,
            CompartimentId: formularData.CompartimentId,
            ComisieBaseId: formularData.ComisieBaseId,
            Document: {
                UnitatiId: formularData.UnitatiId,
                Id: formularData.Document.Id,
                Nr: formularData.Document.Nr,
                TipDocumentId: formularData.Document.TipDocumentId,
                DataDocument: formularData.Document.DataDocument ? moment(formularData.Document.DataDocument).format("YYYY-MM-DD") : null,
            }
        };

        const gridFormularDet = $("#grid-formular-det").dxDataGrid('instance');
        if (gridFormularDet !== undefined) {
            const items = gridFormularDet.getVisibleRows().filter(x => !x.removed && x.data).map(x => x.data);
            const itemsToAdd = [];
            for (let i = 0; i < items.length; i++) {

                var itemRow = items[i];
                var currentId = getValue(itemRow, 'Id');
                if (currentId === null)
                    currentId = 0;
                const item = {
                    Id: currentId,
                    FormulareId: formularId,
                    UnitatiId: itemRow.UnitatiId,
                    Cantitate: itemRow.Cantitate
                };
                itemsToAdd.push(item);
            }
            postData.FormularDetModels = itemsToAdd;
        }
        else {
            postData.FormularDetModels = null;
        }

        const docLinkFormularGrid = $("#docLinkFormularGrid").dxDataGrid('instance');
        if (docLinkFormularGrid !== undefined) {
            const items = docLinkFormularGrid.getVisibleRows().filter(x => !x.removed && x.data).map(x => x.data);

            const itemsToAdd = [];
            for (let i = 0; i < items.length; i++) {

                var itemRow = items[i];

                var currentId = getValue(itemRow, 'Id');
                if (currentId === null)
                    currentId = 0;
                const item = {
                    Id: currentId,
                    FormulareId: formularId,
                    Denumire: itemRow.Denumire,
                    DataDoc: moment(itemRow.DataDoc).format("YYYY-MM-DD"),
                    Identifier: itemRow.Identifier,
                    DocLink: itemRow.DocLink
                };
                itemsToAdd.push(item);
            }
            postData.DocLinkFormularModels = itemsToAdd;
        }
        else {
            postData.DocLinkFormularProdusModels = null;
        }

        var formFiles = await getFilesToUpload();
        postData.FormularFiles = formFiles.FormularFiles;

        ajaxHelper.post(`${apiRoot}/Upsert`,
            postData,
            function (response) {

                HideLoading();

                if (!response || !response.Success) {
                    ToastShowError(response.Message);
                    return;
                }

                HidePopup(popupId);
                ReloadTreeList(gridId);
            },
            function (err) {
                ToastShowError(err.Message);
                HideLoading();
            });

        HideLoading();
    }

    var onSaveDet = async function (item) {
        var formDetInstance = $(upsertDetId).dxForm("instance");

        if (!formDetInstance.validate().isValid) {
            ToastShowError("Date Invalide!");
            return;
        }


        let dataGrid = $('#grid-formular-det').dxDataGrid("instance");
        let formData = formDetInstance.option("formData");

        //verifica suma cantitatilor distribuite sa nu fie mai mare decat cantitatea din formular 
        var cantitate = $(formId).dxForm("instance").option("formData").Cantitate;
        var cantitateDet = 0;
        if (dataGrid !== undefined) {
            const items = dataGrid.getVisibleRows().filter(x => !x.removed && x.data).map(x => x.data);
            for (let i = 0; i < items.length; i++) {

                var itemRow = items[i];
                var currentId = getValue(itemRow, 'Id');
                if (currentId === null)
                    currentId = 0;
                cantitateDet += itemRow.Cantitate;
            }
        }
        cantitateDet += formData.Cantitate;
        if (cantitateDet > (cantitate == undefined ? 0 : cantitate)) {
            ToastShowError(`Suma cantitatilor ditribuite: ${cantitateDet} != cantitatea din formular: ${(cantitate == undefined ? 0 : cantitate) }`);
            return;
        }

        if (editRowIndex >= 0) {
            dataGrid.cellValue(editRowIndex, "UnitatiId", formData.UnitatiId);
            dataGrid.cellValue(editRowIndex, "Cantitate", formData.Cantitate);
            dataGrid.cellValue(editRowIndex, "Key", formData.Key);
        } else {
            dataGrid.on("initNewRow", function (e) {
                e.data["UnitatiId"] = formData.UnitatiId;
                e.data["Cantitate"] = formData.Cantitate;
                e.data["Key"] = formData.Key;
            });

            dataGrid.beginUpdate();
            dataGrid.addRow();
            dataGrid.endUpdate();
            dataGrid.endCustomLoading();
            dataGrid.off("initNewRow");
        }

        HidePopup(popupDetId);
    }

   var onEdit = function (item) {
        var popup = $(popupId).dxPopup("instance");
        if (popup != undefined) {
            popup.option("title", "Actualizare");
        }
        upsertDetId = '#form-formular-det';
        ShowLoading();
        onClearInfo();
        formularId = item.data.Id;
        parinteFormularId = item.data.IdParinte;
        getData(item.data.Id, false);
        item.cancel = true;
    }

   var getData = function (id, isChildAdd) {

        if (!id || id < 1) {
            ToastShowError("Id invalid!")
            return;
        }

        ajaxHelper.get(`${apiRoot}/GetFormularDetails?id=${id}`, null,
            function (response) {

                HideLoading();

                if (!response || !response.Success) {
                    ToastShowError(response.Message);
                    return;
                }

                ShowPopup(popupId);
                var frmInstance = $(formId).dxForm("instance");
                if (frmInstance != undefined) {
                    unitateId = response.Data.UnitatiId;
                    if (isChildAdd)
                        response.Data.Document.Id = 0;
                    frmInstance.option("formData", response.Data);
                }
            },
            function (err) {
                ToastShowError("Au aparut erori la citirea datelor!");
                HideLoading();
            });
    }

    var onClearInfo = function () {
        formularId = 0;
        parinteFormularId = null;
        unitateId = '00000000-0000-0000-0000-000000000000';
    }


    var onRowClick = function (item) {
        formularId = item.data.Id;
    }

    const onPrintRaport = function (e) {
        var codRaport = e.row.data.CodInternRaport;
        ShowLoading();
        ajaxHelper.get(`/Administrare/Raport/GetFormularLinkRaport?formularId=${e.row.data.Id}&codInternRaport=${codRaport}`, null,
            function (response) {
                if (!response || !response.Success) {
                    ToastShowError(response.Message);
                    return;
                }

                window.open(response.Data, '_blank');
                HideLoading();
            },
            function (error) {

            });
        HideLoading();
    }

    const onProdusOpen = function (e) {
        e.component.getDataSource().load().then(function (data) {
            ReloadDataGrid("#ComboGridProduse");
        })
    }

    const onCompartimentOpen = function (e) {
        e.component.getDataSource().load().then(function (data) {
            ReloadDataGrid("#ComboCompartimenteGrid");
        })
    }

    const onComisieBaseOpen = function (e) {
        e.component.getDataSource().load().then(function (data) {
            ReloadDataGrid("#ComisieGrid");
        })
    }

    const onUnitatiChanged = function (args) {
        var produs = $("#ddlProdus").dxDropDownBox("instance");
        var compartiment = $("#ddlCompartiment").dxDropDownBox("instance");
        var comisieBase = $("#ddlComisieBase").dxDropDownBox("instance");
        if (args.component.clickedRowData !== null && args.component.clickedRowData !== undefined) {
            unitateId = args.component.clickedRowData.Id;
            if (produs) {
                produs.option('value', null);
            }
            if (compartiment) {
                compartiment.option('value', null);
            }
            if (comisieBase) {
                comisieBase.option('value', null);
            }
        } else if (args.value !== 0) {
            unitateId = args.value;
        }
    }

    const onAddDocumenteScan = function (e) {
        var dataGrid = $("#docLinkFormularGrid").dxDataGrid("instance");
        myIndex = myIndex - 1;
        docScanRowIdentifier = '';
        dataGrid.on("initNewRow", function (e) {
            e.data["Id"] = myIndex;
            docScanRowIdentifier = GenerateGuid();
            e.data["Identifier"] = docScanRowIdentifier;
        });
        dataGrid.beginUpdate();
        dataGrid.addRow();
        dataGrid.endUpdate();
        dataGrid.endCustomLoading();
    }

    const downloadFile = function (e) {
        var docLink = e.row.data.DocLink;
        if (docLink === undefined || docLink === '')
            DevExpress.ui.notify("Nu exista fisier pentru descarcare", "error", 2000);

        var fileName = docLink.split(/(\\|\/)/g).pop();
        var fileExtension = fileName.split('.').pop();

        ShowLoading();

        var body = {
            FilePath: docLink
        }
        ajaxHelper.post(`${apiRoot}/DownloadFile`, body,
            function (response) {
                if (!response || !response.Success) {
                    ToastShowError(response.Message);
                    HideLoading();
                    return;
                }
                const fileName = response.Data.FileName;
                const content = response.Data.FileContent;
                const fileType = response.Data.FileType;

                const byteCharacters = atob(content);
                const byteNumbers = new Array(byteCharacters.length);
                for (let i = 0; i < byteCharacters.length; i++) {
                    byteNumbers[i] = byteCharacters.charCodeAt(i);
                }
                const byteArray = new Uint8Array(byteNumbers);

                const blob = new Blob([byteArray], { type: fileType });
                const link = document.createElement('a');
                link.href = URL.createObjectURL(blob);
                link.download = fileName;
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
                URL.revokeObjectURL(link.href);
                HideLoading();
            },
            function (err) {
                ToastShowError("Au aparut erori la citirea datelor!");
                HideLoading();
            });

    }

    const deleteFile = function (param) {
        var result = DevExpress.ui.dialog.confirm("<p>Sunteti sigur ca doriti stergerea elementului selectat?</p>", "Stergere");
        result.done(function (dialogResult) {
            deletedRowIndex = param.row.rowIndex;

            if (dialogResult) {
                var gridInstance = $('#docLinkFormularGrid').dxDataGrid('instance');
                gridInstance.deleteRow(deletedRowIndex);
                gridInstance.element().find(".dx-row-removed").hide();
            }
        });
    }

    const onFileUploaderValueChanged = function (e) {
        const files = e.value;
        if (files.length > 0) {
            $.each(files, (i, file) => {
                var fileIndex = -1;
                if (!docScanIsNewRow) {
                    //rand existent - inlocuire fisier
                    fileIndex = newFiles.indexOfObject("ExistingId", docScanRowIdentifier);
                }
                else {
                    //rand nou
                    fileIndex = newFiles.indexOfObject("Identifier", myIndex);
                }

                var date = new Date(file.lastModified);
                var dataGrid = $("#docLinkFormularGrid").dxDataGrid("instance");
                //console.log(date);
                if (fileIndex === -1) {
                    newFiles.push({ Identifier: myIndex, File: file, ExistingId: docScanRowIdentifier });
                }
                else {
                    newFiles[fileIndex].File = file;
                }
                dataGrid.cellValue(docScanRowIndex, "Denumire", file.name);
                dataGrid.cellValue(docScanRowIndex, "DataDoc", new Date());
            });
        }
    }

    const onFocusedRowChangeDocScan = function (e) {
        docScanRowIndex = e.rowIndex;
        docScanRowIdentifier = e.row.data.Identifier;
        docScanIsNewRow = e.row.isNewRow !== undefined;
    }

    const onSetFormularId = function (operation, ajaxSettings) {
        if (operation === "load") {
            ajaxSettings.data.formularId = formularId;
        }
    }
    const setUnitateParam = function (operation, ajaxSettings) {
        ajaxSettings.data.UnitateId = unitateId;
    }
    const getUnitateId = function () {
        return unitateId;
    }

    const setFieldsReadOnly = function (isReadOnly) {

        var dropDownUnitatiInstance = $('#ddlUnitateId').dxDropDownBox('instance');

        if (dropDownUnitatiInstance) {
            dropDownUnitatiInstance.option('readOnly', isReadOnly);
        }

        var dropDownProdusInstance = $('#ddlProdus').dxDropDownBox('instance');

        if (dropDownProdusInstance) {
            dropDownProdusInstance.option('readOnly', isReadOnly);
        }

        var dropDownPartenerInstance = $('#ddlPartener').dxDropDownBox('instance');

        if (dropDownPartenerInstance) {
            dropDownPartenerInstance.option('readOnly', isReadOnly);
        }
    }
    const setReadOnly = function () {
        return !!isReadOnly;
    }

    return {
        onAddAction: onAddAction,
        onAddActionDet: onAddActionDet,
        onResetGrid: onResetGrid,
        onDelete: onDelete,
        onCancel: onCancel,
        onCancelDet: onCancelDet,
        onSave: onSave,
        onSaveDet: onSaveDet,
        onEdit: onEdit,
        onRowClick: onRowClick,
        onHidingPopup: onHidingPopup,
        onHidingPopupDet: onHidingPopupDet,    
        onPrintRaport: onPrintRaport,
        onProdusOpen: onProdusOpen,
        onComisieBaseOpen: onComisieBaseOpen,
        onCompartimentOpen: onCompartimentOpen,
        onUnitatiChanged: onUnitatiChanged,
        setUnitateParam: setUnitateParam,
        getUnitateId: getUnitateId,
        onAddDocumenteScan: onAddDocumenteScan,
        downloadFile: downloadFile,
        deleteFile: deleteFile, 
        onFileUploaderValueChanged: onFileUploaderValueChanged,
        onFocusedRowChangeDocScan: onFocusedRowChangeDocScan,
        onSetFormularId: onSetFormularId,
        setFieldsReadOnly: setFieldsReadOnly,
        setReadOnly: setReadOnly
    }
})();