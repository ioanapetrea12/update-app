﻿var grupaProdusModule = (function () {
    var grupaProdusId = null;
    var grupaProdusModelData = {};


    const apiRoot = "/Produse/GrupaProdus";
    const popupId = "#upsert-grupaProdus-popup";
    const formId = "#upsert-grupaProdus-form";
    const gridId = "#gridGrupaProdus";

    var onAddAction = function (args) {
        var popup = $(popupId).dxPopup("instance");
        if (popup != undefined) {
            popup.option("title", "Adaugare");
        }
        ShowPopup(popupId);
        onClearInfo();

        if (args.row?.data?.Id) {
            parinteArticolId = args.row.data.Id;

            var parentCod = args.row.data.Cod;

            var frmInstance = $(formId).dxForm("instance");
            frmInstance.option("formData", { Cod: parentCod });
        }
    }

    var onDelete = function (item) {
        var result = DevExpress.ui.dialog.confirm("<p>Sunteti sigur/ă că doriți ștergerea elementului selectat?</p>", "Ștergere");
        result.done(function (dialogResult) {
            if (dialogResult) {
                var confirmation = DevExpress.ui.dialog.confirm("<p>Aceasta actiune este ireversibila. <br/> Sunteti sigur/a ca doriti sa continuati?</p>", "Stergere");
                confirmation.done(function (confirmationResult) {
                    if (confirmationResult) {
                        ajaxHelper.delete(`${apiRoot}/Delete/${item.row.key}`,
                            function (response) {
                                HideLoading();
                                if (response) {
                                    if (response.Success == false) {
                                        ToastShowError(response.Message);
                                        return;
                                    }
                                    ReloadDataGrid(gridId);
                                } else {
                                    ToastShowError("A apărut o eroare la ștergerea intrărilor");
                                }
                            },
                            function (err) {
                                ToastShowError("An error occured");
                                HideLoading();
                            });
                    }
                });
            }
        })
    }

    var onResetGrid = function () {
        var grid = $(gridId).dxDataGrid("instance");

        grid.state({});
    }
    var onCancel = function () {
        onClearInfo();
        HidePopup(popupId);
    }

    var onHidingPopup = function () {
        global.onHidingUpsertViewPopup(popupId, apiRoot, onClearInfo);
    }

    var onSave = function (item) {
        ShowLoading();

        var frmInstance = $(formId).dxForm("instance");

        if (!frmInstance.validate().isValid) {
            HideLoading();
            ToastShowError("Date Invalide!");
            return;
        }

        var grupaProdusData = frmInstance.option("formData");
        var range = global.getDateRangeValues('#dateRangeBox');

        var postData = {
            Id: grupaProdusId,
            Cod: grupaProdusData.Cod,
            Denumire: grupaProdusData.Denumire,
            Ordine: grupaProdusData.Ordine,
            DataStart: moment(range[0]).format("YYYY-MM-DD"),
            DataStop: moment(range[1]).format("YYYY-MM-DD")
        };

        ajaxHelper.post(`${apiRoot}/Upsert`,
            postData,
            function (response) {
                HideLoading();

                if (!response || !response.Success) {
                    ToastShowError(response.Message);
                    return;
                }

                HidePopup(popupId);
                ReloadDataGrid(gridId);
            },
            function (err) {
                ToastShowError(err.Message);
                HideLoading();
            });

        HideLoading();
    }
    var onEdit = function (item) {
        var popup = $(popupId).dxPopup("instance");
        if (popup != undefined) {
            popup.option("title", "Actualizare");
        }
        ShowLoading();
        onClearInfo();
        grupaProdusId = item.data.Id;
        getData(grupaProdusId);
        item.cancel = true;
    }

    var getData = function (id) {

        if (!id || id < 1) {
            ToastShowError("Id invalid!")
            return;
        }


        ajaxHelper.get(`${apiRoot}/GetGrupaProdusDetails?grupaProdusId=${id}`, null,
            function (response) {

                HideLoading();

                console.log(response);

                if (!response || !response.Success) {
                    ToastShowError(response.Message);
                    return;
                }

                ShowPopup(popupId);
                var frmInstance = $(formId).dxForm("instance");
                if (frmInstance != undefined) {
                    grupaProdusModelData = response.Data;
                    frmInstance.option("formData", grupaProdusModelData);

                    //for daterange
                    global.setDateRangeValues('#dateRangeBox', grupaProdusModelData.DataStart, grupaProdusModelData.DataStop);
                }
            },
            function (err) {
                ToastShowError("Au aparut erori la citirea datelor!");
                HideLoading();
            });
    }

    var onClearInfo = function () {
        grupaProdusId = null;
        parinteArticolId = null;
        grupaProdusModelData = null;

        var now = new Date();
        global.setDateRangeValues('#dateRangeBox', new Date(now.getFullYear(), 0, 1), new Date(2099, 11, 31),);
    }

    var onRowClick = function (item) {
        grupaProdusId = item.data.Id;
    }

    return {
        onAddAction: onAddAction,
        onResetGrid: onResetGrid,
        onDelete: onDelete,
        onCancel: onCancel,
        onSave: onSave,
        onEdit: onEdit,
        onRowClick: onRowClick,
        onHidingPopup: onHidingPopup
    }
})();