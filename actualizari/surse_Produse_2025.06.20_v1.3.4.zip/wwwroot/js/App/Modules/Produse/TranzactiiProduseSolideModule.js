﻿const tranzactiiProduseSolideModule = (function () {
    const dataLucru = new Date(window.AppConfig.dataLucru);

    var solidePopupId = '';
    var solideDetPopupId = '';
    var generalApiRoot = '/Produse/TranzactiiProduse';
    var gridId = '#gridTranzactiiProdSolide';
    var formDetId = '';
    var docScanRowIndex = -1;
    var docScanRowIdentifier = '';
    var docScanIsNewRow = false;
    var newFiles = [];
    var myIndex = 0;
    var partenerId = 0;
    var editRowIndex = -1;
    var isReadOnly = false;

    var onResetGrid = function () {
        var grid = $(gridId).dxDataGrid("instance");

        grid.state({});
    }

    var onCancel = function () {
        HidePopup(solidePopupId);
    }

    var onHidingPopup = function () {
        $(solidePopupId).dxPopup("dispose");
        //console.log(solidePopupId);
        if (solidePopupId == '#upsert-iesire-solide-popup') {
            $(solidePopupId).load(`${generalApiRoot}/GetPopupTranzactiiView?cod=SIe`);
        }
        if (solidePopupId == '#upsert-intrare-solide-popup') {
            $(solidePopupId).load(`${generalApiRoot}/GetPopupTranzactiiView?cod=SIn`);
        }

        onClearInfo();
    }

    var onHidingIntrariDetPopup = function () {

        $('#upsert-intrare-det-solide-popup').dxPopup("dispose");
        $('#upsert-intrare-det-solide-popup').load(`${generalApiRoot}/GetPopupIntrareViewDet?module=TranzactiiProduseSolide`);
    }

    var onHidingIesiriDetPopup = function () {

        $('#upsert-iesire-det-solide-popup').dxPopup("dispose");
        $('#upsert-iesire-det-solide-popup').load(`${generalApiRoot}/GetPopupIesireViewDet?module=TranzactiiProduseSolide`);
    }

    var onCancelDet = function () {

        HidePopup(solideDetPopupId);
    }

    var onAddSolide = function (type) {
        var title = '';

        if (type === 'iesire') {
            solidePopupId = '#upsert-iesire-solide-popup';
            solideDetPopupId = '#upsert-iesire-det-solide-popup';
            formDetId = '#form-iesire-det-solide';
            title = 'Iesire produse solide - Adaugare';
        } else if (type === 'intrare') {
            solidePopupId = '#upsert-intrare-solide-popup';
            solideDetPopupId = '#upsert-intrare-det-solide-popup';
            formDetId = '#form-intrare-det-solide';
            title = 'Intrare produse solide - Adaugare';
        }

        var popUpSolide = $(solidePopupId).dxPopup('instance');

        popUpSolide.option('title', title);
        ShowPopup(solidePopupId);

        if (type === 'iesire') {
            const frmInstance = $('#form-iesire-solide').dxForm("instance");
            frmInstance.option("formData.DataDocument", dataLucru);
        }
        else if (type === 'intrare') {
            const frmInstance = $('#form-intrare-solide').dxForm("instance");
            frmInstance.option("formData.DataDocument", dataLucru);
        }
        isReadOnly = false;
        tranzactiiProduseModule.setFieldsReadOnly(isReadOnly);
    }

    const onClearInfo = function () {
        solidePopupId = '';
        solideDetPopupId = '';
        planAchizitieDetId = 0;
        newFiles = [];
        isReadOnly = false;
        tranzactiiProduseModule.resetUnitateId();
        tranzactiiProduseModule.setPlanAchizitieId(0);
        tranzactiiProduseModule.setTranzactProductBaseId(0);
        tranzactiiProduseModule.setGestiuniTipLocDepozitareId(0);
        tranzactiiProduseModule.setGestiuneDestinatieId(0);
        tranzactiiProduseModule.setComisieGestiuneId(0);
        tranzactiiProduseModule.setComisieReceptieId(0);
    }

    const onSaveIntrariSolide = async function () {
        ShowLoading();
        var frmInstance = $('#form-intrare-solide').dxForm("instance");

        if (!frmInstance.validate().isValid) {
            HideLoading();
            ToastShowError("Date Invalide!");
            return;
        }

        const formData = frmInstance.option("formData");

        const postData = await getSubmitIntrarePayload(formData);

        if (postData && postData != null) {
            ajaxHelper.post(`${generalApiRoot}/UpsertIntrare`,
                postData,
                function (response) {
                    HideLoading();

                    if (!response || !response.Success) {
                        ToastShowError(response.Message);
                        return;
                    }

                    ToastShowSuccess(response.Data);

                    HidePopup(solidePopupId);
                    ReloadDataGrid(gridId);
                },
                function (err) {
                    ToastShowError(err.Message);
                    HideLoading();
                });
        }
        else {
            HideLoading();
        }
    }

    const onSaveIesiriSolide = async function () {
        ShowLoading();
        var frmInstance = $('#form-iesire-solide').dxForm("instance");

        if (!frmInstance.validate().isValid) {
            HideLoading();
            ToastShowError("Date Invalide!");
            return;
        }

        const formData = frmInstance.option("formData");

        const postData = await getSubmitIesirePayload(formData);

        if (postData && postData != null) {
            ajaxHelper.post(`${generalApiRoot}/UpsertIesire`,
                postData,
                function (response) {
                    HideLoading();

                    if (!response || !response.Success) {
                        ToastShowError(response.Message);
                        return;
                    }

                    ToastShowSuccess(response.Data);

                    HidePopup(solidePopupId);
                    ReloadDataGrid(gridId);
                },
                function (err) {
                    ToastShowError(err.Message);
                    HideLoading();
                });
        }
        else {
            HideLoading();
        }
    }

    const getSubmitIntrarePayload = async function (formData) {
        const payload = {
            GenerareBonConsum: false,
            Id: tranzactiiProduseModule.getTranzactProductBaseId(),
            UnitatiId: formData.UnitatiId,
            PlanAchizitieDetId: formData.PlanAchizitieDetId,
            DataDocumentIesire: formData.DataDocumentIesire ? moment(formData.DataDocumentIesire).format("YYYY-MM-DD") : null,
            GestiuneIdDest: formData.GestiuneIdDest,
            ParteneriIdPrimitor: formData.ParteneriIdPrimitor,
            ParteneriIdFurnizor: formData.ParteneriIdFurnizor,
            ContractBaseId: formData.ContractBaseId ?? null,
            SursaFinantareId: formData.SursaFinantareId,
            UmidBaza: formData.UmidBaza,
            UmidEchivalent: formData.UmidEchivalent,
            NumarCantar: formData.NumarCantar ?? null,
            ModalitateDeterminareCalitate: formData.ModalitateDeterminareCalitate ?? null,
            ModalitateDeterminareCantitate: formData.ModalitateDeterminareCantitate ?? null,
            Expeditor: formData.Expeditor ?? null,
            Caraus: formData.Caraus ?? null,
            Insotitor: formData.Insotitor ?? null,
            DenumireStatieDestinatie: formData.DenumireStatieDestinatie ?? null,
            CodStatieDestinatie: formData.CodStatieDestinatie ?? null,
            DenumireStatieExpeditie: formData.DenumireStatieExpeditie ?? null,
            CodStatieExpeditie: formData.CodStatieExpeditie ?? null,
            DataExpediere: formData.DataExpediere ? moment(formData.DataExpediere).format("YYYY-MM-DD") : null,
            DataSosire: formData.DataSosire ? moment(formData.DataSosire).format("YYYY-MM-DD") : null,
            DataIntrare: formData.DataIntrare ? moment(formData.DataIntrare).format("YYYY-MM-DD") : null,
            ConcluziiDiferenteConstate: formData.ConcluziiDiferenteConstate ?? null,
            NumarStiva: formData.NumarStiva ?? null,
            NumarFisaMagazie: formData.NumarFisaMagazie ?? null,
            GestiuniTipLocDepozitareId: formData.GestiuniTipLocDepozitareId,
            ComisieBaseIdGestionar: formData.ComisieBaseIdGestionar,
            ComisieBaseIdReceptie: formData.ComisieBaseIdReceptie,
            DocumentIdCorespondentNavigation: null,
            DocumentIdPrimarNavigation: {
                UnitatiId: formData.UnitatiId,
                Id: formData.DocumentIdPrimar ?? 0,
                Nr: formData.NumarDocument ?? '',
                TipDocumentId: formData.TipDocumentIdPrimar ?? 0,
                DataDocument: formData.DataDocument ? moment(formData.DataDocument).format("YYYY-MM-DD") : null,
            },
            NotaGreutate: null,
            Constatari: formData.Constatari ?? null,
            VagonAutoNr: formData.VagonAutoNr ?? null,
            Delegat: formData.Delegat ?? null,
            AlteMentiuni: formData.AlteMentiuni ?? null,
            ConcluziiComisieReceptie: formData.ConcluziiComisieReceptie ?? null,
            PunctVedereDelegat: formData.PunctVedereDelegat ?? null,
            NumarProba: formData.NumarProba ?? null
        };

        // Handle CodTipOperatiune
        payload.CodTipOperatiune = formData.CodOperatiune && formData.CodOperatiune !== '' ? formData.CodOperatiune : 'SIn';

        // Handle DocumentIdCorespondentNavigation if valid
        if (formData.DataDocumentCorespondent && moment(formData.DataDocumentCorespondent).isValid()) {
            payload.DocumentIdCorespondentNavigation = {
                UnitatiId: formData.UnitatiId,
                Id: formData.DocumentIdCorespondent ?? 0,
                Nr: formData.NumarDocumentCorespondent ?? '',
                TipDocumentId: formData.TipDocumentIdCorespondent ?? 0,
                DataDocument: formData.DataDocumentCorespondent ? moment(formData.DataDocumentCorespondent).format("YYYY-MM-DD") : null,
            };
        }


        const gridDefecteNrcd = $("#grid-defecte-nrcd").dxDataGrid('instance');
        if (gridDefecteNrcd !== undefined) {
            const items = gridDefecteNrcd.getVisibleRows().filter(x => !x.removed && x.data).map(x => x.data);

            const itemsToAdd = [];
            for (let i = 0; i < items.length; i++) {

                const itemRow = items[i];
                var currentId = getValue(itemRow, 'Id');
                if (currentId === null)
                    currentId = 0;
                const item = {
                    Id: currentId,
                    TranzactProduseBaseId: tranzactiiProduseModule.getTranzactProductBaseId(),
                    NrCrt: itemRow.NrCrt,
                    ProdusIdDefect: itemRow.ProdusIdDefect,
                    Cantitate: itemRow.Cantitate
                };
                itemsToAdd.push(item);
            }
            payload.TranzactProduseBaseDefecteNrcdModels = itemsToAdd;
        }
        else {
            payload.TranzactProduseBaseDefecteNrcdModels = null;
        }

        const gridDelegatiNrcd = $("#grid-delegati-nrcd").dxDataGrid('instance');
        if (gridDelegatiNrcd !== undefined) {
            const items = gridDelegatiNrcd.getVisibleRows().filter(x => !x.removed && x.data).map(x => x.data);

            const itemsToAdd = [];
            for (let i = 0; i < items.length; i++) {

                const itemRow = items[i];
                var currentId = getValue(itemRow, 'Id');
                if (currentId === null)
                    currentId = 0;
                const item = {
                    Id: currentId,
                    TranzactProduseBaseId: tranzactiiProduseModule.getTranzactProductBaseId(),
                    NrCrt: itemRow.NrCrt,
                    NumePrenume: itemRow.NumePrenume,
                    Calitate: itemRow.Calitate,
                    DinParteCui: itemRow.DinParteCui,
                    NrDelegatie: itemRow.NrDelegatie,
                    CarteIdentite: itemRow.CarteIdentite,
                    Adresa: itemRow.Adresa
                };
                itemsToAdd.push(item);
            }
            payload.TranzactProduseBaseDelegatiNrcdModels = itemsToAdd;
        }
        else {
            payload.TranzactProduseBaseDelegatiNrcdModels = null;
        }

        const docLinkTranzactGrid = $("#docLinkTranzactGrid").dxDataGrid('instance');
        if (docLinkTranzactGrid !== undefined) {
            const items = docLinkTranzactGrid.getVisibleRows().filter(x => !x.removed && x.data).map(x => x.data);

            const itemsToAdd = [];
            for (let i = 0; i < items.length; i++) {

                var itemRow = items[i];

                var currentId = getValue(itemRow, 'Id');
                if (currentId === null)
                    currentId = 0;
                const item = {
                    Id: currentId,
                    TranzactProduseBaseId: tranzactiiProduseModule.getTranzactProductBaseId(),
                    Denumire: itemRow.Denumire,
                    DataDoc: moment(itemRow.DataDoc).format("YYYY-MM-DD"),
                    Identifier: itemRow.Identifier,
                    DocLink: itemRow.DocLink
                };
                itemsToAdd.push(item);
            }
            payload.DocLinkTranzactProdusModels = itemsToAdd;
        }
        else {
            payload.DocLinkTranzactProdusModels = null;
        }
        const gridTranzactDet = $("#grid-tranzact-prod-details").dxDataGrid('instance');
        if (gridTranzactDet !== undefined) {
            const items = gridTranzactDet.getVisibleRows().filter(x => !x.removed && x.data).map(x => x.data);

            const itemsToAdd = [];
            for (let i = 0; i < items.length; i++) {

                var itemRow = items[i];

                var currentId = getValue(itemRow, 'Id');
                if (currentId === null)
                    currentId = 0;
                const item = {
                    Id: currentId,
                    TranzactProduseBaseId: tranzactiiProduseModule.getTranzactProductBaseId(),
                    Ordine: itemRow.Ordine,
                    ProdusId: itemRow.ProdusId,
                    TipProdus: itemRow.TipProdus,
                    LotProdus: itemRow.LotProdus,
                    VagonAutoNr: itemRow.VagonAutoNr,
                    AvizExpNr: itemRow.AvizExpNr,
                    CantDocBrut: itemRow.CantDocBrut,
                    CantDocTara: itemRow.CantDocTara,
                    CantDocNet: itemRow.CantDocNet,
                    UmidDocEchiv: itemRow.UmidDocEchiv,
                    CantConstBrut: itemRow.CantConstBrut,
                    CantConstTara: itemRow.CantConstTara,
                    CantConstNet: itemRow.CantConstNet,
                    UmidConstEchiv: itemRow.UmidConstEchiv,
                    CantDifBrut: itemRow.CantDifBrut,
                    CantDifTara: itemRow.CantDifTara,
                    CantDifNet: itemRow.CantDifNet,
                    UmIdDifEchiv: itemRow.UmIdDifEchiv,
                    PretUnitar: itemRow.PretUnitar,
                    ValoareTotala: itemRow.ValoareTotala,
                    GestiuneIdDest: formData.GestiuneIdDest,
                    VolumLitri: itemRow.VolumLitri,
                    GestiuneIdSursa: 0,
                    AmbalajNr: itemRow.AmbalajNr,
                    AnProductieRecolta: itemRow.AnProductieRecolta
                };
                itemsToAdd.push(item);
            }
            payload.TranzactProduseDetModels = itemsToAdd;
        }
        else {
            payload.TranzactProduseDetModels = null;
        }

        if (newFiles !== null && newFiles.length > 0) {
            const filesToAdd = await Promise.all(newFiles.map(async (itemRow) => {
                const fileExtension = itemRow.File.name.split('.').pop();
                const fileType = getMimeTypeByExtension(fileExtension) || itemRow.File.type;

                return {
                    Identifier: itemRow.Identifier,
                    ExistingId: itemRow.ExistingId,
                    AddedFile: {
                        FileName: itemRow.File.name,
                        FileContent: await toBase64(itemRow.File),
                        FileType: fileType.split(':')[1].split(';')[0]
                    }
                };
            }));
            payload.TranzactProdusFiles = filesToAdd;
        }

        console.log(payload);
        return payload;
    }

    const getSubmitIesirePayload = async function (formData) {
        var payload = {
            Id: tranzactiiProduseModule.getTranzactProductBaseId(),
            UnitatiId: formData.UnitatiId,
            PlanAchizitieDetId: formData.PlanAchizitieDetId,
            GestiuneIdSursa: formData.GestiuneIdSursa,
            ParteneriIdPrimitor: formData.ParteneriIdPrimitor,
            ContractBaseId: formData.ContractBaseId,
            Delegat: formData.Delegat,
            VagonAutoNr: formData.VagonAutoNr,
            ContractBaseId: formData.ContractBaseId,
            AlteMentiuni: formData.AlteMentiuni,
            GestiuniTipLocDepozitareId: formData.GestiuniTipLocDepozitareId,
            SursaFinantareId: formData.SursaFinantareId,
            DocumentIdPrimarNavigation: {
                UnitatiId: formData.UnitatiId,
                Id: formData.DocumentIdPrimar,
                Nr: formData.NumarDocument,
                Serie: formData.SerieDocument,
                TipDocumentId: formData.TipDocumentIdPrimar,
                DataDocument: formData.DataDocument ? moment(formData.DataDocument).format("YYYY-MM-DD") : null,
            },
            FormulareId: formData.FormulareId ?? null
        };

        if (formData.CodOperatiune && formData.CodOperatiune !== '') {
            payload.CodTipOperatiune = formData.CodOperatiune
        }
        else {
            payload.CodTipOperatiune = 'SIe';
        }

        const docLinkTranzactGrid = $("#docLinkTranzactGrid").dxDataGrid('instance');
        if (docLinkTranzactGrid !== undefined) {
            const items = docLinkTranzactGrid.getVisibleRows().filter(x => !x.removed && x.data).map(x => x.data);

            const itemsToAdd = [];
            for (let i = 0; i < items.length; i++) {

                var itemRow = items[i];

                var currentId = getValue(itemRow, 'Id');
                if (currentId === null)
                    currentId = 0;
                const item = {
                    Id: currentId,
                    TranzactProduseBaseId: tranzactiiProduseModule.getTranzactProductBaseId(),
                    Denumire: itemRow.Denumire,
                    DataDoc: moment(itemRow.DataDoc).format("YYYY-MM-DD"),
                    Identifier: itemRow.Identifier,
                    DocLink: itemRow.DocLink
                };
                itemsToAdd.push(item);
            }
            payload.DocLinkTranzactProdusModels = itemsToAdd;
        }
        else {
            payload.DocLinkTranzactProdusModels = null;
        }
        const gridTranzactDet = $("#grid-tranzact-prod-det").dxDataGrid('instance');
        if (gridTranzactDet !== undefined) {
            const items = gridTranzactDet.getVisibleRows().filter(x => !x.removed && x.data).map(x => x.data);
            const changes = gridTranzactDet.option("editing.changes") || [];
            const itemsToAdd = [];
            for (let i = 0; i < items.length; i++) {

                var itemRow = items[i];

                payload.UmidBaza = itemRow.UmIdBaza;

                var currentId = getValue(itemRow, 'Id');
                if (currentId === null)
                    currentId = 0;
                const item = {
                    Id: currentId,
                    TranzactProduseBaseId: tranzactiiProduseModule.getTranzactProductBaseId(),
                    Ordine: itemRow.Ordine,
                    ProdusId: itemRow.ProdusId,
                    CantConstNet: itemRow.CantConstNet,
                    PretUnitar: itemRow.PretUnitar,
                    PretUnitarVanzare: itemRow.PretUnitarVanzare,
                    ValoareTotalaVanzare: itemRow.ValoareTotalaVanzare,
                    GestiuneIdSursa: formData.GestiuneIdSursa,
                    VolumLitri: itemRow.VolumLitri,
                    GestiuneIdDest: 0
                };
                itemsToAdd.push(item);
            }
            payload.TranzactProduseDetModels = itemsToAdd;
        }
        else {
            payload.TranzactProduseDetModels = null;
        }

        if (newFiles !== null && newFiles.length > 0) {
            const filesToAdd = await Promise.all(newFiles.map(async (itemRow) => {
                const fileExtension = itemRow.File.name.split('.').pop();
                const fileType = getMimeTypeByExtension(fileExtension) || itemRow.File.type;

                return {
                    Identifier: itemRow.Identifier,
                    ExistingId: itemRow.ExistingId,
                    AddedFile: {
                        FileName: itemRow.File.name,
                        FileContent: await toBase64(itemRow.File),
                        FileType: fileType.split(':')[1].split(';')[0]
                    }
                };
            }));
            payload.TranzactProdusFiles = filesToAdd;
        }

        return payload;
    }

    const toBase64 = file => new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => resolve(reader.result.split(',')[1]);
        reader.onerror = error => reject(error);
    });

    const onEdit = function (item) {
        onClearInfo();
        var formId = '';
        isReadOnly = true;
        if (item.data.CodOperatiune === 'SIe') {
            solidePopupId = '#upsert-iesire-solide-popup';
            solideDetPopupId = '#upsert-iesire-det-solide-popup';
            title = 'Iesire produse solide - Actualizare';
            formId = '#form-iesire-solide';
            formDetId = '#form-iesire-det-solide';
        } else if (item.data.CodOperatiune === 'SIn') {
            solidePopupId = '#upsert-intrare-solide-popup';
            solideDetPopupId = '#upsert-intrare-det-solide-popup';
            title = 'Intrare produse solide - Actualizare';
            formId = '#form-intrare-solide';
            formDetId = '#form-intrare-det-solide';
        }

        var popup = $(solidePopupId).dxPopup("instance");
        if (popup != undefined) {
            popup.option("title", title);
        }
        ShowLoading();
        tranzactiiProduseModule.setTranzactProductBaseId(item.data.Id);
        getData(item.data.Id, formId);
        item.cancel = true;
    }

    const getData = function (id, formId) {

        if (!id || id < 1) {
            ToastShowError("Id invalid!")
            return;
        }

        ajaxHelper.get(`${generalApiRoot}/GetTranzactProdusDetailsByBase?id=${id}`, null,
            function (response) {

                HideLoading();

                if (!response || !response.Success) {
                    ToastShowError(response.Message);
                    return;
                }

                ShowPopup(solidePopupId);
                var frmInstance = $(formId).dxForm("instance");
                if (frmInstance != undefined) {
                    frmInstance.option("formData", response.Data);
                    tranzactiiProduseModule.setGestiuniTipLocDepozitareId(response.Data.GestiuniTipLocDepozitareId);
                    tranzactiiProduseModule.setPlanAchizitieId(response.Data.PlanAchizitieDetId)

                    var btnIntrareSaveAll = $('#btnIntrareSaveAll').dxButton('instance');
                    if (btnIntrareSaveAll) {
                        btnIntrareSaveAll.option('disabled', !!!response.Data.CanEdit);
                    }

                    var btnIesireSaveAll = $('#btnIesireSaveAll').dxButton('instance');
                    if (btnIesireSaveAll) {
                        btnIesireSaveAll.option('disabled', !!!response.Data.CanEdit);
                    }
                    tranzactiiProduseModule.setFieldsReadOnly(isReadOnly);
                }
            },
            function (err) {
                ToastShowError("Au aparut erori la citirea datelor!");
                HideLoading();
            });
    }

    const setDepoziteDisponibileParams = function (operation, ajaxSettings) {
        if (operation === 'load') {
            ajaxSettings.data.GestiuneId = tranzactiiProduseModule.getGestiuneDestinatieId();
            ajaxSettings.data.GestiuniTipLocDepozitareId = tranzactiiProduseModule.getGestiuniTipLocDepozitareId();
            ajaxSettings.data.TipProdus = 'solid';
        }
    }

    const showReport = function (params) {
        var codOperatiune = params.row.data.CodOperatiune;
        if (codOperatiune === 'SIn') {
            return true;
        }
        else
            return false;
    }

    const onAddDocumenteScan = function (e) {
        var dataGrid = $("#docLinkTranzactGrid").dxDataGrid("instance");
        myIndex = myIndex - 1;
        docScanRowIdentifier = '';
        dataGrid.on("initNewRow", function (e) {
            e.data["Id"] = myIndex;
            docScanRowIdentifier = GenerateGuid();
            e.data["Identifier"] = docScanRowIdentifier;
        });
        dataGrid.beginUpdate();
        dataGrid.addRow();
        dataGrid.endUpdate();
        dataGrid.endCustomLoading();
    }

    const downloadFile = function (e) {
        var docLink = e.row.data.DocLink;
        if (docLink === undefined || docLink === '')
            DevExpress.ui.notify("Nu exista fisier pentru descarcare", "error", 2000);

        var fileName = docLink.split(/(\\|\/)/g).pop();
        var fileExtension = fileName.split('.').pop();

        ShowLoading();

        var body = {
            FilePath: docLink
        }
        ajaxHelper.post(`${generalApiRoot}/DownloadFile`, body,
            function (response) {
                if (!response || !response.Success) {
                    ToastShowError(response.Message);
                    HideLoading();
                    return;
                }
                const fileName = response.Data.FileName;
                const content = response.Data.FileContent;
                const fileType = response.Data.FileType;

                const byteCharacters = atob(content);
                const byteNumbers = new Array(byteCharacters.length);
                for (let i = 0; i < byteCharacters.length; i++) {
                    byteNumbers[i] = byteCharacters.charCodeAt(i);
                }
                const byteArray = new Uint8Array(byteNumbers);

                const blob = new Blob([byteArray], { type: fileType });
                const link = document.createElement('a');
                link.href = URL.createObjectURL(blob);
                link.download = fileName;
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
                URL.revokeObjectURL(link.href);
                HideLoading();
            },
            function (err) {
                ToastShowError("Au aparut erori la citirea datelor!");
                HideLoading();
            });

    }

    const deleteFile = function (param) {
        var result = DevExpress.ui.dialog.confirm("<p>Sunteti sigur ca doriti stergerea elementului selectat?</p>", "Stergere");
        result.done(function (dialogResult) {
            deletedRowIndex = param.row.rowIndex;

            if (dialogResult) {
                var gridInstance = $('#docLinkTranzactGrid').dxDataGrid('instance');
                gridInstance.deleteRow(deletedRowIndex);
                gridInstance.element().find(".dx-row-removed").hide();
            }
        });
    }

    const onFileUploaderValueChanged = function (e) {
        const files = e.value;
        if (files.length > 0) {
            $.each(files, (i, file) => {
                var fileIndex = -1;
                if (!docScanIsNewRow) {
                    //rand existent - inlocuire fisier
                    fileIndex = newFiles.indexOfObject("ExistingId", docScanRowIdentifier);
                }
                else {
                    //rand nou
                    fileIndex = newFiles.indexOfObject("Identifier", myIndex);
                }

                var date = new Date(file.lastModified);
                var dataGrid = $("#docLinkTranzactGrid").dxDataGrid("instance");
                //console.log(date);
                if (fileIndex === -1) {
                    newFiles.push({ Identifier: myIndex, File: file, ExistingId: docScanRowIdentifier });
                }
                else {
                    newFiles[fileIndex].File = file;
                }
                dataGrid.cellValue(docScanRowIndex, "Denumire", file.name);
                dataGrid.cellValue(docScanRowIndex, "DataDoc", new Date());
            });
        }
    }

    const onFocusedRowChangeDocScan = function (e) {
        docScanRowIndex = e.rowIndex;
        docScanRowIdentifier = e.row.data.Identifier;
        docScanIsNewRow = e.row.isNewRow !== undefined;
    }

    const onPartnerChanged = function (args) {
        //console.log(args);
        var txtDenumireFurnizor = $('#txtDenumireFurnizor').dxTextBox('instance');

        if (args.component.clickedRowData !== null && args.component.clickedRowData !== undefined) {
            partenerId = args.component.clickedRowData.Id;
            txtDenumireFurnizor.option('value', args.component.clickedRowData.Denumire);
        }
        //pentru situatia in care se schimba valoarea din cod si nu de catre utilizator
        else if (args.value !== 0) {
            partenerId = args.value;
        }

        var subcontract = $("#ddlContracte").dxDropDownBox("instance");
        //resetam valoarea din ddlContracte pentru a se reface filtrarea
        subcontract.option('value', null);
    }

    const getContractParams = function (operation, ajaxSettings) {
        if (operation === 'load') {
            ajaxSettings.data.unitateId = tranzactiiProduseModule.getUnitateId();
            ajaxSettings.data.contractId = 0;
            ajaxSettings.data.partenerId = partenerId;
        }
    }

    const onProdusIdChanged = function (args) {
        if (args.component.clickedRowData !== null && args.component.clickedRowData !== undefined) {
            var frmDetInstance = $(formDetId).dxForm("instance");
            if (frmDetInstance) {
                let formData = frmDetInstance.option("formData");
                if (formDetId === '#form-intrare-det-solide') {
                    formData.Sort = args.component.clickedRowData.Sort;
                    formData.Calitate = args.component.clickedRowData.Calitate;
                }
                if (formDetId === '#form-iesire-det-solide') {
                    formData.Stoc = args.component.clickedRowData.Stoc;
                    formData.PretUnitar = args.component.clickedRowData.PretUnitar;
                    formData.PretUnitarVanzare = args.component.clickedRowData.PretUnitar;
                    formData.Key = args.component.clickedRowData.Key;
                }

                formData.DenumireProdus = args.component.clickedRowData.Denumire;
                formData.ProdusId = args.component.clickedRowData.Id;
                frmDetInstance.option("formData", formData);
            }
        }
        else {
            var dropDownBox = $("#ddlProdusDet").dxDropDownBox("instance");
            var dataSource = dropDownBox.getDataSource();

            dataSource.load().done(function (items) {
                var selectedProduct = items.find(product => product.Key === args.value);
                if (selectedProduct) {
                    var frmDetInstance = $(formDetId).dxForm("instance");
                    if (frmDetInstance) {
                        let formData = frmDetInstance.option("formData");

                        if (formDetId === '#form-intrare-det-solide') {
                            formData.Sort = selectedProduct.Sort;
                            formData.Calitate = selectedProduct.Calitate;
                        }
                        if (formDetId === '#form-iesire-det-solide') {
                            formData.Stoc = selectedProduct.Stoc;
                            formData.PretUnitar = selectedProduct.PretUnitar;
                            formData.Key = selectedProduct.Key;
                        }
                        formData.DenumireProdus = selectedProduct.Denumire;
                        formData.ProdusId = selectedProduct.Id;
                        frmDetInstance.option("formData", formData);
                    }
                }
            });
        }
    }

    var onAddActionDet = function (args) {
        editRowIndex = -1;
        var popup = $(solideDetPopupId).dxPopup("instance");
        if (popup != undefined) {
            popup.option("title", "Adaugare Detalii Tranzactie");
        }

        ShowPopup(solideDetPopupId);

    }

    const onEditDet = function (item) {
        var popup = $(solideDetPopupId).dxPopup("instance");
        if (popup != undefined) {
            popup.option("title", "Actualizare Detalii Tranzactie");
        }

        linieDetId = item.row?.data.Id;

        editRowIndex = item.row?.rowIndex;
        var clonedData = Object.assign({}, item.row?.data);
        item.event.preventDefault();

        ShowPopup(solideDetPopupId);

        if (solideDetPopupId == '#upsert-iesire-det-solide-popup') {
            var btnIesireDetSaveAll = $('#btnIesireDetSaveAll').dxButton('instance');
            var btnIesireSaveAll = $('#btnIesireSaveAll').dxButton('instance');
            if (btnIesireDetSaveAll && btnIesireSaveAll) {
                var canEdit = btnIesireSaveAll.option('disabled');
                btnIesireDetSaveAll.option('disabled', !!canEdit);
            }
        }

        if (solideDetPopupId == '#upsert-intrare-det-solide-popup') {
            var btnIntrareDetSaveAll = $('#btnIntrareDetSaveAll').dxButton('instance');
            var btnIntrareSaveAll = $('#btnIntrareSaveAll').dxButton('instance');
            if (btnIntrareDetSaveAll && btnIntrareSaveAll) {
                var canEdit = btnIntrareSaveAll.option('disabled');
                btnIntrareDetSaveAll.option('disabled', !!canEdit);
            }
        }

        var frmDetInstance = $(formDetId).dxForm("instance");
        frmDetInstance.option("formData", clonedData);
    }

    const onSaveIesiriDetSolide = function (item) {
        var formDetInstance = $(formDetId).dxForm("instance");

        if (!formDetInstance.validate().isValid) {
            ToastShowError("Date Invalide!");
            return;
        }
        let dataGrid = $('#grid-tranzact-prod-det').dxDataGrid("instance");
        let formData = formDetInstance.option("formData");

        if (formData.Stoc < formData.CantConstNet) {
            ToastShowError("Cantitatea nu poate depasi stocul!");
            var txtCantConstNet = $('#txtCantConstNet').dxNumberBox('instance');
            if (txtCantConstNet) {
                txtCantConstNet.option('isValid', false);
            }
            return;
        }

        if (editRowIndex >= 0) {
            dataGrid.cellValue(editRowIndex, "Ordine", formData.Ordine);
            dataGrid.cellValue(editRowIndex, "ProdusId", formData.ProdusId)
            dataGrid.cellValue(editRowIndex, "UmIdBaza", formData.UmIdBaza);
            dataGrid.cellValue(editRowIndex, "VolumLitri", formData.VolumLitri);
            dataGrid.cellValue(editRowIndex, "CantConstNet", formData.CantConstNet);
            dataGrid.cellValue(editRowIndex, "PretUnitar", formData.PretUnitar);
            dataGrid.cellValue(editRowIndex, "PretUnitarVanzare", formData.PretUnitarVanzare);
            dataGrid.cellValue(editRowIndex, "ValoareTotalaVanzare", formData.ValoareTotalaVanzare);
            dataGrid.cellValue(editRowIndex, "DenumireProdus", formData.DenumireProdus);
            dataGrid.cellValue(editRowIndex, "Key", formData.Key);
        } else {
            dataGrid.on("initNewRow", function (e) {
                e.data["Ordine"] = formData.Ordine;
                e.data["ProdusId"] = formData.ProdusId;
                e.data["UmIdBaza"] = formData.UmIdBaza;
                e.data["VolumLitri"] = formData.VolumLitri;
                e.data["CantConstNet"] = formData.CantConstNet;
                e.data["PretUnitar"] = formData.PretUnitar;
                e.data["PretUnitarVanzare"] = formData.PretUnitarVanzare;
                e.data["ValoareTotalaVanzare"] = formData.ValoareTotalaVanzare;
                e.data["Key"] = formData.Key;
                e.data["DenumireProdus"] = formData.DenumireProdus;
            });

            dataGrid.beginUpdate();
            dataGrid.addRow();
            dataGrid.endUpdate();
            dataGrid.endCustomLoading();
            dataGrid.off("initNewRow");
        }
        HidePopup(solideDetPopupId)
    }

    const onSaveIntrariDetSolide = function (item) {
        var formDetInstance = $(formDetId).dxForm("instance");

        if (!formDetInstance.validate().isValid) {
            ToastShowError("Date Invalide!");
            return;
        }

        let dataGrid = $('#grid-tranzact-prod-details').dxDataGrid("instance");
        let formData = formDetInstance.option("formData");

        if (formData.CantConstNet <= 0) {
            ToastShowError("Cantitate net nu poate fi 0!");
            var txtCantContNet = $('#txtCantContNet').dxNumberBox('instance');
            if (txtCantContNet) {
                txtCantContNet.option('isValid', false);
            }
            return;
        }
        if (formData.PretUnitar <= 0) {
            ToastShowError("Pret unitar nu poate fi 0!");
            var txtPretUnitar = $('#txtPretUnitar').dxNumberBox('instance');
            if (txtPretUnitar) {
                txtPretUnitar.option('isValid', false);
            }
            return;
        }

        if (editRowIndex >= 0) {
            dataGrid.cellValue(editRowIndex, "Ordine", formData.Ordine);
            dataGrid.cellValue(editRowIndex, "ProdusId", formData.ProdusId);
            dataGrid.cellValue(editRowIndex, "DenumireProdus", formData.DenumireProdus);
            dataGrid.cellValue(editRowIndex, "Sort", formData.Sort);
            dataGrid.cellValue(editRowIndex, "Calitate", formData.Calitate);
            dataGrid.cellValue(editRowIndex, "TipProdus", formData.TipProdus);
            dataGrid.cellValue(editRowIndex, "LotProdus", formData.LotProdus);
            dataGrid.cellValue(editRowIndex, "AmbalajNr", formData.AmbalajNr);
            dataGrid.cellValue(editRowIndex, "VagonAutoNr", formData.VagonAutoNr);
            dataGrid.cellValue(editRowIndex, "AvizExpNr", formData.AvizExpNr);
            dataGrid.cellValue(editRowIndex, "CantDocBrut", formData.CantDocBrut);
            dataGrid.cellValue(editRowIndex, "CantDocTara", formData.CantDocTara);
            dataGrid.cellValue(editRowIndex, "CantDocNet", formData.CantDocNet);
            dataGrid.cellValue(editRowIndex, "UmidDocEchiv", formData.UmidDocEchiv);
            dataGrid.cellValue(editRowIndex, "CantConstBrut", formData.CantConstBrut);
            dataGrid.cellValue(editRowIndex, "CantConstTara", formData.CantConstTara);
            dataGrid.cellValue(editRowIndex, "CantConstNet", formData.CantConstNet);
            dataGrid.cellValue(editRowIndex, "UmidConstEchiv", formData.UmidConstEchiv);
            dataGrid.cellValue(editRowIndex, "CantDifBrut", formData.CantDifBrut);
            dataGrid.cellValue(editRowIndex, "CantDifTara", formData.CantDifTara);
            dataGrid.cellValue(editRowIndex, "CantDifNet", formData.CantDifNet);
            dataGrid.cellValue(editRowIndex, "UmIdDifEchiv", formData.UmIdDifEchiv);
            dataGrid.cellValue(editRowIndex, "PretUnitar", formData.PretUnitar);
            dataGrid.cellValue(editRowIndex, "ValoareTotala", formData.ValoareTotala);
            dataGrid.cellValue(editRowIndex, "VolumLitri", formData.VolumLitri);
            dataGrid.cellValue(editRowIndex, "AnProductieRecolta", formData.AnProductieRecolta);
        } else {
            dataGrid.on("initNewRow", function (e) {
                e.data["Ordine"] = formData.Ordine;
                e.data["ProdusId"] = formData.ProdusId;
                e.data["DenumireProdus"] = formData.DenumireProdus;
                e.data["Sort"] = formData.Sort;
                e.data["Calitate"] = formData.Calitate;
                e.data["TipProdus"] = formData.TipProdus;
                e.data["LotProdus"] = formData.LotProdus;
                e.data["AmbalajNr"] = formData.AmbalajNr;
                e.data["VagonAutoNr"] = formData.VagonAutoNr;
                e.data["AvizExpNr"] = formData.AvizExpNr;
                e.data["CantDocBrut"] = formData.CantDocBrut;
                e.data["CantDocTara"] = formData.CantDocTara;
                e.data["CantDocNet"] = formData.CantDocNet;
                e.data["UmidDocEchiv"] = formData.UmidDocEchiv;
                e.data["CantConstBrut"] = formData.CantConstBrut;
                e.data["CantConstTara"] = formData.CantConstTara;
                e.data["CantConstNet"] = formData.CantConstNet;
                e.data["UmidConstEchiv"] = formData.UmidConstEchiv;
                e.data["CantDifBrut"] = formData.CantDifBrut;
                e.data["CantDifTara"] = formData.CantDifTara;
                e.data["CantDifNet"] = formData.CantDifNet;
                e.data["UmIdDifEchiv"] = formData.UmIdDifEchiv;
                e.data["PretUnitar"] = formData.PretUnitar;
                e.data["ValoareTotala"] = formData.ValoareTotala;
                e.data["VolumLitri"] = formData.VolumLitri;
                e.data["AnProductieRecolta"] = formData.AnProductieRecolta;
            });

            dataGrid.beginUpdate();
            dataGrid.addRow();
            dataGrid.endUpdate();
            dataGrid.endCustomLoading();
            dataGrid.off("initNewRow");
        }
        HidePopup(solideDetPopupId)
    }

    const setReadOnly = function () {
        return !!isReadOnly;
    }

    return {
        onResetGrid: onResetGrid,
        onCancel: onCancel,
        onHidingPopup: onHidingPopup,
        onAddSolide: onAddSolide,
        onClearInfo: onClearInfo,
        onSaveIntrariSolide: onSaveIntrariSolide,
        onEdit: onEdit,
        onSaveIesiriSolide: onSaveIesiriSolide,
        setDepoziteDisponibileParams: setDepoziteDisponibileParams,
        showReport: showReport,
        getContractParams: getContractParams,
        onPartnerChanged: onPartnerChanged,
        onFocusedRowChangeDocScan: onFocusedRowChangeDocScan,
        onFileUploaderValueChanged: onFileUploaderValueChanged,
        deleteFile: deleteFile,
        downloadFile: downloadFile,
        onAddDocumenteScan: onAddDocumenteScan,
        onEditDet: onEditDet,
        onHidingIntrariDetPopup: onHidingIntrariDetPopup,
        onHidingIesiriDetPopup: onHidingIesiriDetPopup,
        onCancelDet: onCancelDet,
        onSaveIntrariDetSolide: onSaveIntrariDetSolide,
        onAddActionDet: onAddActionDet,
        onProdusIdChanged: onProdusIdChanged,
        onSaveIesiriDetSolide: onSaveIesiriDetSolide,
        setReadOnly: setReadOnly
    };
})();