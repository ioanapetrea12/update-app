﻿const tranzactiiProduseModule = (function () {

    var apiRoot = '/Produse/TranzactiiProduse';

    var comisieReceptieId = 0;
    var comisieGestiuneId = 0;
    var unitateId = '00000000-0000-0000-0000-000000000000';
    var planAchizitieDetId = 0;
    var tranzactProductBaseId = 0;
    var gestiuneDestinatieId = 0;
    var gestiuniTipLocDepozitareId = 0;
    var selectedIds = [];
    var dataNrcd = new Date();

    const onDisableCell = function (e) {
        if (e.rowType === "data" && !e.column.allowEditing) {
            e.cellElement.css('backgroundColor', 'lightgray'); // Light gray background
        }
    }

    const onComisieReceptieChanged = function (args) {
        if (args.component.clickedRowData !== null && args.component.clickedRowData !== undefined) {
            comisieReceptieId = args.component.clickedRowData.Id;
        } else if (args.value !== 0) {
            comisieReceptieId = args.value;
        }
        ReloadDataGrid('#inner-grid-receptie');
    }

    const onComisieGestiuneChanged = function (args) {
        if (args.component.clickedRowData !== null && args.component.clickedRowData !== undefined) {
            comisieGestiuneId = args.component.clickedRowData.Id;
        } else if (args.value !== 0) {
            comisieGestiuneId = args.value;
        }
        ReloadDataGrid('#inner-grid-gestionar');
    }

    const onSetComisieReceptie = function (operation, ajaxSettings) {
        ajaxSettings.data.comisieId = comisieReceptieId;
        ajaxSettings.data.UnitateId = unitateId;
        ajaxSettings.data.DataDocument = dataNrcd;
    }

    const onSetComisieGestiune = function (operation, ajaxSettings) {
        ajaxSettings.data.comisieId = comisieGestiuneId;
        ajaxSettings.data.UnitateId = unitateId;
        ajaxSettings.data.DataDocument = dataNrcd;
    }

    const onContractOpen = function (e) {
        e.component.getDataSource().load().then(function (data) {
            ReloadDataGrid("#ComboContracteGrid");
        })
    }

    const onDepoziteOpen = function (e) {
        e.component.getDataSource().load().then(function (data) {
            ReloadDataGrid("#ComboDepoziteDisponibile");
        })
    }

    const onAddDetLine = function (gridId) {
        var dataGrid = $(gridId).dxDataGrid("instance");
        dataGrid.on("initNewRow", function (e) {
            e.data["VolumLitri"] = 0;
        });

        dataGrid.beginUpdate();
        dataGrid.addRow();
        dataGrid.endUpdate();
        dataGrid.endCustomLoading();
    }

    const onAddDefecteLine = function () {
        var dataGrid = $("#grid-defecte-nrcd").dxDataGrid("instance");
        dataGrid.beginUpdate();
        dataGrid.addRow();
        dataGrid.endUpdate();
        dataGrid.endCustomLoading();
    }

    const onAddDelegatiLine = function () {
        var dataGrid = $("#grid-delegati-nrcd").dxDataGrid("instance");
        dataGrid.beginUpdate();
        dataGrid.addRow();
        dataGrid.endUpdate();
        dataGrid.endCustomLoading();
    }

    const onAddDiferenteLine = function () {
        var dataGrid = $("#grid-diferente-nrcd").dxDataGrid("instance");
        dataGrid.beginUpdate();
        dataGrid.addRow();
        dataGrid.endUpdate();
        dataGrid.endCustomLoading();
    }

    const onDelete = function (item, gridId) {
        var result = DevExpress.ui.dialog.confirm("<p>Sunteti sigur/a ca doriti stergerea linie selectate ?</p>", "Stergere");
        result.done(function (dialogResult) {
            if (dialogResult) {
                var postData = {
                    Id: item.row.key
                };
                ajaxHelper.post(`${apiRoot}/Delete`, postData,
                    function (response) {
                        HideLoading();
                        if (response) {
                            if (response.Success == false) {
                                ToastShowError(response.Message);
                                return;
                            }

                            ToastShowSuccess(response.Data);

                            ReloadDataGrid(gridId);
                        } else {
                            ToastShowError("A apărut o eroare la ștergerea intrărilor");
                        }
                    },
                    function (err) {
                        ToastShowError("An error occured");
                        HideLoading();
                    });
            }
        })
    }

    const onDeleteBatchRow = function (param, grid) {
        var result = DevExpress.ui.dialog.confirm("<p>Sunteti sigur ca doriti stergerea elementului selectat?</p>", "Stergere");
        result.done(function (dialogResult) {
            deletedRowIndex = param.row.rowIndex;

            if (dialogResult) {
                if (IsDataGridInstance(grid)) {
                    var gridInstance = $(grid).dxDataGrid('instance');
                    gridInstance.deleteRow(deletedRowIndex);
                    gridInstance.element().find(".dx-row-removed").hide();
                }
            }
        });
    }

    const onPrintRaport = function (e) {
        var codRaport = e.row.data.CodInternRaport;
        var tranzactBaseId = e.row.data.Id;
        ShowLoading();
        ajaxHelper.get(`/Administrare/Raport/GetTranzactiiLinkRaport?tranzactProdusBaseId=${tranzactBaseId}&codInternRaport=${codRaport}`, null,
            function (response) {
                if (!response || !response.Success) {
                    ToastShowError(response.Message);
                    return;
                }

                window.open(response.Data, '_blank');
                HideLoading();
            },
            function (error) {

            });
        HideLoading();
    }

    const onGeneratePvrd = function (e) {
        var codRaport = e.row.data.CodRaportPVRD;
        var tranzactBaseId = e.row.data.Id;
        ShowLoading();
        ajaxHelper.get(`/Administrare/Raport/GetTranzactiiLinkRaport?tranzactProdusBaseId=${tranzactBaseId}&codInternRaport=${codRaport}`, null,
            function (response) {
                if (!response || !response.Success) {
                    ToastShowError(response.Message);
                    return;
                }

                window.open(response.Data, '_blank');
                HideLoading();
            },
            function (error) {

            });
        HideLoading();
    }

    const setUnitateParam = function (operation, ajaxSettings) {
        if (operation === "load") {
            ajaxSettings.data.UnitateId = unitateId;
        }
    }

    const setOrdinLivrareParam = function (operation, ajaxSettings) {
        if (operation === "load") {
            ajaxSettings.data.UnitateId = unitateId;
            ajaxSettings.data.PlanAchizitieDetId = planAchizitieDetId;
        }
    }


    const onUnitatiChanged = function (args) {
        if (args.component.clickedRowData !== null && args.component.clickedRowData !== undefined) {
            unitateId = args.component.clickedRowData.Id;
        } else if (args.value !== 0) {
            unitateId = args.value;
        }
        var planAchizitieDet = $("#ddlPlanAchizitieDet").dxDropDownBox("instance");
        if (planAchizitieDet)
            planAchizitieDet.option('value', null);
        var gestiuni = $("#ddlGestiuni").dxDropDownBox("instance");
        if (gestiuni)
            gestiuni.option('value', null);
        var comisieReceptie = $("#ddlComisieReceptie").dxDropDownBox("instance");
        if (comisieReceptie) {
            comisieReceptie.option('value', null);
            comisieReceptieId = 0;
            ReloadDataGrid("#inner-grid-receptie");
        }
        var comisieGestiune = $("#ddlComisieGestiune").dxDropDownBox("instance");
        if (comisieGestiune) {
            comisieGestiune.option('value', null);
            comisieGestiuneId = 0;
            ReloadDataGrid("#inner-grid-gestionar");
        }
        var ddlForms = $("#ddlForms").dxDropDownBox("instance");
        if (ddlForms) {
            ddlForms.option('value', null);
        }
    }

    const onPlanAchizitieOpen = function (e) {
        e.component.getDataSource().load().then(function (data) {
            ReloadDataGrid("#ComboPlanAchizitieDetGrid");
        })

    }

    const onGestiuniOpen = function (e) {
        e.component.getDataSource().load().then(function (data) {
            ReloadDataGrid("#ComboTipuriGestiuneGrid");
        })
    }

    const onComisieReceptieOpen = function (e) {
        e.component.getDataSource().load().then(function (data) {
            ReloadDataGrid("#ComboComisiePersonalGrid");
        })

    }

    const onComisieGestiuneOpen = function (e) {
        e.component.getDataSource().load().then(function (data) {
            ReloadDataGrid("#ComisieGrid");
        })

    }

    const getUnitateId = function () {
        return unitateId;
    }

    const onEditingStart = function (e) {
        e.cancel = true;
    }

    const onCalendarOpened = async function (e) {
        try {
            const response = await getCallWithPromise(`/Nomenclatoare/BlocareLuna/GetDataBlocanta?unitatiId=${unitateId}`);

            if (response != null) {
                let minDate = new Date(response.Data.DataBlocareFull);
                e.component.option("min", minDate);
            }
        }
        catch {
            e.component.option("min", null);
        }
    }

    function getCallWithPromise(url) {
        return new Promise((resolve, reject) => {
            ajaxHelper.get(url, null,
                function (response) {
                    // Resolve the promise with the response data
                    if (!response || !response.Success) {
                        reject(response.Message || "Unknown error");
                    } else {
                        resolve(response);
                    }
                },
                function (err) {
                    // Reject the promise with an error message
                    reject("Au aparut erori la citirea datelor!");
                }
            );
        });
    }

    const onPlanChanged = function (args) {
        if (args.component.clickedRowData !== null && args.component.clickedRowData !== undefined) {
            planAchizitieDetId = args.component.clickedRowData.Id;
            var codProdus = args.component.clickedRowData.CodProdus;
            var txtCodProdus = $('#txtCodProdus').dxTextBox('instance');
            if (txtCodProdus)
                txtCodProdus.option('value', codProdus);
        }
        else if (args.value !== 0) {
            planAchizitieDetId = args.value;
        }
    }

    const onGestiuneChanged = function (args) {
        if (args.component.clickedRowData !== null && args.component.clickedRowData !== undefined) {
            gestiuneDestinatieId = args.component.clickedRowData.Id;
        } else if (args.value !== 0) {
            gestiuneDestinatieId = args.value;
        }

        var ddlDepozitatIn = $('#ddlDepozitatIn').dxDropDownBox('instance');
        ddlDepozitatIn.option('value', null);
    }

    const resetUnitateId = function () {
        unitateId = '00000000-0000-0000-0000-000000000000';
    }

    const setPlanAchizitieId = function (value) {
        planAchizitieDetId = value;
    }

    const setTranzactProductBaseId = function (value) {
        tranzactProductBaseId = value;
    }

    const getTranzactProductBaseId = function () {
        return tranzactProductBaseId;
    }

    const setGestiuneDestinatieId = function (value) {
        gestiuneDestinatieId = value;
    }

    const getGestiuneDestinatieId = function () {
        return gestiuneDestinatieId;
    }

    const setPlanAchizitieParam = function (operation, ajaxSettings) {
        if (operation === "load") {
            ajaxSettings.data.PlanAchizitieDetId = planAchizitieDetId;
        }
    }

    const getGestiuniTipLocDepozitareId = function () {
        return gestiuniTipLocDepozitareId;
    }

    const setGestiuniTipLocDepozitareId = function (value) {
        gestiuniTipLocDepozitareId = value;
    }

    const setProductsStockParam = function (operation, ajaxSettings) {
        if (operation === "load") {
            ajaxSettings.data.PlanAchizitieDetId = planAchizitieDetId;
            ajaxSettings.data.TranzactProduseBaseId = tranzactProductBaseId;
            ajaxSettings.data.GestiuniTipLocDepozitareId = gestiuniTipLocDepozitareId;
        }
    }

    const onSetTranzactProdusBaseId = function (operation, ajaxSettings) {
        if (operation === "load") {
            ajaxSettings.data.tranzactProductBaseId = tranzactProductBaseId;
        }
    }

    const setComisieFilterParam = function (operation, ajaxSettings) {
        if (operation === "load") {
            ajaxSettings.data.GestiuneId = gestiuneDestinatieId;
            ajaxSettings.data.UnitateId = unitateId;
        }
    }

    const setComisieReceptieId = function (value) {
        comisieReceptieId = value;
    }

    const setComisieGestiuneId = function (value) {
        comisieGestiuneId = value;
    }

    const onDepoziteValueChanged = function (args) {
        if (args.component.clickedRowData !== null && args.component.clickedRowData !== undefined) {
            gestiuniTipLocDepozitareId = args.component.clickedRowData.Id;
        }
        else if (args.value !== 0) {
            gestiuniTipLocDepozitareId = args.value;
        }
    }

    const getSelectedProductIds = function () {
        if (IsDataGridInstance('#grid-tranzact-prod-details')) {
            var grid = $('#grid-tranzact-prod-details').dxDataGrid('instance');
            var items = grid.getVisibleRows().filter(x => !x.removed && x.data).map(x => x.data.ProdusId);
            selectedIds = items.join(',');
        }
        return selectedIds;
    }

    const setSelectedProdId = function (value) {
        selectedIds = value;
    }

    const setFieldsReadOnly = function (isReadOnly) {
        var dropDownUnitatiInstance = $('#ddlUnitateId').dxDropDownBox('instance');

        if (dropDownUnitatiInstance) {
            dropDownUnitatiInstance.option('readOnly', isReadOnly);
        }

        var dropDownPlanInstance = $('#ddlPlanAchizitieDet').dxDropDownBox('instance');

        if (dropDownPlanInstance) {
            dropDownPlanInstance.option('readOnly', isReadOnly);
        }


        var dropDownGestiuniInstance = $('#ddlGestiuni').dxDropDownBox('instance');

        if (dropDownGestiuniInstance) {
            dropDownGestiuniInstance.option('readOnly', isReadOnly);
        }

        var textBoxNrDocInstance = $('#txtNrDocument').dxTextBox('instance');

        if (textBoxNrDocInstance) {
            textBoxNrDocInstance.option('readOnly', isReadOnly);
        }

        var dateBoxDataDocInstance = $('#txtDataDocument').dxDateBox('instance');

        if (dateBoxDataDocInstance) {
            dateBoxDataDocInstance.option('readOnly', isReadOnly);
        }

        var txtSerieDocInstance = $('#txtSerieDoc').dxTextBox('instance');

        if (txtSerieDocInstance) {
            txtSerieDocInstance.option('readOnly', isReadOnly);
        }

        var dropDownSursaFinantareInstance = $('#ddlSursaFinantare').dxDropDownBox('instance');

        if (dropDownSursaFinantareInstance) {
            dropDownSursaFinantareInstance.option('readOnly', isReadOnly);
        }

        var dropDownTipDocumentInstance = $('#ddlTipDocument').dxDropDownBox('instance');

        if (dropDownTipDocumentInstance) {
            dropDownTipDocumentInstance.option('readOnly', isReadOnly);
        }

        var txtNrDocCorespondentInstance = $('#txtNrDocCorespondent').dxTextBox('instance');

        if (txtNrDocCorespondentInstance) {
            txtNrDocCorespondentInstance.option('readOnly', isReadOnly);
        }

        var txtSerieDocCorespondentInstance = $('#txtSerieDocCorespondent').dxTextBox('instance');

        if (txtSerieDocCorespondentInstance) {
            txtSerieDocCorespondentInstance.option('readOnly', isReadOnly);
        }

        var txtDataDocCorespondentInstance = $('#txtDataDocCorespondent').dxDateBox('instance');

        if (txtDataDocCorespondentInstance) {
            txtDataDocCorespondentInstance.option('readOnly', isReadOnly);
        }

        var ddlFurnizorInstance = $('#ddlFurnizor').dxDropDownBox('instance');

        if (ddlFurnizorInstance) {
            ddlFurnizorInstance.option('readOnly', isReadOnly);
        }

        var ddlContracteInstance = $('#ddlContracte').dxDropDownBox('instance');

        if (ddlContracteInstance) {
            ddlContracteInstance.option('readOnly', isReadOnly);
        }

        var ddlPrimitorInstance = $('#ddlPrimitor').dxDropDownBox('instance');

        if (ddlPrimitorInstance) {
            ddlPrimitorInstance.option('readOnly', isReadOnly);
        }

        var ddlUmBazaInstance = $('#ddlUmBaza').dxDropDownBox('instance');

        if (ddlUmBazaInstance) {
            ddlUmBazaInstance.option('readOnly', isReadOnly);
        }

        var ddlUmEchivInstance = $('#ddlUmEchiv').dxDropDownBox('instance');

        if (ddlUmEchivInstance) {
            ddlUmEchivInstance.option('readOnly', isReadOnly);
        }

        var txtNotaGreutateInstance = $('#txtNotaGreutate').dxTextBox('instance');
        if (txtNotaGreutateInstance) {
            txtNotaGreutateInstance.option('readonly', isReadOnly);
        }

        var txtVagonAutoInstance = $('#txtVagonAuto').dxTextBox('instance');
        if (txtVagonAutoInstance) {
            txtVagonAutoInstance.option('readonly', isReadOnly);
        }

        var txtDelegatInstance = $('#txtDelegat').dxTextBox('instance');
        if (txtDelegatInstance) {
            txtDelegatInstance.option('readonly', isReadOnly);
        }

        var ddlDepozitatInInstance = $('#ddlDepozitatIn').dxDropDownBox('instance');
        if (ddlDepozitatInInstance) {
            ddlDepozitatInInstance.option('readOnly', isReadOnly);
        }
    }
    const onFormsOpen = function (e) {
        e.component.getDataSource().load().then(function (data) {
            ReloadDataGrid("#grid-forms-combo");
        })

    }

    const onDataChanged = function (args) {
        //console.log(args);
        if (args.component.changedValue !== null && args.component.changedValue !== undefined) {
            dataNrcd = moment(args.component.changedValue).format("YYYY-MM-DD");
        } else if (args.value !== 0) {
            dataNrcd = moment(args.value).format("YYYY-MM-DD");
        }
    }

    return {
        onDisableCell: onDisableCell,
        onSetComisieReceptie: onSetComisieReceptie,
        onSetComisieGestiune: onSetComisieGestiune,
        onComisieReceptieChanged: onComisieReceptieChanged,
        onComisieGestiuneChanged: onComisieGestiuneChanged,
        onContractOpen: onContractOpen,
        onDepoziteOpen: onDepoziteOpen,
        onAddDetLine: onAddDetLine,
        onAddDefecteLine: onAddDefecteLine,
        onAddDelegatiLine: onAddDelegatiLine,
        onAddDiferenteLine: onAddDiferenteLine,
        onDeleteBatchRow: onDeleteBatchRow,
        onDelete: onDelete,
        onPrintRaport: onPrintRaport,
        onGeneratePvrd: onGeneratePvrd,
        setUnitateParam: setUnitateParam,
        onUnitatiChanged: onUnitatiChanged,
        onPlanAchizitieOpen: onPlanAchizitieOpen,
        onGestiuniOpen: onGestiuniOpen,
        onComisieReceptieOpen: onComisieReceptieOpen,
        onComisieGestiuneOpen: onComisieGestiuneOpen,
        getUnitateId: getUnitateId,
        onEditingStart: onEditingStart,
        onCalendarOpened: onCalendarOpened,
        resetUnitateId: resetUnitateId,
        setOrdinLivrareParam: setOrdinLivrareParam,
        setPlanAchizitieParam: setPlanAchizitieParam,
        setPlanAchizitieId: setPlanAchizitieId,
        setProductsStockParam: setProductsStockParam,
        setTranzactProductBaseId: setTranzactProductBaseId,
        onPlanChanged: onPlanChanged,
        onGestiuneChanged: onGestiuneChanged,
        onSetTranzactProdusBaseId: onSetTranzactProdusBaseId,
        getTranzactProductBaseId: getTranzactProductBaseId,
        setGestiuneDestinatieId: setGestiuneDestinatieId,
        getGestiuneDestinatieId: getGestiuneDestinatieId,
        setGestiuniTipLocDepozitareId: setGestiuniTipLocDepozitareId,
        getGestiuniTipLocDepozitareId: getGestiuniTipLocDepozitareId,
        setComisieFilterParam: setComisieFilterParam,
        setComisieReceptieId: setComisieReceptieId,
        setComisieGestiuneId: setComisieGestiuneId,
        onDepoziteValueChanged: onDepoziteValueChanged,
        getSelectedProductIds: getSelectedProductIds,
        setSelectedProdId: setSelectedProdId,
        setFieldsReadOnly: setFieldsReadOnly,
        onDataChanged: onDataChanged,
        onFormsOpen: onFormsOpen
    };
})();