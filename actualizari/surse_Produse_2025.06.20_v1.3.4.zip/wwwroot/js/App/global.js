const global = (function () {
    function logout() {
        $('#logoutForm').submit();
    }

    function schimbareParola() {
        window.location.href = "/UserAccess/Users/Index";
    }

    const onDeleteConfirmation = function (param, callback = null) {

        if (param === undefined || param.element.length === 0) return;

        const gridId = `#${param.element[0].id}`;

        const result = DevExpress.ui.dialog.confirm("<p>Sunteti sigur ca doriti stergerea elementului selectat?</p>", "Stergere");

        result.done(function (dialogResult) {

            if (callback !== undefined && callback !== null && typeof callback === 'function') {
                callback();
                return;
            }

            const deletedRowIndex = param.row.rowIndex;

            if (!dialogResult) return;
            if (!IsDataGridInstance(gridId)) return;

            const gridInstance = $(gridId).dxDataGrid('instance');
            gridInstance.deleteRow(deletedRowIndex);
            gridInstance.element().find(".dx-row-removed").hide();
        });
    }

    const onHidingUpsertViewPopup = function (popupId, controllerRoute, onClearInfo) {
        onClearInfo();
        $(popupId).dxPopup("dispose");
        $(popupId).load(`${controllerRoute}/GetPopupView`);
    }

    const setDateRangeValues = function (dateRangeId, startDate, endDate) {
        var dateRange = $(dateRangeId).dxDateRangeBox('instance');

        if (dateRange != undefined) {
            dateRange.option('value', [startDate, endDate]);
        }
    }

    const getDateRangeValues = function (dateRangeId) {
        var dateRange = $(dateRangeId).dxDateRangeBox('instance');

        if (dateRange != undefined) {
            return dateRange.option('value');
        }
    }

    return {
        logout: logout,
        schimbareParola: schimbareParola,
        onDeleteConfirmation: onDeleteConfirmation,
        onHidingUpsertViewPopup: onHidingUpsertViewPopup,
        setDateRangeValues: setDateRangeValues,
        getDateRangeValues: getDateRangeValues
    };
})();